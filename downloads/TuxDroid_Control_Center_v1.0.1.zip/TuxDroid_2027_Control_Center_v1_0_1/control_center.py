#!/usr/bin/env python3
"""TuxDroid 2027 Control Center v1.0 — historic full command deck, direct local Wi-Fi lab controller for original robot.

Safe allowlisted operations; uses separately built native macOS IOHID helper.
No firmware flash, driver install, network binding, arbitrary USB command or shell.
"""
from __future__ import annotations

import argparse
import ipaddress
import hmac
import socket
from collections import deque
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import signal
import subprocess
import threading
import time
from urllib.parse import urlsplit
from catalog import CATALOG, STATUS_CODES, LEGACY_GADGETS

ROOT = Path(__file__).resolve().parent
VERSION = "1.0.1"
PAGE = ROOT / "Web" / "index.html"
HELPER = ROOT / "bin" / "tuxhid"
HOST = "127.0.0.1"
PORT = 8765
MAX_BODY = 4096
PROVEN = {a['id'] for a in CATALOG if a['status'] == 'bewezen'}
LED_EXPERIMENTS = {a['id'] for a in CATALOG if a['group'] == 'Verlichting' and a['status'] != 'bewezen'}
MOTOR_EXPERIMENTS = {a['id'] for a in CATALOG if a['group'] == 'Beweging' and not a['id'].endswith('_stop')}
OTHER_EXPERIMENTS = {a['id'] for a in CATALOG if a['group'] in ('Audio', 'Infrarood', 'Sensoren')}
EXPERIMENTAL = LED_EXPERIMENTS | MOTOR_EXPERIMENTS | OTHER_EXPERIMENTS
ALLOWED = {a['id'] for a in CATALOG} | {'stop'}  # historical fixed actions only
STOP_ACTIONS = {'stop','stop_all','wings_stop','eyes_stop','mouth_stop','spin_stop'}
WING_ACTIONS = {'flap','flap_medium','flap_fast','wings_reset'}
EXPERIMENT_MAX = 0  # unlimited number of individual tests; movement duration remains bounded
EXPERIMENT_COOLDOWN = 0.0
MAX_FLAPS = 0  # unlimited one-shot flap tests; no continuous motor operation
COOLDOWN_SECONDS = 0.0


class Bridge:
    def __init__(self, *, mock=False, helper=HELPER):
        self.mock = mock
        self.helper = Path(helper)
        # v0.9: no user-facing pairing, PIN, cookies or manual unlocks.
        # A random per-run browser token + exact Origin checks still block blind
        # cross-site POSTs. This is NOT LAN authentication: anyone on trusted Wi-Fi
        # may open the page and control the robot. Never expose this port to WAN.
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.usb_lock = threading.Lock()
        self.events = deque(maxlen=70)
        self.detected = False
        self.hid_open = False
        self.led_observed = False
        self.led_proof_sent = False
        self.flaps = 0
        self.last_flap = 0.0
        self.flap_active = False
        self.experiments_armed = True
        self.experiment_count = 0
        self.last_experiment = 0.0
        self.experiment_active = False
        self.observed = set()  # recorded after explicit user confirmation, never inferred from USB
        self.led_diagnostic_feedback = {}  # per left/right scripted test, actual physical observation
        self.last_input = None
        self.last_response = None
        self.record("Control Center gestart", "info")

    def record(self, message, level="info"):
        with self.lock:
            self.events.appendleft({"at": datetime.now().astimezone().strftime("%H:%M:%S"),
                                    "level": level, "message": message})

    def snapshot(self):
        with self.lock:
            return {"version": VERSION, "mock": self.mock, "device": "03EB:FF07",
                    "detected": self.detected, "hid_open": self.hid_open,
                    "led_observed": self.led_observed, "led_proof_sent": self.led_proof_sent,
                    "flaps": self.flaps, "max_flaps": MAX_FLAPS, "flap_active": self.flap_active,
                    "experiments_armed": self.experiments_armed,
                    "experiment_count": self.experiment_count, "experiment_max": EXPERIMENT_MAX,
                    "experiment_active": self.experiment_active,
                    "experiment_cooldown": max(0, round(EXPERIMENT_COOLDOWN - (time.monotonic() - self.last_experiment), 1)) if self.experiment_count else 0,
                    "observed": sorted(self.observed), "led_diagnostic_feedback": dict(self.led_diagnostic_feedback), "last_input": self.last_input,
                    "cooldown_remaining": max(0, round(COOLDOWN_SECONDS - (time.monotonic() - self.last_flap), 1)) if self.flaps else 0,
                    "events": list(self.events), "last_response": self.last_response}

    def raw_helper(self, action, timeout=3):
        if action in {"led_test_left", "led_test_right"}: timeout = max(timeout, 5)
        if action not in ALLOWED:
            return {"ok": False, "code": "invalid_action", "message": "Niet-toegestane USB-opdracht"}
        if self.mock:
            return {"ok": True, "action": action, "device": "03EB:FF07",
                    "found": True, "count": 1,
                    "message": "SIMULATIE: geen USB-opdracht verstuurd", "simulated": True}
        if not self.helper.is_file():
            return {"ok": False, "code": "no_binary", "message": "Native HID-helper ontbreekt; start via het bouwscript"}
        try:
            child = subprocess.Popen([str(self.helper), action], stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True, cwd=str(ROOT),
                                     start_new_session=True)
            try:
                out, err = child.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                # SIGTERM requests cooperative STOP within the native flap loop.
                child.terminate()
                try:
                    child.communicate(timeout=1.5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.communicate()
                if action in MOTOR_EXPERIMENTS or action in WING_ACTIONS:
                    # Best effort independent full STOP; physical power-off still required if unexpected.
                    try:
                        subprocess.run([str(self.helper), "stop_all"], stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL, timeout=2, check=False)
                    except (OSError, subprocess.TimeoutExpired):
                        pass
                return {"ok": False, "code": "timeout", "message": "USB-opdracht duurde te lang; STOP geprobeerd. Schakel TuxDroid zo nodig uit."}
            try:
                data = json.loads(out)
                if not isinstance(data, dict):
                    raise ValueError("No JSON object")
            except (ValueError, json.JSONDecodeError):
                return {"ok": False, "code": "bad_native_output", "message": "HID-helper gaf geen geldig JSON-antwoord",
                        "diagnostic": (err or "")[:180]}
            if child.returncode != 0:
                data["ok"] = False
            return data
        except OSError as ex:
            return {"ok": False, "code": "spawn_error", "message": f"HID-helper kon niet starten: {type(ex).__name__}"}

    def run(self, action):
        # Prevent dangerous stale buttons and API calls from re-running a closing-only movement.
        if action == "eyes_blink":
            return 409, {"ok": False, "code": "eye_blink_disabled", "message": "Knipperen tijdelijk uitgeschakeld: vorige test sloot de oogleden zonder te heropenen. Gebruik Oogleden openen als herstelproef."}
        if action not in ALLOWED:
            return 400, {"ok": False, "message": "Onbekende opdracht"}
        # No confirmations, PIN, LED proof or experimental arming required.
        # USB must really be recognized/opened; this protects against stale UI.
        with self.lock:
            if action not in {"scan", "probe"} | STOP_ACTIONS and not (self.detected and self.hid_open):
                return 409, {"ok": False, "message": "USB-dongle nog niet verbonden. Kies 'Zoek USB-dongle' en 'Test HID-toegang'."}
            if action == "probe" and not self.detected:
                return 409, {"ok": False, "message": "Scan eerst de USB-dongle"}
            if action not in {"scan", "probe"} | STOP_ACTIONS and (self.flap_active or self.experiment_active):
                return 429, {"ok": False, "message": "Motor is nog bezig met een korte beweging. Probeer daarna opnieuw."}
            if action in EXPERIMENTAL:
                # LED and sensor/audio/IR operations do not burn motor-test slots.
                self.experiment_count += 1
                self.last_experiment = time.monotonic()
                if action in MOTOR_EXPERIMENTS:
                    self.experiment_active = True
            if action in WING_ACTIONS:
                self.flap_active = True
                self.flaps += 1
                self.last_flap = time.monotonic()
        # STOP is deliberately allowed while another command is in progress.
        acquired = self.usb_lock.acquire(blocking=False) if action not in STOP_ACTIONS else True
        if not acquired:
            with self.lock:
                if action in WING_ACTIONS:
                    self.flap_active = False
                    self.flaps -= 1
                if action in EXPERIMENTAL:
                    self.experiment_active = False
                    self.experiment_count = max(0, self.experiment_count-1)
            return 409, {"ok": False, "message": "USB is bezig; probeer opnieuw nadat de huidige test klaar is"}
        try:
            result = self.raw_helper(action)
        finally:
            if action not in STOP_ACTIONS:
                self.usb_lock.release()
        with self.lock:
            if action in WING_ACTIONS:
                self.flap_active = False
            if action in MOTOR_EXPERIMENTS:
                self.experiment_active = False
            if action in EXPERIMENTAL:
                if action == "read_input" and result.get("ok"):
                    self.last_input = result.get("raw_hex")
            if action == "scan":
                self.detected = bool(result.get("ok") and result.get("found"))
                self.hid_open = False
                self.led_observed = False
                self.led_proof_sent = False
                self.experiments_armed = True
                self.observed.clear()
                self.led_diagnostic_feedback.clear()
            elif action == "probe":
                self.hid_open = bool(result.get("ok"))
                self.led_observed = False
                self.led_proof_sent = False
                self.experiments_armed = True
                self.observed.clear()
                self.led_diagnostic_feedback.clear()
            elif action == "led_blink":
                self.led_proof_sent = bool(result.get("ok"))
                self.led_observed = False
            elif action in {"led_test_left", "led_test_right"}:
                # A previous observation is not evidence for this new attempt.
                self.led_diagnostic_feedback.pop(action, None)
            self.last_response = {"action": action, "ok": bool(result.get("ok")), "result": result}
            self.record(f"{action}: {result.get('message', 'Onbekend resultaat')}", "success" if result.get("ok") else "error")
        return 200 if result.get("ok") else 502, result

    def record_led_diagnostic(self, action, worked):
        if not isinstance(action, str) or action not in {"led_test_left", "led_test_right"} or not isinstance(worked, bool):
            return 400, {"ok": False, "message": "Alleen een vaste LED-proef en ja/nee toegestaan"}
        with self.lock:
            last = self.last_response or {}
            if self.mock or last.get("action") != action or not last.get("ok"):
                return 409, {"ok": False, "message": "Voer eerst deze echte LED-diagnose uit"}
            self.led_diagnostic_feedback[action] = worked
            self.record(f"{action}: gebruiker zag {'afzonderlijk oog reageren' if worked else 'GEEN afzonderlijke oogreactie'}", "info")
        return 200, {"ok": True, "message": "Waarneming vastgelegd in JSON-rapport; dit is geen firmware- of USB-bevestiging"}

    def confirm_led(self):
        with self.lock:
            if not self.led_proof_sent:
                return 409, {"ok": False, "message": "Voer eerst de korte LED-proef uit"}
            self.led_observed = True
            self.record("Gebruiker bevestigde zichtbare LED-reactie", "success")
            return 200, {"ok": True, "message": "LED-controle bevestigd; één vleugelslag per klik mogelijk"}

    def arm_experiments(self):
        with self.lock:
            if not self.detected or not self.hid_open or not self.led_observed:
                return 409, {"ok": False, "message": "Eerst USB/HID en fysieke LED-reactie bevestigen"}
            self.experiments_armed = True
            self.record("Voorzichtige originele hardwaretests handmatig ontgrendeld", "info")
            return 200, {"ok": True, "message": "Experimentele tests vrijgegeven. Iedere beweging kort, bewaakt en afzonderlijk testen."}

    def confirm_observed(self, action):
        with self.lock:
            if not isinstance(action, str) or action not in EXPERIMENTAL:
                return 400, {"ok": False, "message": "Ongeldige proef"}
            last = self.last_response or {}
            if last.get("action") != action or not last.get("ok") or self.mock:
                return 409, {"ok": False, "message": "Alleen direct na een geslaagde echte USB-proef te bevestigen"}
            self.observed.add(action)
            self.record(f"Fysieke reactie door gebruiker bevestigd: {action}", "success")
            return 200, {"ok": True, "message": f"Fysieke reactie bij {action} vastgelegd"}

    def speak(self, text):
        # Simple host TTS, not USB audio. It speaks over the *currently selected Mac output*.
        if not isinstance(text, str) or not (1 <= len(text) <= 140) or any(ord(c)<32 or ord(c)==127 for c in text):
            return 400, {"ok": False, "message": "Voer 1–140 tekens zonder regelafbrekingen in"}
        if self.mock:
            return 200, {"ok": True, "message": "SIMULATIE: macOS-spraak (geen robot-audio)"}
        try:
            result = subprocess.run(["/usr/bin/say", text], capture_output=True, text=True, timeout=18)
            ok = result.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            ok = False
        self.record("macOS-spraakproef gestart; geluid volgt standaard Mac-uitgang" if ok else "macOS-spraakproef mislukt", "success" if ok else "error")
        return (200 if ok else 502), {"ok": ok, "message": "Spraak verstuurd naar standaard macOS-audio-uitgang; alleen via TuxDroid als dongle-audio geselecteerd is" if ok else "Mac-spraakoproep mislukt"}

    def report(self):
        snapshot = self.snapshot()
        snapshot.pop("cooldown_remaining", None)
        snapshot.pop("experiment_cooldown", None)
        return {"application": "TuxDroid 2027 Control Center", "version": VERSION,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "read_only": False, "firmware_update": False,
                "browser_access": "no PIN, open to devices on same trusted local Wi-Fi (HTTP prototype)", "usb": snapshot}


class Handler(BaseHTTPRequestHandler):
    bridge: Bridge = None
    lan_ip = None  # set by server constructor; never interpolate untrusted hostnames
    server_version = "TuxDroid2027/" + VERSION
    sys_version = ""

    def log_message(self, fmt, *args):
        if not fmt.startswith('"GET /api/status'):
            print(f"[HTTP] {fmt % args}", flush=True)

    def _allowed_hosts(self):
        port = self.server.server_address[1]
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if self.lan_ip: hosts.add(f"{self.lan_ip}:{port}")
        return hosts

    def _host_ok(self):
        if self.headers.get("Host") not in self._allowed_hosts(): return False
        # LAN use is deliberately limited to the server's own /24 segment.
        # Proxies/WAN/other networks never qualify. localhost stays available.
        try:
            client = ipaddress.ip_address(self.client_address[0])
            if client.is_loopback: return True
            if not self.lan_ip: return False
            network = ipaddress.ip_network(f"{self.lan_ip}/24", strict=False)
            return client in network
        except ValueError:
            return False

    def _json(self, data, status=200, *, filename=None, set_cookie=None):
        payload = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        if filename: self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        if set_cookie: self.send_header("Set-Cookie", f"tux_session={set_cookie}; HttpOnly; SameSite=Strict; Path=/")
        self.end_headers()
        self.wfile.write(payload)

    def _deny(self, status=403, reason="Toegang geweigerd"):
        self._json({"ok": False, "message": reason}, status)

    def _html(self, source):
        page=source.encode('utf-8')
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def do_GET(self):
        if not self._host_ok(): return self._deny(403, "Geen toegang vanaf dit netwerk of deze host")
        path = urlsplit(self.path).path
        if path == "/":
            html = PAGE.read_text(encoding="utf-8").replace("__SESSION_TOKEN__", json.dumps(self.bridge.token))
            html = html.replace("__CATALOG_DATA__", json.dumps(CATALOG, ensure_ascii=False))
            html = html.replace("__STATUS_DATA__", json.dumps(STATUS_CODES, ensure_ascii=False))
            html = html.replace("__GADGET_DATA__", json.dumps(LEGACY_GADGETS, ensure_ascii=False))
            return self._html(html)
        if path == "/api/status": return self._json(self.bridge.snapshot())
        if path == "/api/catalog": return self._json({"commands": CATALOG, "status_codes": STATUS_CODES, "historical_gadgets": LEGACY_GADGETS})
        if path == "/api/report":
            return self._json(self.bridge.report(), filename="TuxDroid_2027_Control_Center_rapport.json")
        self._deny(404, "Pagina niet gevonden")

    def do_POST(self):
        if not self._host_ok(): return self._deny(403, "Geen toegang vanaf dit netwerk of deze host")
        origin = self.headers.get("Origin")
        if origin != "http://" + self.headers.get("Host", ""):
            return self._deny(403, "Verzoek van andere website geweigerd")
        if not hmac.compare_digest(self.headers.get("X-Tux-Token", ""), self.bridge.token):
            return self._deny(403, "Ongeldig browsertoken. Ververs de webpagina.")
        try: size = int(self.headers.get("Content-Length", "0"))
        except ValueError: return self._deny(400, "Ongeldige berichtlengte")
        if size < 0 or size > MAX_BODY: return self._deny(413, "Verzoek is te groot")
        try: body = json.loads(self.rfile.read(size)) if size else {}
        except (json.JSONDecodeError, UnicodeDecodeError): return self._deny(400, "Ongeldige JSON")
        if not isinstance(body, dict): return self._deny(400, "Ongeldige berichtinhoud")
        route = urlsplit(self.path).path
        if route == "/api/speak":
            if set(body) != {"text"}: return self._deny(400, "Alleen tekst toegestaan")
            status, result = self.bridge.speak(body["text"])
            return self._json(result, status)
        if route == "/api/led-test-feedback":
            if set(body) != {"action", "worked"}: return self._deny(400, "Alleen proef en waarneming toegestaan")
            status, result = self.bridge.record_led_diagnostic(body["action"], body["worked"])
            return self._json(result, status)
        if route == "/api/confirm-observed":
            # Optional factual test logging only; never a prerequisite for buttons.
            if set(body) != {"action"}: return self._deny(400, "Alleen een vaste actienaam toegestaan")
            status, result = self.bridge.confirm_observed(body["action"])
            return self._json(result, status)
        if body: return self._deny(400, "Extra USB-parameters zijn niet toegestaan")
        if route.startswith("/api/action/"):
            status, result = self.bridge.run(route.removeprefix("/api/action/"))
        else: return self._deny(404, "Opdracht niet gevonden")
        return self._json(result, status)


def create_server(bridge, port=PORT, lan_ip=None):
    class BoundHandler(Handler): pass
    BoundHandler.bridge = bridge
    BoundHandler.lan_ip = lan_ip
    host = "0.0.0.0" if lan_ip else "127.0.0.1"
    server = ThreadingHTTPServer((host, port), BoundHandler)
    server.daemon_threads = True
    server.allow_reuse_address = True
    return server


def get_lan_ip():
    # Use real active macOS interface; no VPN/public address or localhost.
    for interface in ("en0", "en1", "en2"):
        try:
            out = subprocess.run(["/usr/sbin/ipconfig", "getifaddr", interface], capture_output=True,
                                 text=True, timeout=2, check=False).stdout.strip()
            ip = ipaddress.ip_address(out)
            if ip.version == 4 and ip.is_private and not ip.is_loopback and not ip.is_link_local:
                return str(ip)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            continue
    return None


def main():
    parser = argparse.ArgumentParser(description="TuxDroid 2027 local Control Center")
    parser.add_argument("--demo", action="store_true", help="Demo without USB commands")
    parser.add_argument("--no-browser", action="store_true", help="Do not open Safari")
    parser.add_argument("--lan", action="store_true", help="Allow clients on trusted local Wi-Fi without a PIN")
    args = parser.parse_args()
    lan_ip = get_lan_ip() if args.lan else None
    if args.lan and not lan_ip: raise SystemExit("Geen geschikt privé-wifi-IP gevonden (en0/en1/en2). Verbind Mac en iPhone met hetzelfde wifi-netwerk.")
    bridge = Bridge(mock=args.demo)
    # Always start with a passive detection + HID open/close.
    # No LED or motor output is sent on application start.
    _, scan_result = bridge.run("scan")
    if scan_result.get("found"):
        bridge.run("probe")
    try:
        httpd = create_server(bridge, lan_ip=lan_ip)
    except OSError as ex:
        raise SystemExit(f"Poort {PORT} is bezet of niet beschikbaar: {ex}")
    address = f"http://{HOST}:{PORT}"
    print(f"🐧 TuxDroid 2027 COMMAND DECK v{VERSION} — {address}")
    if lan_ip:
        print(f"📱 OPEN OP JE iPHONE/iPAD: http://{lan_ip}:{PORT}")
        print("⚠ Alleen op VERTROUWD privé-wifi. Geen PIN of HTTPS; nooit publieke wifi of portforwarding.")
    print("✅ HISTORISCHE FUNCTIEDECK — 70 vaste USB-knoppen, geen pincode of ontgrendeling.")
    print("⚠ Iedereen op dit privé-wifi kan de robot bedienen. Geen HTTPS, geen internetdoorgifte.")
    print("Sluit af met Ctrl+C.")
    if args.demo: print("⚠ DEMO — USB-commando's worden alleen gesimuleerd.")
    if not args.no_browser:
        try:
            subprocess.Popen(["open", address], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
    try:
        httpd.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        # Best effort STOP if active movement; never assume software STOP is hardware guarantee.
        if bridge.flap_active or bridge.experiment_active:
            bridge.raw_helper("stop_all", timeout=2)
        httpd.server_close()
        print("TuxDroid 2027 Control Center gestopt.")


if __name__ == "__main__":
    main()
