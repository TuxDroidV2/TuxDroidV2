"""Diagnostic API regression checks; native helper replies are mocked, no USB."""
import http.client
import json
from pathlib import Path
import sys
import threading
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from control_center import Bridge, create_server


class DiagnosticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bridge = Bridge(mock=True)
        cls.server = create_server(cls.bridge, port=0)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(3)

    def setUp(self):
        self.bridge.mock = True
        self.bridge.led_diagnostic_feedback.clear()
        self.bridge.last_response = None

    def request(self, method, path, body=None):
        host = f"127.0.0.1:{self.port}"
        headers = {"Origin": "http://" + host,
                   "X-Tux-Token": self.bridge.token}
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            conn.request(method, path, json.dumps(body) if body is not None else None,
                         headers=headers)
            response = conn.getresponse()
            return response.status, json.loads(response.read())
        finally:
            conn.close()

    def stage_test(self, action="led_test_left", ok=True):
        # This stages a recorded native reply, without starting a helper process.
        self.bridge.mock = False
        self.bridge.last_response = {"action": action, "ok": ok,
                                     "result": {"ok": ok}}

    def test_malformed_action_returns_400_and_server_keeps_working(self):
        for action in ([], {}, 1, None):
            with self.subTest(action=action):
                status, _ = self.request("POST", "/api/led-test-feedback",
                                         {"action": action, "worked": True})
                self.assertEqual(status, 400)
        self.assertEqual(self.request("GET", "/api/status")[0], 200)

    def test_demo_cannot_record_physical_confirmation(self):
        self.bridge.last_response = {"action": "led_test_left", "ok": True}
        self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                     {"action": "led_test_left", "worked": True})[0], 409)

    def test_positive_and_negative_observation_saved_in_report(self):
        for worked in (True, False):
            with self.subTest(worked=worked):
                self.stage_test()
                self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                             {"action": "led_test_left", "worked": worked})[0], 200)
                status, report = self.request("GET", "/api/report")
                self.assertEqual(status, 200)
                self.assertIs(report["usb"]["led_diagnostic_feedback"]["led_test_left"], worked)

    def test_failed_or_stale_test_cannot_be_confirmed(self):
        for action, ok in (("led_test_left", False), ("stop_all", True)):
            with self.subTest(action=action, ok=ok):
                self.stage_test(action, ok)
                self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                             {"action": "led_test_left", "worked": True})[0], 409)

    def test_non_boolean_observation_is_rejected(self):
        self.stage_test()
        self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                     {"action": "led_test_left", "worked": "false"})[0], 400)

    def test_repeated_diagnosis_does_not_reuse_previous_observation(self):
        self.stage_test()
        self.bridge.detected = self.bridge.hid_open = True
        self.request("POST", "/api/led-test-feedback",
                     {"action": "led_test_left", "worked": True})
        with patch.object(self.bridge, "raw_helper", return_value={"ok": True}):
            self.assertEqual(self.request("POST", "/api/action/led_test_left", {})[0], 200)
        status, report = self.request("GET", "/api/report")
        self.assertEqual(status, 200)
        self.assertNotIn("led_test_left", report["usb"]["led_diagnostic_feedback"])

    def test_ir_failures_are_preserved_in_api_and_report(self):
        self.bridge.detected = self.bridge.hid_open = True
        reply = {"ok": False, "write_result": "0xE00002C0",
                 "ir_on_result": "0xE00002C0", "ir_off_result": "0xE00002C7",
                 "message": "IR-uit mislukt"}
        with patch.object(self.bridge, "raw_helper", return_value=reply):
            status, result = self.request("POST", "/api/action/ir_on", {})
        self.assertEqual(status, 502)
        self.assertEqual(result, reply)
        report = self.request("GET", "/api/report")[1]
        self.assertEqual(report["usb"]["last_response"]["result"], reply)

    def test_native_allowlist_rejects_before_device_access(self):
        # Source-level invariant only; actual IOKit compilation requires macOS.
        source = (ROOT / "Sources/tuxhid.m").read_text()
        gate = source.index('if (![allowed containsObject:action])')
        self.assertLess(gate, source.index("IOHIDManagerCreate("))
        self.assertIn('return fail(@"invalid_action"', source[gate:gate + 160])


if __name__ == "__main__":
    unittest.main(verbosity=2)
