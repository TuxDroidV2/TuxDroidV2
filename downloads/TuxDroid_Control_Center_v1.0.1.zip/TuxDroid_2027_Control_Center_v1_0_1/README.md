# TuxDroid 2027 Control Center v1.0.1

Onderhoudsversie van het aangeleverde Control Center v1.0.

## Start op je Mac

Pak dit ZIP-bestand uit in Documenten. Stop een eerdere server met Ctrl+C.
Open Terminal en kies de uitgepakte map:

```bash
cd "$HOME/Documents/TuxDroid_2027_Control_Center_v1_0_1"
bash Start_Demo.command
```

De demo verstuurt geen USB-opdrachten. Python 3.10 of nieuwer is vereist.

Voor de echte robot gebruik je in dezelfde map:

```bash
bash Start_TuxDroid_2027.command
```

Dit vereist macOS, Apple Command Line Tools, de originele 03EB:FF07-dongle,
een ingeschakelde robot en vertrouwd lokaal wifi. Het script bouwt de helper.
De app is een HTTP-laboratoriumprototype zonder wifi-authenticatie: alleen
op een afgeschermd thuisnetwerk gebruiken. Houd de fysieke uitknop bereikbaar.
Een software-STOP is geen gegarandeerde noodstop. Stem elke fysieke proef apart af.

## Softwarecorrecties

- Iedere STOP-actie annuleert resterende stappen van de scène in dat browservenster.
- Een mislukte scène meldt een fout in plaats van succesvolle voltooiing.
- Verbindingsverlies schakelt de actieknoppen uit; STOP blijft beschikbaar als poging.
- De demo toont nadrukkelijk dat geen echte robot verbonden is.
- LED-diagnose heeft knoppen om de fysieke waarneming vast te leggen; zowel ja
  als nee komt in het JSON-rapport. Een herhaalde proef gebruikt de oude waarneming niet.
- Ongeldige LED-feedback wordt met HTTP 400 afgewezen.
- De native helper controleert de allowlist voordat hij apparaten opent.
- De IR-puls bewaart inschakel- en uitschakelresultaten afzonderlijk.
- Het laatste USB-resultaat is zichtbaar, ook op mobiel.

## Validatie en beperkingen

42 Python-tests en 9 Chromium-browsertests slagen in Linux. Alle hardwareantwoorden
in die tests zijn gesimuleerd. Vier browserregressies falen op de originele v1.0
en slagen op de gewijzigde versie. De native allowlist is alleen op bronniveau
gecontroleerd. IOKit-compilatie en fysiek gedrag zijn nog niet op macOS getest.
De afwijkingen aan afzonderlijke leds, infrarood en oogleden zijn nog niet opgelost.

```bash
python3 -m unittest discover -s Tests -v
```

De optionele browsertests in Tools/check_browser.py vereisen Playwright en Chromium.
De app en Python-tests gebruiken verder alleen de Python-standaardbibliotheek.

Deze distributie bevat geen projecthistorie, chatdossiers, hardwarelogboeken,
previews of oude referentieprogramma's. Protocolgegevens zijn ontleend aan de
historische Ruby-driver; zie Docs/ORIGINELE_COMMANDOS.md.
