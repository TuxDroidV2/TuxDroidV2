# Bronverwijzingen en licentie

De protocolaanpassingen in `Sources/tux_protocol.h` zijn gebaseerd op
`libtuxdriver`, copyright (C) 2008 C2ME Sa / Rémi Jocaille, onder
GNU GPL versie 2 of later. De oorspronkelijke licentietekst staat in
`licenses/GPL-2.0.txt`. De aanpassingen worden eveneens onder GPL-2.0-or-later
beschikbaar gesteld; hun volledige broncode staat in deze distributie.

Onderzochte snapshot: https://github.com/joelmatteotti/tuxdriver/tree/b89270c787f77d24639d898de0b155b86cc28ac5

De firmwarebron en de PortAudio-server zijn alleen als referentie gelezen.
Hun firmware-images en executables zijn niet in deze distributie opgenomen.
De app installeert geen historische driver, stem, Java-runtime of firmware.
Zie `docs/AUDIO_EN_DRAAIEN_v1.2.0.md` voor de exacte bronketen en grenzen.
