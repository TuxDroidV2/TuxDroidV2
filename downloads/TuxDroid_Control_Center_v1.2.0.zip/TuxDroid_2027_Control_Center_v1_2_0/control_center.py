#!/usr/bin/env python3
"""TuxDroid 2027 Control Center v1.2.0 — local command deck with separate transport and observation evidence.

Safe allowlisted operations; uses separately built native macOS IOHID helper.
No firmware flash, driver install, network binding, arbitrary USB command or shell.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import copy
import hashlib
import ipaddress
import hmac
import socket
from collections import deque
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import platform
import sys
import signal
import subprocess
import threading
import time
from urllib.parse import urlsplit
from catalog import CATALOG, STATUS_CODES, LEGACY_GADGETS
from attitunes import inspect_archive, AttituneError
from audio_output import MacAudio

ROOT = Path(__file__).resolve().parent
VERSION = "1.2.0"
PAGE = ROOT / "Web" / "index.html"
HELPER = ROOT / "bin" / "tuxhid"
HOST = "127.0.0.1"
PORT = 8765
MAX_BODY = 4096
PROVEN = {a['id'] for a in CATALOG if a['status'] == 'bewezen'}
LED_EXPERIMENTS = {a['id'] for a in CATALOG if a['group'] == 'Verlichting' and a['status'] != 'bewezen'}
MOTOR_EXPERIMENTS = {a['id'] for a in CATALOG if a['group'] == 'Beweging' and not a['id'].endswith('_stop')}
OTHER_EXPERIMENTS = {a['id'] for a in CATALOG if a['group'] in ('Audio', 'Infrarood', 'Sensoren')}
EXPERIMENTAL = LED_EXPERIMENTS | MOTOR_EXPERIMENTS | OTHER_EXPERIMENTS
ALLOWED = {a['id'] for a in CATALOG} | {'stop'}  # historical fixed actions only
AUDIO_CHANNELS = {"audio_channel_general", "audio_channel_tts"}
STOP_ACTIONS = {'stop','stop_all','wings_stop','eyes_stop','mouth_stop','spin_stop'}
WING_ACTIONS = {'flap','flap_medium','flap_fast','wings_reset'}
EXPERIMENT_MAX = 0  # unlimited number of individual tests; movement duration remains bounded
EXPERIMENT_COOLDOWN = 0.0
MAX_FLAPS = 0  # unlimited one-shot flap tests; no continuous motor operation
COOLDOWN_SECONDS = 0.0
HISTORY_LIMIT = 200
OBSERVABLE = (ALLOWED | AUDIO_CHANNELS) - {"scan", "probe", "read_input"}


class Bridge:
    def __init__(self, *, mock=False, helper=HELPER, report_dir=None):
        self.mock = mock
        self.helper = Path(helper)
        # v0.9: no user-facing pairing, PIN, cookies or manual unlocks.
        # A random per-run browser token + exact Origin checks still block blind
        # cross-site POSTs. This is NOT LAN authentication: anyone on trusted Wi-Fi
        # may open the page and control the robot. Never expose this port to WAN.
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.usb_lock = threading.Lock()
        self.audio_lock = threading.Lock()
        self.audio = MacAudio(mock=mock)
        self.audio_devices = {"ok": True, "devices": [], "message": "Audio-uitgangen nog niet onderzocht"}
        self.save_lock = threading.Lock()
        self.report_dir = Path(report_dir) if report_dir is not None else None
        self.report_error = None
        self.session_id = secrets.token_hex(8)
        self.command_count = 0
        self.command_history = deque(maxlen=HISTORY_LIMIT)
        self.helper_version = VERSION if mock else None
        self.helper_sha256 = None
        self.output_ready = False
        self.stop_generation = 0
        self.events = deque(maxlen=70)
        self.detected = False
        self.hid_open = False
        self.led_observed = False
        self.led_proof_sent = False
        self.flaps = 0
        self.last_flap = 0.0
        self.flap_active = False
        self.experiments_armed = True
        self.experiment_count = 0
        self.last_experiment = 0.0
        self.experiment_active = False
        self.observed = set()  # recorded after explicit user confirmation, never inferred from USB
        self.led_diagnostic_feedback = {}  # per left/right scripted test, actual physical observation
        self.last_input = None
        self.last_input_result = None
        self.last_response = None
        self.record("Control Center gestart", "info")

    def record(self, message, level="info"):
        with self.lock:
            self.events.appendleft({"at": datetime.now().astimezone().strftime("%H:%M:%S"),
                                    "level": level, "message": message})

    def snapshot(self):
        with self.lock:
            recent = [{k: row[k] for k in ("id", "sequence", "action", "kind", "mode", "completed_at", "ok", "code", "output_attempted", "can_observe", "observation")}
                      for row in list(self.command_history)[-20:]]
            return {"version": VERSION, "mock": self.mock, "device": "03EB:FF07",
                    "detected": self.detected, "hid_open": self.hid_open,
                    "output_ready": self.output_ready,
                    "stop_generation": self.stop_generation,
                    "audio": copy.deepcopy(self.audio_devices), "audio_active": self.audio_lock.locked(),
                    "helper_version": self.helper_version,
                    "helper_compatible": self.mock or self.helper_version == VERSION,
                    "report_autosave": self.report_dir is not None,
                    "report_error": self.report_error,
                    "command_count": self.command_count, "recent_commands": copy.deepcopy(recent),
                    "led_observed": self.led_observed, "led_proof_sent": self.led_proof_sent,
                    "flaps": self.flaps, "max_flaps": MAX_FLAPS, "flap_active": self.flap_active,
                    "experiments_armed": self.experiments_armed,
                    "experiment_count": self.experiment_count, "experiment_max": EXPERIMENT_MAX,
                    "experiment_active": self.experiment_active,
                    "experiment_cooldown": max(0, round(EXPERIMENT_COOLDOWN - (time.monotonic() - self.last_experiment), 1)) if self.experiment_count else 0,
                    "observed": sorted(self.observed), "led_diagnostic_feedback": dict(self.led_diagnostic_feedback), "last_input": self.last_input,
                    "last_input_result": copy.deepcopy(self.last_input_result),
                    "cooldown_remaining": max(0, round(COOLDOWN_SECONDS - (time.monotonic() - self.last_flap), 1)) if self.flaps else 0,
                    "events": list(self.events), "last_response": self.last_response}

    def raw_helper(self, action, timeout=3):
        if action in {"led_test_left", "led_test_right"}: timeout = max(timeout, 5)
        if action not in ALLOWED | AUDIO_CHANNELS:
            return {"ok": False, "code": "invalid_action", "message": "Niet-toegestane USB-opdracht"}
        if self.mock:
            return {"ok": True, "action": action, "device": "03EB:FF07",
                    "found": True, "count": 1,
                    "helper_version": VERSION, "output_ready": True,
                    "output_reports": [], "usb_output_reports_attempted": False,
                    "message": "SIMULATIE: geen USB-opdracht verstuurd", "simulated": True}
        if not self.helper.is_file():
            return {"ok": False, "code": "no_binary", "message": "Native HID-helper ontbreekt; start via het bouwscript"}
        started = False
        try:
            child = subprocess.Popen([str(self.helper), action], stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True, cwd=str(ROOT),
                                     start_new_session=True)
            started = True
            try:
                out, err = child.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                # SIGTERM requests cooperative STOP within the native flap loop.
                child.terminate()
                try:
                    child.communicate(timeout=1.5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.communicate()
                recovery = {"attempted": False}
                if action in MOTOR_EXPERIMENTS or action in WING_ACTIONS:
                    # Best effort independent full STOP; physical power-off still required if unexpected.
                    try:
                        recovery["attempted"] = True
                        stopped = subprocess.run([str(self.helper), "stop_all"], capture_output=True,
                                                 text=True, timeout=2, check=False)
                        reply = json.loads(stopped.stdout)
                        recovery["result"] = reply if isinstance(reply, dict) else None
                        recovery["ok"] = stopped.returncode == 0 and isinstance(reply, dict) and reply.get("ok") is True
                    except (OSError, subprocess.TimeoutExpired, ValueError, UnicodeError) as ex:
                        recovery["ok"] = False
                        recovery["error"] = type(ex).__name__
                message = "USB-opdracht duurde te lang; uitvoering onbekend."
                if recovery["attempted"]:
                    message += " STOP geprobeerd; schakel TuxDroid zo nodig fysiek uit."
                return {"ok": False, "code": "timeout", "helper_process_started": True,
                        "usb_output_reports_attempted": None, "recovery_stop": recovery, "message": message}
            try:
                data = json.loads(out)
                if not isinstance(data, dict) or not isinstance(data.get("ok"), bool):
                    raise ValueError("No JSON object")
            except (ValueError, json.JSONDecodeError):
                return {"ok": False, "code": "bad_native_output", "message": "HID-helper gaf geen geldig JSON-antwoord",
                        "helper_process_started": True, "usb_output_reports_attempted": None,
                        "diagnostic": (err or "")[:180]}
            if child.returncode != 0:
                data["ok"] = False
            if data.get("action") not in (None, action):
                return {"ok": False, "code": "bad_native_output", "helper_process_started": True,
                        "usb_output_reports_attempted": None, "message": "HID-helper antwoordde op een andere opdracht"}
            data["helper_process_started"] = True
            if action in {"scan", "probe"}:
                with self.lock:
                    self.helper_sha256 = hashlib.sha256(self.helper.read_bytes()).hexdigest()
            return data
        except (OSError, UnicodeError) as ex:
            return {"ok": False, "code": "spawn_error", "helper_process_started": started,
                    "usb_output_reports_attempted": None if started else False,
                    "message": f"HID-helperfout: {type(ex).__name__}"}

    def run(self, action, *, scene_generation=None):
        started = datetime.now(timezone.utc).isoformat()
        clock = time.monotonic()
        with self.lock:
            if isinstance(action, str) and action in STOP_ACTIONS:
                self.stop_generation += 1
                self.audio.stop()
        status, result = self._run(action, scene_generation=scene_generation)
        self._store_command(action, status, result, started, clock)
        return status, result

    def _store_command(self, action, status, result, started, clock, *, kind="usb"):
        with self.lock:
            self.command_count += 1
            command_id = f"{self.session_id}:{self.command_count}"
            attempted = result.get("usb_output_reports_attempted")
            if type(attempted) is not bool:
                attempted = bool(result["output_reports"]) if isinstance(result.get("output_reports"), list) else None if result.get("helper_process_started") else False
            observable = (not self.mock and not result.get("simulated") and
                          ((kind == "usb" and isinstance(action, str) and action in OBSERVABLE and attempted is not False)
                           or (kind == "robot_audio" and result.get("audio_attempted") is True)))
            row = {"id": command_id, "sequence": self.command_count,
                   "action": action if isinstance(action, str) else "invalid_action",
                   "kind": kind, "mode": "demo" if self.mock else "hardware" if kind in {"usb", "robot_audio"} else "host_audio",
                   "started_at": started, "completed_at": datetime.now(timezone.utc).isoformat(),
                   "duration_ms": round((time.monotonic() - clock) * 1000),
                   "http_status": status, "ok": result.get("ok") is True,
                   "code": result.get("code"), "result": copy.deepcopy(result),
                   "output_attempted": attempted,
                   "can_observe": bool(observable), "observation": None}
            self.command_history.append(row)
            if kind == "usb":
                self.last_response = {"id": command_id, "action": row["action"], "ok": row["ok"],
                                      "result": copy.deepcopy(result)}
        self.save_report()

    def save_report(self):
        if self.report_dir is None:
            return
        with self.save_lock:
            try:
                with self.lock:
                    self.report_error = None
                self.report_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
                data = json.dumps(self.report(), ensure_ascii=False, indent=2)
                for name in (f"session-{self.session_id}.json", "latest.json"):
                    target = self.report_dir / name
                    temporary = target.with_suffix(".json.tmp")
                    temporary.write_text(data, encoding="utf-8")
                    temporary.chmod(0o600)
                    temporary.replace(target)
                with self.lock:
                    self.report_error = None
            except OSError as ex:
                with self.lock:
                    self.report_error = f"Automatisch opslaan mislukt ({type(ex).__name__}); download het rapport via Diagnose."

    def _run(self, action, *, scene_generation=None, internal_audio=False):
        if not isinstance(action, str):
            return 400, {"ok": False, "code": "invalid_action", "message": "Ongeldige opdracht"}
        if scene_generation is not None and (type(scene_generation) is not int or scene_generation < 0):
            return 400, {"ok": False, "code": "invalid_scene", "message": "Ongeldige scèneversie"}
        # Prevent dangerous stale buttons and API calls from re-running a closing-only movement.
        if action == "eyes_blink":
            return 409, {"ok": False, "code": "eye_blink_disabled", "message": "Knipperen tijdelijk uitgeschakeld: vorige test sloot de oogleden zonder te heropenen. Gebruik Oogleden openen als herstelproef."}
        if action not in ALLOWED and not (internal_audio and action in AUDIO_CHANNELS):
            return 400, {"ok": False, "message": "Onbekende opdracht"}
        # No confirmations, PIN, LED proof or experimental arming required.
        # USB must really be recognized/opened; this protects against stale UI.
        with self.lock:
            if action not in STOP_ACTIONS and scene_generation is not None and scene_generation != self.stop_generation:
                return 409, {"ok": False, "code": "scene_cancelled", "message": "Deze scène is door een STOP-opdracht geannuleerd"}
            if action not in {"scan", "probe"} | STOP_ACTIONS and not (self.detected and self.hid_open):
                return 409, {"ok": False, "message": "USB-dongle nog niet verbonden. Kies 'Zoek USB-dongle' en 'Test HID-toegang'."}
            if action == "probe" and not self.detected:
                return 409, {"ok": False, "message": "Scan eerst de USB-dongle"}
            if action not in {"scan", "probe"} | STOP_ACTIONS and not self.mock and self.helper_version != VERSION:
                return 409, {"ok": False, "code": "helper_version_mismatch",
                             "message": "De native helper hoort niet bij deze appversie. Stop de server en start opnieuw via Start_TuxDroid_2027.command."}
            if action not in {"scan", "probe", "read_input"} | STOP_ACTIONS and not self.output_ready:
                return 409, {"ok": False, "code": "wrong_report_size", "message": "Deze HID-interface heeft geen geschikt 64-byte uitvoerreport."}
            if action not in {"scan", "probe"} | STOP_ACTIONS and (self.flap_active or self.experiment_active):
                return 429, {"ok": False, "message": "Motor is nog bezig met een korte beweging. Probeer daarna opnieuw."}
            if action in EXPERIMENTAL:
                # LED and sensor/audio/IR operations do not burn motor-test slots.
                self.experiment_count += 1
                self.last_experiment = time.monotonic()
                if action in MOTOR_EXPERIMENTS:
                    self.experiment_active = True
            if action in WING_ACTIONS:
                self.flap_active = True
                self.flaps += 1
                self.last_flap = time.monotonic()
        # STOP is deliberately allowed while another command is in progress.
        acquired = self.usb_lock.acquire(blocking=False) if action not in STOP_ACTIONS else True
        if not acquired:
            with self.lock:
                if action in WING_ACTIONS:
                    self.flap_active = False
                    self.flaps -= 1
                if action in EXPERIMENTAL:
                    self.experiment_active = False
                    self.experiment_count = max(0, self.experiment_count-1)
            return 409, {"ok": False, "message": "USB is bezig; probeer opnieuw nadat de huidige test klaar is"}
        try:
            try:
                result = self.raw_helper(action)
            except Exception as ex:
                result = {"ok": False, "code": "helper_exception",
                          "message": f"Helperfout ({type(ex).__name__}); opdracht niet als geslaagd beschouwd"}
        finally:
            if action not in STOP_ACTIONS:
                self.usb_lock.release()
        with self.lock:
            if isinstance(result.get("helper_version"), str):
                self.helper_version = result["helper_version"]
            if action in WING_ACTIONS:
                self.flap_active = False
            if action in MOTOR_EXPERIMENTS:
                self.experiment_active = False
            if action == "read_input":
                self.last_input = result.get("raw_hex") if result.get("ok") else None
                self.last_input_result = copy.deepcopy(result)
            if action == "scan":
                self.detected = bool(result.get("ok") and result.get("found") is True)
                self.hid_open = False
                self.output_ready = False
                self.last_input = self.last_input_result = None
                self.led_observed = False
                self.led_proof_sent = False
                self.experiments_armed = True
                self.observed.clear()
                self.led_diagnostic_feedback.clear()
            elif action == "probe":
                self.hid_open = bool(result.get("ok"))
                self.output_ready = bool(self.hid_open and result.get("output_ready", True))
                self.last_input = self.last_input_result = None
                self.led_observed = False
                self.led_proof_sent = False
                self.experiments_armed = True
                self.observed.clear()
                self.led_diagnostic_feedback.clear()
            elif action == "led_blink":
                self.led_proof_sent = bool(result.get("ok"))
                self.led_observed = False
            elif action in {"led_test_left", "led_test_right"}:
                # A previous observation is not evidence for this new attempt.
                self.led_diagnostic_feedback.pop(action, None)
            if result.get("code") in {"wrong_device_count", "no_binary", "spawn_error", "bad_native_output"}:
                self.detected = self.hid_open = self.output_ready = False
            elif result.get("code") == "open_failed":
                self.hid_open = self.output_ready = False
            elif result.get("code") == "wrong_report_size":
                self.output_ready = False
            self.last_response = {"action": action, "ok": bool(result.get("ok")), "result": result}
            level = "success" if result.get("ok") else "warning" if result.get("code") == "no_input_report" else "error"
            self.record(f"{action}: {result.get('message', 'Onbekend resultaat')}", level)
        return 200 if result.get("ok") or result.get("code") == "no_input_report" else 502, result

    def record_observation(self, command_id, outcome, note=""):
        if (not isinstance(command_id, str) or not isinstance(outcome, str) or
                outcome not in {"expected", "no_reaction", "different"} or
                not isinstance(note, str) or len(note) > 400 or
                any((ord(c) < 32 and c not in "\n\t") or ord(c) == 127 or
                    0xD800 <= ord(c) <= 0xDFFF for c in note)):
            return 400, {"ok": False, "message": "Kies een geldige opdracht, waarneming en maximaal 400 tekens toelichting"}
        with self.lock:
            row = next((r for r in self.command_history if r["id"] == command_id), None)
            if row is None:
                return 404, {"ok": False, "message": "Deze opdracht staat niet meer in deze sessie"}
            if self.mock or not row["can_observe"]:
                return 409, {"ok": False, "message": "Alleen een echte uitgevoerde USB-poging kan een fysieke waarneming krijgen"}
            row["observation"] = {"outcome": outcome, "note": note,
                                  "recorded_at": datetime.now(timezone.utc).isoformat(), "source": "user"}
            if row["action"] in {"led_test_left", "led_test_right"}:
                self.led_diagnostic_feedback[row["action"]] = outcome == "expected"
            self.record(f"Waarneming bij opdracht {row['sequence']} ({row['action']}): {outcome}", "info")
        self.save_report()
        return 200, {"ok": True, "message": "Fysieke waarneming bij deze specifieke opdracht opgeslagen"}

    def record_led_diagnostic(self, action, worked):
        if not isinstance(action, str) or action not in {"led_test_left", "led_test_right"} or not isinstance(worked, bool):
            return 400, {"ok": False, "message": "Alleen een vaste LED-proef en ja/nee toegestaan"}
        with self.lock:
            last = self.last_response or {}
            if self.mock or last.get("action") != action or not last.get("ok"):
                return 409, {"ok": False, "message": "Voer eerst deze echte LED-diagnose uit"}
            self.led_diagnostic_feedback[action] = worked
            command_id = last.get("id")
            row = next((r for r in self.command_history if r["id"] == command_id), None)
            if row is not None and row["can_observe"]:
                row["observation"] = {"outcome": "expected" if worked else "different", "note": "LED-diagnosefeedback",
                                      "recorded_at": datetime.now(timezone.utc).isoformat(), "source": "user"}
            self.record(f"{action}: gebruiker zag {'afzonderlijk oog reageren' if worked else 'GEEN afzonderlijke oogreactie'}", "info")
        self.save_report()
        return 200, {"ok": True, "message": "Waarneming vastgelegd in JSON-rapport; dit is geen firmware- of USB-bevestiging"}

    def confirm_led(self):
        with self.lock:
            if not self.led_proof_sent:
                return 409, {"ok": False, "message": "Voer eerst de korte LED-proef uit"}
            self.led_observed = True
            self.record("Gebruiker bevestigde zichtbare LED-reactie", "success")
            return 200, {"ok": True, "message": "LED-controle bevestigd; één vleugelslag per klik mogelijk"}

    def arm_experiments(self):
        with self.lock:
            if not self.detected or not self.hid_open or not self.led_observed:
                return 409, {"ok": False, "message": "Eerst USB/HID en fysieke LED-reactie bevestigen"}
            self.experiments_armed = True
            self.record("Voorzichtige originele hardwaretests handmatig ontgrendeld", "info")
            return 200, {"ok": True, "message": "Experimentele tests vrijgegeven. Iedere beweging kort, bewaakt en afzonderlijk testen."}

    def confirm_observed(self, action):
        with self.lock:
            if not isinstance(action, str) or action not in EXPERIMENTAL:
                return 400, {"ok": False, "message": "Ongeldige proef"}
            last = self.last_response or {}
            if last.get("action") != action or not last.get("ok") or self.mock:
                return 409, {"ok": False, "message": "Alleen direct na een geslaagde echte USB-proef te bevestigen"}
            self.observed.add(action)
            self.record(f"Fysieke reactie door gebruiker bevestigd: {action}", "success")
            return 200, {"ok": True, "message": f"Fysieke reactie bij {action} vastgelegd"}

    def scan_audio(self):
        result = self.audio.devices()
        with self.lock:
            self.audio_devices = result
        return result

    def speak(self, text, *, target="host", device_id=None):
        started = datetime.now(timezone.utc).isoformat()
        clock = time.monotonic()
        kind = "robot_audio" if target == "robot" else "host_audio"
        status, result = self._speak(text, target=target, device_id=device_id)
        self._store_command("robot_speech" if target == "robot" else "host_speech",
                            status, result, started, clock, kind=kind)
        self.record(result["message"], "success" if result.get("ok") else "error")
        return status, result

    def _speak(self, text, *, target, device_id):
        if (not isinstance(text, str) or not (1 <= len(text) <= 140) or
                any(ord(c) < 32 or ord(c) == 127 or 0xD800 <= ord(c) <= 0xDFFF for c in text) or
                "[[" in text or "]]" in text):
            return 400, {"ok": False, "message": "Voer 1–140 gewone teksttekens in, zonder spraakcodes of regelafbrekingen"}
        if not isinstance(target, str) or target not in {"robot", "host"} or (target == "host" and device_id is not None):
            return 400, {"ok": False, "message": "Kies robotspraak of Mac-spraak"}
        if not self.audio_lock.acquire(blocking=False):
            return 409, {"ok": False, "message": "Spraak is nog bezig; stop de stem of wacht tot deze klaar is"}
        try:
            with self.lock:
                generation = self.stop_generation
                epoch = self.audio.epoch()
            device = None
            preparation = None
            if target == "robot":
                resolved = self.audio.resolve(device_id)
                if not resolved["ok"]:
                    return 409, resolved
                device = resolved["device"]
                if not self.mock:
                    if epoch != self.audio.epoch():
                        return 409, {"ok": False, "code": "audio_cancelled", "audio_attempted": False,
                                     "message": "Spraak door STOP geannuleerd vóór de kanaalkeuze"}
                    action = "audio_channel_" + device["channel"]
                    started = datetime.now(timezone.utc).isoformat()
                    clock = time.monotonic()
                    status, preparation = self._run(action, scene_generation=generation, internal_audio=True)
                    self._store_command(action, status, preparation, started, clock)
                    if not preparation.get("ok"):
                        return status, {"ok": False, "code": "audio_prepare_failed", "audio_attempted": False,
                                        "device": device, "preparation": preparation,
                                        "message": "Audio-kanaal niet gereed: " + preparation.get("message", "USB-fout")}
            result = self.audio.speak(text, device, epoch=epoch)
            result["target"] = target
            if preparation is not None:
                result["preparation"] = preparation
            if target == "host" and result.get("ok") and not result.get("simulated"):
                result["message"] = "Spraak verwerkt via de standaard Mac-uitgang; dit is geen bevestigde robotspraak"
            return (200 if result.get("ok") else 409 if result.get("code") == "audio_cancelled" else 502), result
        finally:
            self.audio_lock.release()

    def report(self):
        with self.lock:
            snapshot = self.snapshot()
            snapshot.pop("cooldown_remaining", None)
            snapshot.pop("experiment_cooldown", None)
            return {"application": "TuxDroid 2027 Control Center", "version": VERSION,
                    "report_schema": 2, "session_id": self.session_id,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "read_only": False, "firmware_update": False,
                    "runtime": {"platform": sys.platform, "architecture": platform.machine(),
                                "python": platform.python_version(), "helper_version": self.helper_version,
                                "helper_sha256": self.helper_sha256},
                    "commands": copy.deepcopy(list(self.command_history)),
                    "commands_truncated": max(0, self.command_count - len(self.command_history)),
                    "browser_access": "no PIN, open to devices on same trusted local Wi-Fi (HTTP prototype)", "usb": copy.deepcopy(snapshot)}


class Handler(BaseHTTPRequestHandler):
    bridge: Bridge = None
    lan_ip = None  # set by server constructor; never interpolate untrusted hostnames
    server_version = "TuxDroid2027/" + VERSION
    sys_version = ""

    def log_message(self, fmt, *args):
        if not fmt.startswith('"GET /api/status'):
            print(f"[HTTP] {fmt % args}", flush=True)

    def _allowed_hosts(self):
        port = self.server.server_address[1]
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if self.lan_ip: hosts.add(f"{self.lan_ip}:{port}")
        return hosts

    def _host_ok(self):
        if self.headers.get("Host") not in self._allowed_hosts(): return False
        # LAN use is deliberately limited to the server's own /24 segment.
        # Proxies/WAN/other networks never qualify. localhost stays available.
        try:
            client = ipaddress.ip_address(self.client_address[0])
            if client.is_loopback: return True
            if not self.lan_ip: return False
            network = ipaddress.ip_network(f"{self.lan_ip}/24", strict=False)
            return client in network
        except ValueError:
            return False

    def _json(self, data, status=200, *, filename=None, set_cookie=None):
        payload = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        if filename: self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        if set_cookie: self.send_header("Set-Cookie", f"tux_session={set_cookie}; HttpOnly; SameSite=Strict; Path=/")
        self.end_headers()
        self.wfile.write(payload)

    def _deny(self, status=403, reason="Toegang geweigerd"):
        self._json({"ok": False, "message": reason}, status)

    def _html(self, source):
        page=source.encode('utf-8')
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def do_GET(self):
        if not self._host_ok(): return self._deny(403, "Geen toegang vanaf dit netwerk of deze host")
        path = urlsplit(self.path).path
        if path == "/":
            html = PAGE.read_text(encoding="utf-8").replace("__SESSION_TOKEN__", json.dumps(self.bridge.token))
            html = html.replace("__CATALOG_DATA__", json.dumps(CATALOG, ensure_ascii=False))
            html = html.replace("__STATUS_DATA__", json.dumps(STATUS_CODES, ensure_ascii=False))
            html = html.replace("__GADGET_DATA__", json.dumps(LEGACY_GADGETS, ensure_ascii=False))
            return self._html(html)
        if path == "/api/status": return self._json(self.bridge.snapshot())
        if path == "/api/audio/devices": return self._json(self.bridge.scan_audio())
        if path == "/api/catalog": return self._json({"commands": CATALOG, "status_codes": STATUS_CODES, "historical_gadgets": LEGACY_GADGETS})
        if path == "/api/report":
            return self._json(self.bridge.report(), filename="TuxDroid_2027_Control_Center_rapport.json")
        self._deny(404, "Pagina niet gevonden")

    def do_POST(self):
        if not self._host_ok(): return self._deny(403, "Geen toegang vanaf dit netwerk of deze host")
        origin = self.headers.get("Origin")
        if origin != "http://" + self.headers.get("Host", ""):
            return self._deny(403, "Verzoek van andere website geweigerd")
        if not hmac.compare_digest(self.headers.get("X-Tux-Token", "").encode("utf-8"), self.bridge.token.encode("utf-8")):
            return self._deny(403, "Ongeldig browsertoken. Ververs de webpagina.")
        try: size = int(self.headers.get("Content-Length", "0"))
        except ValueError: return self._deny(400, "Ongeldige berichtlengte")
        route = urlsplit(self.path).path
        limit = 3 * 1024 * 1024 if route == "/api/attitunes/inspect" else MAX_BODY
        if size < 0 or size > limit: return self._deny(413, "Verzoek is te groot")
        try: body = json.loads(self.rfile.read(size)) if size else {}
        except (json.JSONDecodeError, UnicodeDecodeError): return self._deny(400, "Ongeldige JSON")
        if not isinstance(body, dict): return self._deny(400, "Ongeldige berichtinhoud")
        if route == "/api/attitunes/inspect":
            if set(body) != {"filename", "archive_base64"} or not isinstance(body["archive_base64"], str):
                return self._deny(400, "Kies een geldig Attitunes-bestand")
            try:
                payload = base64.b64decode(body["archive_base64"], validate=True)
                result = inspect_archive(payload, body["filename"])
            except (binascii.Error, ValueError, AttituneError):
                return self._deny(400, "Geen ondersteund Attitunes-archief; kies een .att, ZIP of tar.gz van maximaal 2 MB")
            self.bridge.record(f"Oorspronkelijk Attitunes-archief geïnspecteerd: {result['scene_count']} scènes, niets uitgevoerd", "info")
            self.bridge.save_report()
            return self._json(result)
        if route == "/api/observation":
            if set(body) != {"command_id", "outcome", "note"}:
                return self._deny(400, "Alleen opdracht-ID, waarneming en toelichting toegestaan")
            status, result = self.bridge.record_observation(body["command_id"], body["outcome"], body["note"])
            return self._json(result, status)
        if route == "/api/audio/stop":
            if body: return self._deny(400, "Geen extra parameters toegestaan")
            self.bridge.audio.stop()
            return self._json({"ok": True, "message": "Spraak-STOP gevraagd"})
        if route == "/api/speak":
            if "text" not in body or set(body) - {"text", "target", "device_id"}:
                return self._deny(400, "Alleen tekst, doel en audio-uitgang toegestaan")
            if "target" in body and not isinstance(body["target"], str):
                return self._deny(400, "Ongeldig spraakdoel")
            status, result = self.bridge.speak(body["text"], target=body.get("target", "robot"),
                                               device_id=body.get("device_id"))
            return self._json(result, status)
        if route == "/api/led-test-feedback":
            if set(body) != {"action", "worked"}: return self._deny(400, "Alleen proef en waarneming toegestaan")
            status, result = self.bridge.record_led_diagnostic(body["action"], body["worked"])
            return self._json(result, status)
        if route == "/api/confirm-observed":
            # Optional factual test logging only; never a prerequisite for buttons.
            if set(body) != {"action"}: return self._deny(400, "Alleen een vaste actienaam toegestaan")
            status, result = self.bridge.confirm_observed(body["action"])
            return self._json(result, status)
        if route.startswith("/api/action/"):
            if body and set(body) != {"scene_generation"}:
                return self._deny(400, "Extra USB-parameters zijn niet toegestaan")
            if "scene_generation" in body and (type(body["scene_generation"]) is not int or body["scene_generation"] < 0):
                return self._deny(400, "Ongeldige scèneversie")
            status, result = self.bridge.run(route.removeprefix("/api/action/"), scene_generation=body.get("scene_generation"))
        else: return self._deny(404, "Opdracht niet gevonden")
        return self._json(result, status)


def create_server(bridge, port=PORT, lan_ip=None):
    class BoundHandler(Handler): pass
    BoundHandler.bridge = bridge
    BoundHandler.lan_ip = lan_ip
    host = "0.0.0.0" if lan_ip else "127.0.0.1"
    server = ThreadingHTTPServer((host, port), BoundHandler)
    server.daemon_threads = True
    server.allow_reuse_address = True
    return server


def get_lan_ip():
    # Use real active macOS interface; no VPN/public address or localhost.
    for interface in ("en0", "en1", "en2"):
        try:
            out = subprocess.run(["/usr/sbin/ipconfig", "getifaddr", interface], capture_output=True,
                                 text=True, timeout=2, check=False).stdout.strip()
            ip = ipaddress.ip_address(out)
            if ip.version == 4 and ip.is_private and not ip.is_loopback and not ip.is_link_local:
                return str(ip)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            continue
    return None


def main():
    parser = argparse.ArgumentParser(description="TuxDroid 2027 local Control Center")
    parser.add_argument("--demo", action="store_true", help="Demo without USB commands")
    parser.add_argument("--no-browser", action="store_true", help="Do not open Safari")
    parser.add_argument("--lan", action="store_true", help="Allow clients on trusted local Wi-Fi without a PIN")
    args = parser.parse_args()
    lan_ip = get_lan_ip() if args.lan else None
    if args.lan and not lan_ip: raise SystemExit("Geen geschikt privé-wifi-IP gevonden (en0/en1/en2). Verbind Mac en iPhone met hetzelfde wifi-netwerk.")
    bridge = Bridge(mock=args.demo, report_dir=ROOT / "reports")
    # Always start with a passive detection + HID open/close.
    # No LED or motor output is sent on application start.
    _, scan_result = bridge.run("scan")
    if scan_result.get("found"):
        bridge.run("probe")
    try:
        httpd = create_server(bridge, lan_ip=lan_ip)
    except OSError as ex:
        raise SystemExit(f"Poort {PORT} is bezet of niet beschikbaar: {ex}")
    address = f"http://{HOST}:{PORT}"
    print(f"🐧 TuxDroid 2027 COMMAND DECK v{VERSION} — {address}")
    if lan_ip:
        print(f"📱 OPEN OP JE iPHONE/iPAD: http://{lan_ip}:{PORT}")
        print("⚠ Alleen op VERTROUWD privé-wifi. Geen PIN of HTTPS; nooit publieke wifi of portforwarding.")
    print("✅ HISTORISCHE FUNCTIEDECK — 70 vaste USB-knoppen, geen pincode of ontgrendeling.")
    if not lan_ip:
        print("Lokaal dashboard op deze machine; voor iPhone-bediening gebruikt het Mac-startscript vertrouwd privé-wifi.")
    print("Sluit af met Ctrl+C.")
    print("Volledige sessierapporten worden automatisch bewaard in de map reports naast deze app.")
    if args.demo: print("⚠ DEMO — USB-commando's worden alleen gesimuleerd.")
    def stop_requested(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop_requested)
    if not args.no_browser:
        try:
            subprocess.Popen(["open", address], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
    try:
        httpd.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        bridge.audio.stop()
        # Best effort STOP if active movement; never assume software STOP is hardware guarantee.
        if bridge.flap_active or bridge.experiment_active:
            bridge.raw_helper("stop_all", timeout=2)
        httpd.server_close()
        print("TuxDroid 2027 Control Center gestopt.")


if __name__ == "__main__":
    main()
