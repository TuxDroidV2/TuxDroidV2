"""Route macOS speech to an explicitly enumerated TuxDroid output, without fallback."""
import re
import subprocess
import threading


def parse_devices(output):
    devices = []
    seen = set()
    for line in output.splitlines():
        match = re.fullmatch(r"\s*\*?\s*(\d+)\s*:?\s+(.+?)\s*", line)
        if not match:
            continue
        number, name = int(match[1]), match[2]
        if not (0 < number < 2**32) or not re.search(r"tux[\s_-]*droid", name, re.I):
            continue
        if number in seen:
            raise ValueError("Duplicate audio device ID")
        seen.add(number)
        devices.append({"id": number, "name": name,
                        "channel": "tts" if re.search(r"\btts\b", name, re.I) else "general"})
    return devices


class MacAudio:
    def __init__(self, *, mock=False):
        self.mock = mock
        self.lock = threading.Lock()
        self.process = None
        self.generation = 0

    def epoch(self):
        with self.lock:
            return self.generation

    def devices(self):
        if self.mock:
            return {"ok": True, "simulated": True, "devices": [
                {"id": 101, "name": "TuxDroid-Audio (demo)", "channel": "general"},
                {"id": 102, "name": "TuxDroid-TTS (demo)", "channel": "tts"}],
                "message": "DEMO: geen echte audio-uitgang onderzocht"}
        try:
            result = subprocess.run(["/usr/bin/say", "-a", "?"], input="",
                                    capture_output=True, text=True, timeout=4)
            if result.returncode:
                raise ValueError("Device enumeration failed")
            devices = parse_devices(result.stdout + "\n" + result.stderr)
        except (OSError, subprocess.TimeoutExpired, ValueError, UnicodeError):
            return {"ok": False, "code": "audio_scan_failed", "devices": [],
                    "message": "Mac-audio-uitgangen konden niet worden gelezen; geen geluid afgespeeld"}
        return {"ok": True, "devices": devices,
                "message": "TuxDroid-audio-uitgangen gevonden" if devices else
                "Geen TuxDroid-audio-uitgang gevonden. Controleer de dongle bij macOS Geluidsuitvoer."}

    def resolve(self, device_id=None):
        if device_id is not None and (type(device_id) is not int or not 0 < device_id < 2**32):
            return {"ok": False, "code": "invalid_audio_device", "message": "Kies een geldige TuxDroid-audio-uitgang"}
        result = self.devices()
        if not result["ok"]:
            return result
        choices = result["devices"]
        if device_id is None:
            preferred = [d for d in choices if d["channel"] == "tts"]
            choices = preferred if preferred else choices
        else:
            choices = [d for d in choices if d["id"] == device_id]
        if len(choices) != 1:
            return {"ok": False, "code": "audio_device_missing" if not choices else "audio_device_ambiguous",
                    "message": "Kies één aanwezige TuxDroid-audio-uitgang; er wordt niet teruggevallen op de Mac-luidspreker"}
        return {"ok": True, "device": choices[0]}

    def stop(self):
        with self.lock:
            self.generation += 1
            child = self.process
            if child is not None and child.poll() is None:
                try:
                    child.terminate()
                except OSError:
                    pass

    def speak(self, text, device, *, epoch):
        # stdin prevents text beginning with '-' from becoming command-line options.
        args = ["/usr/bin/say", "-r", "165", "-f", "-"]
        if device is not None:
            args[1:1] = ["-a", str(device["id"])]
        if self.mock:
            return {"ok": True, "simulated": True, "audio_attempted": False,
                    "device": device, "message": "SIMULATIE: geen geluid of spraak afgespeeld"}
        child = None
        try:
            with self.lock:
                if epoch != self.generation:
                    return {"ok": False, "code": "audio_cancelled", "audio_attempted": False,
                            "message": "Spraak door STOP geannuleerd vóór het afspelen"}
                child = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, text=True, start_new_session=True)
                self.process = child
            try:
                child.communicate(input=text, timeout=20)
            except subprocess.TimeoutExpired:
                child.terminate()
                try:
                    child.communicate(timeout=1)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.communicate()
                return {"ok": False, "code": "audio_timeout", "audio_attempted": True,
                        "device": device, "message": "Spraak duurde te lang en is afgebroken; hoorbare uitvoering onbekend"}
            cancelled = epoch != self.epoch()
            ok = child.returncode == 0 and not cancelled
            return {"ok": ok, "code": "audio_cancelled" if cancelled else None if ok else "audio_failed",
                    "audio_attempted": True, "device": device,
                    "message": "Spraak door de gekozen audio-uitgang verwerkt; hoorbare robotreactie nog bevestigen" if ok else
                    "Spraak door STOP geannuleerd" if cancelled else "Afspelen via deze audio-uitgang mislukt; geen andere uitgang geprobeerd"}
        except (OSError, UnicodeError):
            if child is not None and child.poll() is None:
                try:
                    child.kill()
                    child.communicate()
                except (OSError, UnicodeError):
                    pass
            return {"ok": False, "code": "audio_process_failed", "audio_attempted": child is not None,
                    "device": device, "message": "Mac-spraakproces mislukt; geen andere audio-uitgang geprobeerd"}
        finally:
            with self.lock:
                if self.process is child:
                    self.process = None
