"""Build the source distribution with an explicit file list; private reports stay local."""
import argparse
import hashlib
from pathlib import Path
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from control_center import VERSION

FILES = (
    ".gitignore", "README.md", "LEESMIJ_v1.2.0.md",
    "control_center.py", "catalog.py", "attitunes.py", "audio_output.py",
    "Sources/tuxhid.m", "Sources/tux_protocol.h", "Web/index.html",
    "Start_Demo.command", "Start_TuxDroid_2027.command",
    "Docs/ORIGINELE_COMMANDOS.md", "docs/VALIDATIE_v1.2.0.md",
    "THIRD_PARTY_NOTICES.md", "licenses/GPL-2.0.txt", "docs/AUDIO_EN_DRAAIEN_v1.2.0.md",
    "Tests/test_audio_output.py", "Tests/__init__.py", "Tests/test_command_deck.py", "Tests/test_diagnostics.py",
    "Tests/test_sessions.py", "Tests/test_attitunes.py", "Tests/test_native_protocol.py",
    "Tests/native_protocol_test.c", "Tools/check_browser.py", "Tools/build_release.py",
)


def build(output):
    for relative in FILES:
        path = ROOT / relative
        if not path.is_file() or path.is_symlink():
            raise SystemExit("Missing regular source file: " + relative)
    output.mkdir(parents=True, exist_ok=True)
    target = output / f"TuxDroid_Control_Center_v{VERSION}.zip"
    if target.exists():
        raise SystemExit("Existing release preserved; choose an empty output directory")
    folder = "TuxDroid_2027_Control_Center_v" + VERSION.replace(".", "_")
    with zipfile.ZipFile(target, "w") as archive:
        for relative in FILES:
            info = zipfile.ZipInfo(folder + "/" + relative, date_time=(2026, 10, 25, 0, 0, 0))
            mode = 0o755 if relative.endswith(".command") else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, (ROOT / relative).read_bytes(),
                             compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(FILES):
            raise SystemExit("Release integrity check failed")
    target.chmod(0o644)
    checksum = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix(".zip.sha256").write_text(checksum + "  " + target.name + "\n")
    print(target)
    print(f"{len(FILES)} files; {target.stat().st_size} bytes; SHA256 {checksum}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    build(parser.parse_args().output)
