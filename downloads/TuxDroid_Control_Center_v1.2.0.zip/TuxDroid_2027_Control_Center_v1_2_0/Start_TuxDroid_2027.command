#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
printf '\n🐧 TuxDroid 2027 — Command Deck v1.2.0\n\n'
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Deze hardwareversie is voor macOS (Apple Silicon of Intel)."
  exit 1
fi
if ! xcrun --find clang >/dev/null 2>&1; then
  echo "Apple Command Line Tools ontbreken. Installeer met: xcode-select --install"
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 ontbreekt. Installeer Python 3.10+ en voer deze opdracht opnieuw uit."
  exit 1
fi
python3 - <<'PY'
import sys
if sys.version_info < (3,10):
    raise SystemExit('Python 3.10 of nieuwer is nodig.')
PY
mkdir -p bin
printf 'Bouw de native macOS HID-helper...\n'
xcrun clang -fobjc-arc -O2 -Wall -Wextra -mmacosx-version-min=12.0 \
  -framework Foundation -framework IOKit -framework CoreFoundation \
  Sources/tuxhid.m -o bin/tuxhid
chmod 700 bin/tuxhid
printf '\nStart Control Center op Mac én vertrouwd lokaal wifi (IP verschijnt hieronder, geen PIN nodig)\n'
printf 'Houd dit Terminal-venster open. Stop met Ctrl+C.\n\n'
exec python3 control_center.py --lan
