"""Read original Attitunes as data. This module never executes or extracts them."""
from io import BytesIO
import math
from pathlib import PurePosixPath
import tarfile
import xml.etree.ElementTree as ET
import zipfile

MAX_ARCHIVE_BYTES = 2 * 1024 * 1024
MAX_XML_BYTES = 512 * 1024
MAX_EXPANDED_BYTES = 32 * 1024 * 1024
MAX_SCENES = 100


class AttituneError(ValueError):
    pass


def safe_name(name):
    name = name.replace("\\", "/")
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\x00" in name:
        raise AttituneError("Ongeldig pad in het archief")
    return name


def number(value, label):
    try:
        result = float(value)
    except (ValueError, TypeError):
        raise AttituneError(f"Ongeldige {label}") from None
    if not math.isfinite(result) or not 0 <= result <= 3600:
        raise AttituneError(f"Ongeldige {label}")
    return result


def read_scene(payload, source):
    try:
        with zipfile.ZipFile(BytesIO(payload)) as archive:
            entries = archive.infolist()
            if len(entries) > 128 or sum(e.file_size for e in entries) > MAX_EXPANDED_BYTES:
                raise AttituneError("De scène is te groot om te inspecteren")
            names = [(safe_name(e.filename), e) for e in entries]
            xmls = [e for name, e in names if name.rsplit("/", 1)[-1] == "scene.xml"]
            if len(xmls) != 1 or xmls[0].file_size > MAX_XML_BYTES:
                raise AttituneError("De scène moet één scene.xml van beperkte grootte bevatten")
            text = archive.read(xmls[0]).decode("utf-8-sig")
            if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper():
                raise AttituneError("XML-entiteiten en documenttypes zijn niet ondersteund")
            scene = ET.fromstring(text)
            timeline = scene.find("body/script/timeline")
            if scene.tag != "scene" or timeline is None or len(timeline) > 1024:
                raise AttituneError("Geen geldige Attitunes-tijdlijn gevonden")
            blocks = []
            for block in timeline:
                params = {part.tag: (part.text or "") for part in block}
                command = params.get("cmd", "")
                if not command or len(command) > 80 or any(len(v) > 4096 for v in params.values()):
                    raise AttituneError("Ongeldig of te groot tijdlijnblok")
                start = number(params.get("start_time"), "starttijd")
                duration = number(params.get("duration", 0), "duur")
                blocks.append({"command": command, "start": start, "duration": duration,
                               "parameters": params})
            blocks.sort(key=lambda row: row["start"])
            return {"source": source, "name": scene.findtext("header/name") or PurePosixPath(source).stem,
                    "author": scene.findtext("header/author") or "Onbekend",
                    "language": scene.findtext("header/language") or "Onbekend",
                    "description": scene.findtext("header/description") or "",
                    "duration": number(scene.findtext("header/length"), "scèneduur"),
                    "blocks": blocks,
                    "audio_files": [name.rsplit("/", 1)[-1] for name, _ in names if name.lower().endswith(".wav")],
                    "playback_supported": False}
    except AttituneError:
        raise
    except (zipfile.BadZipFile, UnicodeError, ET.ParseError, RuntimeError, OSError, ValueError, NotImplementedError):
        raise AttituneError("De oorspronkelijke scène kon niet worden gelezen") from None


def inspect_archive(payload, filename):
    if not isinstance(payload, bytes) or not 0 < len(payload) <= MAX_ARCHIVE_BYTES:
        raise AttituneError("Kies een .att- of archiefbestand van maximaal 2 MB")
    if not isinstance(filename, str) or not filename or len(filename) > 200:
        raise AttituneError("Ongeldige bestandsnaam")
    try:
        filename.encode("utf-8")
    except UnicodeError:
        raise AttituneError("Ongeldige bestandsnaam") from None
    scenes = []
    expanded = 0

    def inspect(data, origin, depth):
        nonlocal expanded
        if depth > 3:
            raise AttituneError("Het archief heeft te veel geneste lagen")
        if zipfile.is_zipfile(BytesIO(data)):
            with zipfile.ZipFile(BytesIO(data)) as archive:
                entries = archive.infolist()
                if any(safe_name(e.filename).rsplit("/", 1)[-1] == "scene.xml" for e in entries):
                    expanded += sum(e.file_size for e in entries if safe_name(e.filename).rsplit("/", 1)[-1] == "scene.xml")
                    if expanded > MAX_EXPANDED_BYTES:
                        raise AttituneError("De gezamenlijke tijdlijnen zijn te groot")
                    scenes.append(read_scene(data, origin))
                    if len(scenes) > MAX_SCENES:
                        raise AttituneError("Maximaal 100 oorspronkelijke scènes per inspectie")
                    return
                if len(entries) > 256:
                    raise AttituneError("Te veel bestanden in dit archief")
                if sum(e.file_size for e in entries) > MAX_EXPANDED_BYTES:
                    raise AttituneError("Het uitgepakte archief is te groot")
                for entry in entries:
                    name = safe_name(entry.filename)
                    if entry.is_dir() or name.startswith("__MACOSX/"):
                        continue
                    if name.lower().endswith((".att", ".zip", ".tar", ".tar.gz", ".tgz")):
                        expanded += entry.file_size
                        if expanded > MAX_EXPANDED_BYTES or entry.file_size > MAX_EXPANDED_BYTES:
                            raise AttituneError("Het uitgepakte archief is te groot")
                        inspect(archive.read(entry), origin + "!" + name, depth + 1)
            return
        with tarfile.open(fileobj=BytesIO(data), mode="r:*") as archive:
            for index, entry in enumerate(archive):
                if index >= 256:
                    raise AttituneError("Te veel bestanden in dit archief")
                name = safe_name(entry.name)
                if entry.issym() or entry.islnk():
                    raise AttituneError("Archiefkoppelingen zijn niet ondersteund")
                expanded += entry.size
                if expanded > MAX_EXPANDED_BYTES or entry.size < 0:
                    raise AttituneError("Het uitgepakte archief is te groot")
                if entry.isfile() and name.lower().endswith((".att", ".zip", ".tar", ".tar.gz", ".tgz")):
                    inspect(archive.extractfile(entry).read(), origin + "!" + name, depth + 1)

    try:
        inspect(payload, safe_name(filename), 0)
    except AttituneError:
        raise
    except (zipfile.BadZipFile, tarfile.TarError, OSError, RuntimeError, ValueError, EOFError, NotImplementedError):
        raise AttituneError("Geen leesbaar Attitunes-archief gevonden") from None
    if not scenes:
        raise AttituneError("Geen oorspronkelijke .att-scènes gevonden in dit bestand")
    return {"ok": True, "read_only": True, "usb_commands_sent": False,
            "scene_count": len(scenes), "scenes": scenes}
