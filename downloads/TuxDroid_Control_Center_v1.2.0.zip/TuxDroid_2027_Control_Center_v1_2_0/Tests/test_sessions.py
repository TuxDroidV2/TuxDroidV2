"""Session/evidence regressions. Every native response is a test fixture: no USB."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from control_center import Bridge, VERSION, HISTORY_LIMIT


def fixture_reply(action, timeout=3):
    passive = action in {"scan", "probe", "read_input"}
    return {"ok": True, "action": action, "helper_version": VERSION,
            "found": True, "output_ready": True,
            "message": "Test fixture, no USB",
            "usb_output_reports_attempted": not passive,
            "output_reports": [] if passive else [{"fixture": "no USB"}]}


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.bridge = Bridge(mock=False)
        self.bridge.raw_helper = fixture_reply
        self.bridge.run("scan")
        self.bridge.run("probe")

    def latest(self):
        return self.bridge.report()["commands"][-1]

    def test_history_retains_failure_details_after_another_command(self):
        failure = {"ok": False, "code": "input_failed", "input_result": "0xE0005000"}
        with patch.object(self.bridge, "raw_helper", return_value=failure):
            self.assertEqual(self.bridge.run("read_input")[0], 502)
        self.bridge.run("led_on")
        commands = self.bridge.report()["commands"]
        self.assertEqual(commands[-2]["result"], failure)
        self.assertEqual(commands[-1]["action"], "led_on")
        self.assertNotEqual(commands[-2]["id"], commands[-1]["id"])
        self.assertIsNone(commands[-1]["observation"])

    def test_replies_are_copied_instead_of_later_mutated(self):
        reply = fixture_reply("led_on")
        with patch.object(self.bridge, "raw_helper", return_value=reply):
            self.bridge.run("led_on")
        reply["output_reports"].clear()
        report = self.bridge.report()
        self.assertTrue(report["commands"][-1]["result"]["output_reports"])
        report["commands"][-1]["result"]["output_reports"].clear()
        self.assertTrue(self.latest()["result"]["output_reports"])

    def test_observations_identify_attempt_not_just_action_name(self):
        self.bridge.run("led_left_on")
        first = self.latest()["id"]
        self.bridge.run("led_left_on")
        second = self.latest()["id"]
        self.bridge.run("stop_all")
        self.assertEqual(self.bridge.record_observation(first, "no_reaction", "Geen ooglicht")[0], 200)
        self.assertEqual(self.bridge.record_observation(second, "different", "Beide ogen gingen aan")[0], 200)
        by_id = {row["id"]: row for row in self.bridge.report()["commands"]}
        self.assertEqual(by_id[first]["observation"]["outcome"], "no_reaction")
        self.assertEqual(by_id[second]["observation"]["note"], "Beide ogen gingen aan")

    def test_partial_usb_failure_can_have_separate_physical_observation(self):
        reply = {**fixture_reply("flap"), "ok": False, "stop_result": "0xE00002C0"}
        with patch.object(self.bridge, "raw_helper", return_value=reply):
            self.bridge.run("flap")
        self.assertEqual(self.bridge.record_observation(self.latest()["id"], "different", "Beweging gezien, stop onzeker")[0], 200)
        row = self.latest()
        self.assertFalse(row["ok"])
        self.assertEqual(row["observation"]["outcome"], "different")

    def test_timed_out_started_helper_is_unknown_execution_not_no_execution(self):
        timeout = {"ok": False, "code": "timeout", "helper_process_started": True,
                   "usb_output_reports_attempted": None, "recovery_stop": {"attempted": True, "ok": False}}
        with patch.object(self.bridge, "raw_helper", return_value=timeout):
            self.bridge.run("flap")
        row = self.latest()
        self.assertIsNone(row["output_attempted"])
        self.assertTrue(row["can_observe"])
        self.assertEqual(self.bridge.record_observation(row["id"], "different", "Beweging gezien")[0], 200)

    def test_no_output_attempt_cannot_be_confirmed_as_hardware(self):
        self.bridge.run("probe")
        self.assertEqual(self.bridge.record_observation(self.latest()["id"], "expected")[0], 409)
        with patch.object(self.bridge, "raw_helper", return_value={"ok": False, "code": "no_binary"}):
            self.bridge.run("led_on")
        self.assertEqual(self.bridge.record_observation(self.latest()["id"], "expected")[0], 409)

    def test_demo_cannot_be_confirmed(self):
        bridge = Bridge(mock=True)
        bridge.run("stop_all")
        command_id = bridge.report()["commands"][-1]["id"]
        self.assertEqual(bridge.record_observation(command_id, "expected")[0], 409)

    def test_invalid_or_unknown_observation_is_rejected(self):
        for command_id, outcome, note in (([], "expected", ""), ("id", [], ""),
                                          ("id", "yes", ""), ("id", "different", "\x00"),
                                          ("id", "different", "\ud800"),
                                          ("id", "different", "x" * 401)):
            with self.subTest(command_id=command_id, outcome=outcome):
                self.assertEqual(self.bridge.record_observation(command_id, outcome, note)[0], 400)
        self.assertEqual(self.bridge.record_observation("unknown", "no_reaction")[0], 404)

    def test_empty_input_is_not_a_zero_or_stale_sensor_value(self):
        received = {"ok": True, "raw_hex": "01 A5", "actual_bytes": 2, "input_transport": "interrupt_callback"}
        with patch.object(self.bridge, "raw_helper", return_value=received):
            self.bridge.run("read_input")
        self.assertEqual(self.bridge.snapshot()["last_input"], "01 A5")
        empty = {"ok": False, "code": "no_input_report", "input_result": None,
                 "input_transport": "interrupt_callback", "status_request_sent": False}
        with patch.object(self.bridge, "raw_helper", return_value=empty):
            status, result = self.bridge.run("read_input")
        self.assertEqual(status, 200)
        self.assertFalse(result["ok"])
        self.assertIsNone(self.bridge.snapshot()["last_input"])
        self.assertTrue(self.bridge.snapshot()["hid_open"])
        self.assertEqual(self.bridge.report()["commands"][-2]["result"]["raw_hex"], "01 A5")

    def test_helper_version_mismatch_blocks_actions_but_not_stop(self):
        self.bridge.helper_version = "1.0.1"
        with patch.object(self.bridge, "raw_helper", side_effect=fixture_reply) as helper:
            for action in ("led_on", "read_input", "flap"):
                self.assertEqual(self.bridge.run(action)[1]["code"], "helper_version_mismatch")
            helper.assert_not_called()
            self.assertEqual(self.bridge.run("stop_all")[0], 200)
            helper.assert_called_once_with("stop_all")

    def test_input_does_not_require_output_report_size(self):
        self.bridge.output_ready = False
        self.assertEqual(self.bridge.run("led_on")[1]["code"], "wrong_report_size")
        self.assertEqual(self.bridge.run("read_input")[0], 200)

    def test_missing_device_clears_stale_connection(self):
        with patch.object(self.bridge, "raw_helper", return_value={"ok": False, "code": "wrong_device_count"}):
            self.bridge.run("led_on")
        status = self.bridge.snapshot()
        self.assertFalse(status["detected"])
        self.assertFalse(status["hid_open"])

    def test_helper_exception_releases_motor_and_usb_lock(self):
        with patch.object(self.bridge, "raw_helper", side_effect=RuntimeError("fixture")):
            self.assertEqual(self.bridge.run("flap")[1]["code"], "helper_exception")
        self.assertFalse(self.bridge.flap_active)
        self.assertFalse(self.bridge.experiment_active)
        self.assertEqual(self.bridge.run("flap")[0], 200)

    def test_any_stop_invalidates_pending_scene_steps(self):
        for stop in ("stop_all", "wings_stop", "eyes_stop", "mouth_stop", "spin_stop"):
            generation = self.bridge.stop_generation
            self.bridge.run(stop)
            with patch.object(self.bridge, "raw_helper") as helper:
                status, result = self.bridge.run("flap", scene_generation=generation)
                self.assertEqual(status, 409)
                self.assertEqual(result["code"], "scene_cancelled")
                helper.assert_not_called()
        self.assertEqual(self.bridge.run("led_on", scene_generation=self.bridge.stop_generation)[0], 200)

    def test_invalid_scene_values_do_not_send_commands(self):
        for value in (True, -1, "0", []):
            with patch.object(self.bridge, "raw_helper") as helper:
                self.assertEqual(self.bridge.run("led_on", scene_generation=value)[0], 400)
                helper.assert_not_called()

    def test_report_history_bound_is_explicit(self):
        for _ in range(HISTORY_LIMIT):
            self.bridge.run("led_on")
        report = self.bridge.report()
        self.assertEqual(len(report["commands"]), HISTORY_LIMIT)
        self.assertEqual(report["commands_truncated"], 2)
        self.assertEqual(len(report["usb"]["recent_commands"]), 20)
        self.assertNotIn(self.bridge.token, json.dumps(report))

    def test_autosave_survives_a_following_command_and_observation(self):
        with tempfile.TemporaryDirectory() as directory:
            self.bridge.report_dir = Path(directory)
            self.bridge.run("led_on")
            command_id = self.latest()["id"]
            self.bridge.run("stop_all")
            self.bridge.record_observation(command_id, "expected", "Beide ogen brandden")
            saved = json.loads((Path(directory) / "latest.json").read_text())
            observed = next(r for r in saved["commands"] if r["id"] == command_id)
            self.assertEqual(observed["observation"]["outcome"], "expected")
            self.assertTrue((Path(directory) / f"session-{self.bridge.session_id}.json").is_file())
            self.assertNotIn(self.bridge.token, json.dumps(saved))

    def test_failed_autosave_does_not_discard_downloadable_report(self):
        with tempfile.TemporaryDirectory() as directory:
            blocked = Path(directory) / "not-a-directory"
            blocked.write_text("keep")
            self.bridge.report_dir = blocked
            self.assertEqual(self.bridge.run("led_on")[0], 200)
            report = self.bridge.report()
            self.assertEqual(report["commands"][-1]["action"], "led_on")
            self.assertIn("opslaan mislukt", report["usb"]["report_error"])
            self.assertEqual(blocked.read_text(), "keep")

    def test_host_speech_is_not_a_robot_output_attempt(self):
        self.bridge.mock = True
        self.bridge.speak("Hallo")
        row = self.latest()
        self.assertEqual(row["kind"], "host_audio")
        self.assertFalse(row["output_attempted"])
        self.assertFalse(row["can_observe"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
