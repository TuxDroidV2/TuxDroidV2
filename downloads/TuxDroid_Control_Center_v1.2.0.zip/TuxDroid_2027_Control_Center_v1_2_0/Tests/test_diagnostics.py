"""Diagnostic API regression checks; native helper replies are mocked, no USB."""
import http.client
import json
from pathlib import Path
import sys
import threading
import tempfile
import subprocess
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from control_center import Bridge, VERSION, create_server


class DiagnosticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bridge = Bridge(mock=True)
        cls.server = create_server(cls.bridge, port=0)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(3)

    def setUp(self):
        self.bridge.mock = True
        self.bridge.helper_version = VERSION
        self.bridge.output_ready = True
        self.bridge.led_diagnostic_feedback.clear()
        self.bridge.last_response = None

    def request(self, method, path, body=None):
        host = f"127.0.0.1:{self.port}"
        headers = {"Origin": "http://" + host,
                   "X-Tux-Token": self.bridge.token}
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            conn.request(method, path, json.dumps(body) if body is not None else None,
                         headers=headers)
            response = conn.getresponse()
            return response.status, json.loads(response.read())
        finally:
            conn.close()

    def stage_test(self, action="led_test_left", ok=True):
        # This stages a recorded native reply, without starting a helper process.
        self.bridge.mock = False
        self.bridge.last_response = {"action": action, "ok": ok,
                                     "result": {"ok": ok}}

    def test_malformed_action_returns_400_and_server_keeps_working(self):
        for action in ([], {}, 1, None):
            with self.subTest(action=action):
                status, _ = self.request("POST", "/api/led-test-feedback",
                                         {"action": action, "worked": True})
                self.assertEqual(status, 400)
        self.assertEqual(self.request("GET", "/api/status")[0], 200)

    def test_audio_routes_and_simulation_keep_robot_and_host_separate(self):
        status, devices = self.request("GET", "/api/audio/devices")
        self.assertEqual(status, 200)
        self.assertTrue(devices["simulated"])
        self.assertEqual([d["id"] for d in devices["devices"]], [101, 102])
        status, reply = self.request("POST", "/api/speak", {"text": "Hallo", "device_id": 102})
        self.assertEqual(status, 200)
        self.assertEqual(reply["target"], "robot")
        self.assertFalse(reply["audio_attempted"])
        self.assertEqual(reply["device"]["id"], 102)
        status, reply = self.request("POST", "/api/speak", {"text": "Hallo", "target": "host"})
        self.assertEqual(status, 200)
        self.assertEqual(reply["target"], "host")
        for body in ({"text": "Hallo", "device_id": "102"}, {"text": "Hallo", "target": []},
                     {"text": "Hallo", "target": "host", "device_id": 102}, {"text": "Hallo", "path": "/tmp/a"}):
            self.assertIn(self.request("POST", "/api/speak", body)[0], {400, 409})
        self.assertEqual(self.request("POST", "/api/audio/stop", {})[0], 200)
        self.assertEqual(self.request("POST", "/api/audio/stop", {"device_id": 102})[0], 400)

    def test_internal_audio_preparation_is_not_a_raw_action_endpoint(self):
        self.assertEqual(self.request("POST", "/api/action/audio_channel_tts", {})[0], 400)

    def test_demo_cannot_record_physical_confirmation(self):
        self.bridge.last_response = {"action": "led_test_left", "ok": True}
        self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                     {"action": "led_test_left", "worked": True})[0], 409)

    def test_positive_and_negative_observation_saved_in_report(self):
        for worked in (True, False):
            with self.subTest(worked=worked):
                self.stage_test()
                self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                             {"action": "led_test_left", "worked": worked})[0], 200)
                status, report = self.request("GET", "/api/report")
                self.assertEqual(status, 200)
                self.assertIs(report["usb"]["led_diagnostic_feedback"]["led_test_left"], worked)

    def test_failed_or_stale_test_cannot_be_confirmed(self):
        for action, ok in (("led_test_left", False), ("stop_all", True)):
            with self.subTest(action=action, ok=ok):
                self.stage_test(action, ok)
                self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                             {"action": "led_test_left", "worked": True})[0], 409)

    def test_non_boolean_observation_is_rejected(self):
        self.stage_test()
        self.assertEqual(self.request("POST", "/api/led-test-feedback",
                                     {"action": "led_test_left", "worked": "false"})[0], 400)

    def test_repeated_diagnosis_does_not_reuse_previous_observation(self):
        self.stage_test()
        self.bridge.detected = self.bridge.hid_open = True
        self.request("POST", "/api/led-test-feedback",
                     {"action": "led_test_left", "worked": True})
        with patch.object(self.bridge, "raw_helper", return_value={"ok": True}):
            self.assertEqual(self.request("POST", "/api/action/led_test_left", {})[0], 200)
        status, report = self.request("GET", "/api/report")
        self.assertEqual(status, 200)
        self.assertNotIn("led_test_left", report["usb"]["led_diagnostic_feedback"])

    def test_ir_failures_are_preserved_in_api_and_report(self):
        self.bridge.detected = self.bridge.hid_open = True
        reply = {"ok": False, "write_result": "0xE00002C0",
                 "ir_on_result": "0xE00002C0", "ir_off_result": "0xE00002C7",
                 "message": "IR-uit mislukt"}
        with patch.object(self.bridge, "raw_helper", return_value=reply):
            status, result = self.request("POST", "/api/action/ir_on", {})
        self.assertEqual(status, 502)
        self.assertEqual(result, reply)
        report = self.request("GET", "/api/report")[1]
        self.assertEqual(report["usb"]["last_response"]["result"], reply)

    def test_native_allowlist_rejects_before_device_access(self):
        # Source-level invariant only; actual IOKit compilation requires macOS.
        source = (ROOT / "Sources/tuxhid.m").read_text()
        gate = source.index('if (![allowed containsObject:action])')
        self.assertLess(gate, source.index("IOHIDManagerCreate("))
        self.assertIn('return fail(@"invalid_action"', source[gate:gate + 160])

    def test_observation_endpoint_validates_shape_and_demo_proof(self):
        self.bridge.run("scan")
        self.bridge.run("probe")
        self.bridge.run("led_on")
        command_id = self.bridge.last_response["id"]
        self.assertEqual(self.request("POST", "/api/observation", {"command_id": command_id})[0], 400)
        self.assertEqual(self.request("POST", "/api/observation",
                                     {"command_id": command_id, "outcome": "expected", "note": ""})[0], 409)

    def test_scene_generation_endpoint_rejects_stale_or_invalid_steps(self):
        self.bridge.run("scan")
        self.bridge.run("probe")
        generation = self.bridge.stop_generation
        self.request("POST", "/api/action/stop_all", {})
        before = self.bridge.flaps
        self.assertEqual(self.request("POST", "/api/action/flap", {"scene_generation": generation})[0], 409)
        self.assertEqual(self.bridge.flaps, before)
        for value in (True, None, -1, "0"):
            self.assertEqual(self.request("POST", "/api/action/flap", {"scene_generation": value})[0], 400)

    def test_non_ascii_browser_token_is_denied_without_crashing(self):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            conn.request("POST", "/api/action/scan", "{}", headers={
                "Origin": f"http://127.0.0.1:{self.port}", "X-Tux-Token": "é"})
            response = conn.getresponse()
            self.assertEqual(response.status, 403)
            response.read()
        finally:
            conn.close()

    def test_native_json_requires_real_boolean_and_matching_action(self):
        with tempfile.TemporaryDirectory() as directory:
            helper = Path(directory) / "fake-helper"
            helper.write_text("fixture, never executed")
            bridge = Bridge(helper=helper)
            for payload in ({"ok": "false"}, {"ok": True, "action": "different"}, []):
                with self.subTest(payload=payload), patch("control_center.subprocess.Popen") as popen:
                    popen.return_value.communicate.return_value = (json.dumps(payload), "")
                    popen.return_value.returncode = 0
                    self.assertEqual(bridge.raw_helper("led_on")["code"], "bad_native_output")

    def test_timeout_records_actual_recovery_stop_result(self):
        with tempfile.TemporaryDirectory() as directory:
            helper = Path(directory) / "fake-helper"
            helper.write_text("fixture, never executed")
            bridge = Bridge(helper=helper)
            with patch("control_center.subprocess.Popen") as popen, patch("control_center.subprocess.run") as stop:
                popen.return_value.communicate.side_effect = [subprocess.TimeoutExpired("fixture", 3), ("", "")]
                stop.return_value.returncode = 0
                stop.return_value.stdout = json.dumps({"ok": True, "stop_results": {"0x30": "0x00000000"}})
                result = bridge.raw_helper("flap")
                self.assertEqual(result["code"], "timeout")
                self.assertIsNone(result["usb_output_reports_attempted"])
                self.assertTrue(result["helper_process_started"])
                self.assertTrue(result["recovery_stop"]["attempted"])
                self.assertTrue(result["recovery_stop"]["ok"])
                self.assertEqual(stop.call_args.args[0], [str(helper), "stop_all"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
