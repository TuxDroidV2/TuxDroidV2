"""Historical .att data inspection; fixtures are never executed."""
import io
from pathlib import Path
import sys
import tarfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from attitunes import inspect_archive, AttituneError, MAX_ARCHIVE_BYTES

SCENE = '''<?xml version="1.0" encoding="UTF-8"?><scene><header>
<name>Testscène</name><author>Fixture</author><language>Be Dutch</language><length>2.5</length>
</header><body><script><timeline>
<block_2><cmd>wav_play</cmd><start_time>1.0</start_time><duration>1.5</duration><wav_name>test.wav</wav_name></block_2>
<block_1><cmd>leds_on</cmd><start_time>0.0</start_time><duration>0.5</duration></block_1>
</timeline></script></body></scene>'''


def scene_archive(xml=SCENE, name="scene\\scene.xml"):
    data = io.BytesIO()
    with zipfile.ZipFile(data, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(name, xml)
        archive.writestr("scene\\wavs\\test.wav", b"test fixture, not audio")
    return data.getvalue()


class AttituneTests(unittest.TestCase):
    def test_original_windows_paths_and_timeline_order(self):
        result = inspect_archive(scene_archive(), "demo.att")
        self.assertTrue(result["read_only"])
        self.assertFalse(result["usb_commands_sent"])
        row = result["scenes"][0]
        self.assertEqual(row["name"], "Testscène")
        self.assertEqual([b["command"] for b in row["blocks"]], ["leds_on", "wav_play"])
        self.assertEqual(row["audio_files"], ["test.wav"])
        self.assertFalse(row["playback_supported"])

    def test_zip_containing_tar_containing_multiple_scenes(self):
        tar = io.BytesIO()
        with tarfile.open(fileobj=tar, mode="w:gz") as archive:
            for name in ("first.att", "second.att"):
                data = scene_archive()
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                archive.addfile(entry, io.BytesIO(data))
        container = io.BytesIO()
        with zipfile.ZipFile(container, "w") as archive:
            archive.writestr("Attitunes.tar.gz", tar.getvalue())
        result = inspect_archive(container.getvalue(), "attitunes.zip")
        self.assertEqual(result["scene_count"], 2)

    def test_entity_or_document_type_is_rejected(self):
        xml = '<!DOCTYPE scene [<!ENTITY x SYSTEM "file:///etc/passwd">]>' + SCENE
        with self.assertRaises(AttituneError):
            inspect_archive(scene_archive(xml), "bad.att")

    def test_path_traversal_is_rejected_without_extracting_files(self):
        with self.assertRaises(AttituneError):
            inspect_archive(scene_archive(name="../scene.xml"), "bad.att")

    def test_non_finite_negative_and_missing_times_are_rejected(self):
        for value in ("NaN", "Infinity", "-1", ""):
            with self.subTest(value=value), self.assertRaises(AttituneError):
                inspect_archive(scene_archive(SCENE.replace("<start_time>1.0", "<start_time>" + value)), "bad.att")

    def test_invalid_or_oversized_archive_is_rejected(self):
        for payload in (b"", b"not an archive", b"x" * (MAX_ARCHIVE_BYTES + 1)):
            with self.assertRaises(AttituneError):
                inspect_archive(payload, "bad.att")

    def test_a_jar_or_empty_archive_is_not_mistaken_for_a_scene(self):
        data = io.BytesIO()
        with zipfile.ZipFile(data, "w") as archive:
            archive.writestr("Example.class", b"fixture")
        with self.assertRaises(AttituneError):
            inspect_archive(data.getvalue(), "program.jar")


if __name__ == "__main__":
    unittest.main(verbosity=2)
