"""Compile and execute the portable code used by the real macOS helper; no USB."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class NativeProtocolTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("cc"), "C compiler required for native protocol checks")
    def test_proven_output_layout_and_input_capture(self):
        with tempfile.TemporaryDirectory(prefix="tux-protocol-") as directory:
            binary = Path(directory) / "protocol-check"
            subprocess.run([shutil.which("cc"), "-std=c11", "-Wall", "-Wextra", "-Werror",
                            str(ROOT / "Tests/native_protocol_test.c"), "-o", str(binary)], check=True)
            result = subprocess.run([str(binary)], capture_output=True, text=True, check=True)
            self.assertIn("Native protocol core passed", result.stdout)

    def test_native_input_uses_documented_callback_and_no_control_get(self):
        source = (ROOT / "Sources/tuxhid.m").read_text()
        self.assertNotIn("IOHIDDeviceGetReport(", source)
        self.assertIn("IOHIDDeviceRegisterInputReportCallback(", source)
        region = source.split("static NSDictionary *readInputReport(", 1)[1].split("static NSDictionary *safePulse(", 1)[0]
        self.assertNotIn("sendOpcode(", region)
        self.assertNotIn("IOHIDDeviceSetReport(", region)
        self.assertIn("IOHIDDeviceUnscheduleFromRunLoop(", region)
        self.assertIn("no_input_report", region)


if __name__ == "__main__":
    unittest.main(verbosity=2)
