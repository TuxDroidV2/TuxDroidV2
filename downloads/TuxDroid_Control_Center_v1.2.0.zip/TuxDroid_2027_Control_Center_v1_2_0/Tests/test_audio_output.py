"""No audio or hardware is used: OS discovery/processes and USB are fixtures."""
import json
import subprocess
import threading
import unittest
from unittest.mock import Mock, patch

from audio_output import MacAudio, parse_devices
from control_center import Bridge, VERSION


OUTPUTS = "  41 Built-in Output\n  47 TuxDroid-Audio\n  48 TuxDroid-TTS\n"


def usb_reply(action, timeout=3):
    return {"ok": True, "found": True, "output_ready": True,
            "helper_version": VERSION, "action": action,
            "usb_output_reports_attempted": action.startswith("audio_channel_"),
            "message": "USB fixture; nothing sent"}


class AudioTests(unittest.TestCase):
    def setUp(self):
        self.audio = MacAudio()
        self.child = Mock()
        self.child.returncode = 0
        self.child.poll.return_value = None
        self.child.communicate.return_value = ("", "")

    def test_parser_only_keeps_named_tuxdroid_outputs(self):
        devices = parse_devices(OUTPUTS + " 49: Tux Droid USB Audio\n")
        self.assertEqual([d["id"] for d in devices], [47, 48, 49])
        self.assertEqual([d["channel"] for d in devices], ["general", "tts", "general"])

    def test_duplicate_ids_do_not_create_an_ambiguous_route(self):
        with self.assertRaises(ValueError):
            parse_devices("47 TuxDroid-Audio\n47 TuxDroid-TTS")

    def test_discovery_is_passive_and_has_no_speech_input(self):
        with patch("audio_output.subprocess.run", return_value=Mock(returncode=0, stdout=OUTPUTS, stderr="")) as run:
            self.assertEqual(len(self.audio.devices()["devices"]), 2)
            self.assertEqual(run.call_args.args[0], ["/usr/bin/say", "-a", "?"])
            self.assertEqual(run.call_args.kwargs["input"], "")

    def test_prefer_tts_and_validate_explicit_device_against_fresh_scan(self):
        with patch.object(self.audio, "devices", return_value={"ok": True, "devices": parse_devices(OUTPUTS)}):
            self.assertEqual(self.audio.resolve()["device"]["id"], 48)
            self.assertEqual(self.audio.resolve(47)["device"]["channel"], "general")
            self.assertFalse(self.audio.resolve(41)["ok"])
            self.assertFalse(self.audio.resolve(999)["ok"])

    def test_missing_ambiguous_and_invalid_devices_never_choose_mac_default(self):
        for bad in (True, "47", [], {}, -1, 2**32):
            self.assertFalse(self.audio.resolve(bad)["ok"])
        with patch.object(self.audio, "devices", return_value={"ok": True, "devices": []}):
            self.assertEqual(self.audio.resolve()["code"], "audio_device_missing")
        choices = parse_devices("47 TuxDroid-Audio\n49 TuxDroid USB")
        with patch.object(self.audio, "devices", return_value={"ok": True, "devices": choices}):
            self.assertEqual(self.audio.resolve()["code"], "audio_device_ambiguous")

    def test_scan_failures_are_errors_not_default_output(self):
        for failure in (FileNotFoundError(), subprocess.TimeoutExpired("say", 4)):
            with patch("audio_output.subprocess.run", side_effect=failure):
                self.assertFalse(self.audio.devices()["ok"])

    def test_selected_device_is_explicit_and_user_text_cannot_be_options(self):
        with patch("audio_output.subprocess.Popen", return_value=self.child) as popen:
            result = self.audio.speak("-n example.invalid", {"id": 48}, epoch=0)
        args = popen.call_args.args[0]
        self.assertEqual(args, ["/usr/bin/say", "-a", "48", "-r", "165", "-f", "-"])
        self.assertEqual(self.child.communicate.call_args.kwargs["input"], "-n example.invalid")
        self.assertTrue(result["ok"])

    def test_failed_playback_does_not_retry_on_mac(self):
        self.child.returncode = 1
        with patch("audio_output.subprocess.Popen", return_value=self.child) as popen:
            result = self.audio.speak("Hallo", {"id": 48}, epoch=0)
        self.assertFalse(result["ok"])
        self.assertEqual(popen.call_count, 1)

    def test_stop_before_playback_prevents_process_creation(self):
        self.audio.stop()
        with patch("audio_output.subprocess.Popen") as popen:
            result = self.audio.speak("Hallo", {"id": 48}, epoch=0)
        popen.assert_not_called()
        self.assertFalse(result["audio_attempted"])
        self.assertEqual(result["code"], "audio_cancelled")

    def test_stop_during_playback_terminates_owned_process_and_records_cancel(self):
        self.child.communicate.side_effect = lambda **kw: self.audio.stop()
        with patch("audio_output.subprocess.Popen", return_value=self.child):
            result = self.audio.speak("Hallo", {"id": 48}, epoch=0)
        self.child.terminate.assert_called_once()
        self.assertEqual(result["code"], "audio_cancelled")
        self.assertIsNone(self.audio.process)

    def test_timeout_terminates_then_kills_only_owned_process(self):
        self.child.communicate.side_effect = [subprocess.TimeoutExpired("say", 20),
                                              subprocess.TimeoutExpired("say", 1), ("", "")]
        with patch("audio_output.subprocess.Popen", return_value=self.child):
            result = self.audio.speak("Hallo", {"id": 48}, epoch=0)
        self.assertEqual(result["code"], "audio_timeout")
        self.assertTrue(result["audio_attempted"])
        self.child.kill.assert_called_once()


class RobotSpeechTests(unittest.TestCase):
    def setUp(self):
        self.bridge = Bridge(mock=False)
        self.bridge.raw_helper = Mock(side_effect=usb_reply)
        self.bridge.run("scan")
        self.bridge.run("probe")
        self.bridge.raw_helper.reset_mock()
        self.devices = patch.object(self.bridge.audio, "devices", return_value={"ok": True, "devices": parse_devices(OUTPUTS)})
        self.devices.start()
        self.addCleanup(self.devices.stop)
        self.play = patch.object(self.bridge.audio, "speak", return_value={"ok": True, "audio_attempted": True, "message": "Audio fixture"})
        self.speak = self.play.start()
        self.addCleanup(self.play.stop)

    def test_robot_speech_prepares_correct_channel_and_has_no_text_in_report(self):
        status, result = self.bridge.speak("Privé voorbeeld", target="robot", device_id=48)
        self.assertEqual(status, 200)
        self.bridge.raw_helper.assert_called_once_with("audio_channel_tts")
        self.assertEqual(self.speak.call_args.args[1]["id"], 48)
        self.assertNotIn("Privé voorbeeld", json.dumps(self.bridge.report()))
        row = self.bridge.report()["commands"][-1]
        self.assertEqual(row["kind"], "robot_audio")
        self.assertTrue(row["can_observe"])
        self.assertIsNone(row["observation"])
        self.assertEqual(self.bridge.record_observation(row["id"], "no_reaction", "Geen geluid")[0], 200)

    def test_general_device_selects_general_channel(self):
        self.assertEqual(self.bridge.speak("Hallo", target="robot", device_id=47)[0], 200)
        self.bridge.raw_helper.assert_called_once_with("audio_channel_general")

    def test_missing_device_prevents_usb_preparation_and_playback(self):
        self.assertEqual(self.bridge.speak("Hallo", target="robot", device_id=41)[0], 409)
        self.bridge.raw_helper.assert_not_called()
        self.speak.assert_not_called()

    def test_missing_connection_and_wrong_helper_prevent_audio(self):
        self.bridge.helper_version = "1.1.0"
        self.assertEqual(self.bridge.speak("Hallo", target="robot")[0], 409)
        self.bridge.raw_helper.assert_not_called()
        self.speak.assert_not_called()
        self.bridge.helper_version = VERSION
        self.bridge.hid_open = False
        self.assertEqual(self.bridge.speak("Hallo", target="robot")[0], 409)
        self.speak.assert_not_called()

    def test_usb_preparation_failure_never_starts_speech(self):
        self.bridge.raw_helper.side_effect = lambda action: {"ok": False, "code": "open_failed", "message": "USB failure"}
        status, result = self.bridge.speak("Hallo", target="robot")
        self.assertEqual(status, 502)
        self.assertEqual(result["code"], "audio_prepare_failed")
        self.speak.assert_not_called()

    def test_stop_during_device_discovery_cancels_before_usb(self):
        def discover():
            self.bridge.audio.stop()
            return {"ok": True, "devices": parse_devices(OUTPUTS)}
        with patch.object(self.bridge.audio, "devices", side_effect=discover):
            status, result = self.bridge.speak("Hallo", target="robot")
        self.assertEqual(status, 409)
        self.assertEqual(result["code"], "audio_cancelled")
        self.bridge.raw_helper.assert_not_called()
        self.speak.assert_not_called()

    def test_stop_during_channel_preparation_cancels_audio_process(self):
        self.play.stop()
        def prepare(action):
            self.bridge.audio.stop()
            return usb_reply(action)
        self.bridge.raw_helper.side_effect = prepare
        with patch("audio_output.subprocess.Popen") as popen:
            status, result = self.bridge.speak("Hallo", target="robot")
        self.assertEqual(status, 409)
        self.assertEqual(result["code"], "audio_cancelled")
        popen.assert_not_called()

    def test_host_is_separate_and_does_not_prepare_robot_channel(self):
        self.assertEqual(self.bridge.speak("Hallo", target="host")[0], 200)
        self.bridge.raw_helper.assert_not_called()
        self.assertIsNone(self.speak.call_args.args[1])
        self.assertFalse(self.bridge.report()["commands"][-1]["can_observe"])

    def test_extra_audio_requests_and_markup_do_not_create_processes(self):
        for text in ("[[slnc 999999]]", "bad\ntext", "", None):
            self.assertEqual(self.bridge.speak(text, target="robot")[0], 400)
        self.assertEqual(self.bridge.speak("Hallo", target=[])[0], 400)
        self.bridge.raw_helper.assert_not_called()
        self.speak.assert_not_called()

    def test_busy_audio_rejects_second_call_and_releases_after_error(self):
        self.bridge.audio_lock.acquire()
        try:
            self.assertEqual(self.bridge.speak("Hallo", target="robot")[0], 409)
        finally:
            self.bridge.audio_lock.release()
        self.assertEqual(self.bridge.speak("Hallo", target="robot", device_id=41)[0], 409)
        self.assertFalse(self.bridge.audio_lock.locked())

    def test_internal_channels_are_not_public_usb_actions(self):
        self.assertEqual(self.bridge.run("audio_channel_tts")[0], 400)
        self.bridge.raw_helper.assert_not_called()

    def test_motor_stops_also_cancel_audio(self):
        before = self.bridge.audio.epoch()
        self.bridge.run("spin_stop")
        self.assertGreater(self.bridge.audio.epoch(), before)


if __name__ == "__main__":
    unittest.main()
