#include <assert.h>
#include <stdio.h>
#include "../Sources/tux_protocol.h"

int main(void) {
    assert(TUX_OUTPUT_BYTES == 64);
    uint8_t report[TUX_OUTPUT_BYTES];
    memset(report, 0xFF, sizeof(report));
    tux_output_report(report, 0x80, 1, 1);
    const uint8_t wing[] = {0x00, 0x80, 0x01, 0x01, 0x00};
    assert(memcmp(report, wing, sizeof(wing)) == 0);
    for (size_t i = 5; i < sizeof(report); ++i) assert(report[i] == 0);
    tux_output_report(report, 0x1A, 0, 0);
    assert(report[0] == 0 && report[1] == 0x1A);
    for (size_t i = 2; i < sizeof(report); ++i) assert(report[i] == 0);
    tux_output_report(report, 0x30, 0, 0);
    assert(report[1] == 0x30 && report[2] == 0 && report[3] == 0);

    /* Golden bytes traced from OEM C, not the former Ruby constants.
       tux_audio.c + tux_usb.c: dongle channel selection. */
    tux_addressed_report(report, 1, 2, 1, 0, 0);
    const uint8_t tts_channel[] = {1, 2, 1, 0, 0};
    assert(memcmp(report, tts_channel, 5) == 0);
    for (size_t i = 5; i < sizeof(report); ++i) assert(report[i] == 0);
    assert(tux_flash_attenuation(0) == 7);
    assert(tux_flash_attenuation(50) == 4);
    assert(tux_flash_attenuation(80) == 2);
    assert(tux_flash_attenuation(100) == 0);
    assert(tux_flash_attenuation(255) == 0);
    const uint8_t first_sound[] = {0, 0x90, 1, 2, 0};
    const uint8_t last_sound[] = {0, 0x90, 8, 2, 0};
    tux_sound_report(report, 0);
    assert(memcmp(report, first_sound, 5) == 0);
    tux_sound_report(report, 7);
    assert(memcmp(report, last_sound, 5) == 0);
    /* OEM: motor 4=left, 3=right; time flag 1, sixty 4 ms ticks. */
    const uint8_t config_left[] = {0, 0x81, 4, 3, 0};
    const uint8_t move_left[] = {0, 0xD4, 4, 60, 1};
    const uint8_t config_right_fast[] = {0, 0x81, 3, 5, 0};
    const uint8_t move_right[] = {0, 0xD4, 3, 60, 1};
    tux_spin_report(report, true, false, false);
    assert(memcmp(report, config_left, 5) == 0);
    tux_spin_report(report, true, false, true);
    assert(memcmp(report, move_left, 5) == 0);
    tux_spin_report(report, false, true, false);
    assert(memcmp(report, config_right_fast, 5) == 0);
    tux_spin_report(report, false, true, true);
    assert(memcmp(report, move_right, 5) == 0);
    for (size_t i = 5; i < sizeof(report); ++i) assert(report[i] == 0);

    struct tux_input_capture capture = {0};
    capture.limit = 64;
    assert(capture.state == TUX_INPUT_WAITING && capture.length == 0);
    uint8_t data[65];
    for (size_t i = 0; i < sizeof(data); ++i) data[i] = (uint8_t)(i ^ 0xA5);
    tux_capture_input(&capture, 0, 7, data, 64);
    assert(capture.state == TUX_INPUT_RECEIVED && capture.length == 64);
    assert(capture.report_id == 7 && memcmp(capture.bytes, data, 64) == 0);
    tux_capture_input(&capture, -1, 99, data, 65);
    assert(capture.state == TUX_INPUT_RECEIVED && capture.report_id == 7);

    capture = (struct tux_input_capture){.limit = 64};
    tux_capture_input(&capture, (int32_t)0xE0005000, 2, NULL, -1);
    assert(capture.state == TUX_INPUT_FAILED && capture.length == 0);
    assert((uint32_t)capture.result == 0xE0005000 && capture.report_id == 2);
    const ptrdiff_t invalid_lengths[] = {-1, 0, 65, TUX_INPUT_CAPACITY + 1};
    for (size_t i = 0; i < sizeof(invalid_lengths) / sizeof(invalid_lengths[0]); ++i) {
        capture = (struct tux_input_capture){.limit = 64};
        tux_capture_input(&capture, 0, 0, data, invalid_lengths[i]);
        assert(capture.state == TUX_INPUT_INVALID && capture.length == 0);
    }
    capture = (struct tux_input_capture){.limit = 64};
    tux_capture_input(&capture, 0, 0, NULL, 1);
    assert(capture.state == TUX_INPUT_INVALID && capture.length == 0);
    capture = (struct tux_input_capture){.limit = 1};
    tux_capture_input(&capture, 0, 0, data, 1);
    assert(capture.state == TUX_INPUT_RECEIVED && capture.length == 1);
    assert(capture.bytes[0] == data[0]);
    puts("Native protocol core passed: known output bytes, padding, input data, errors and bounds.");
    return 0;
}
