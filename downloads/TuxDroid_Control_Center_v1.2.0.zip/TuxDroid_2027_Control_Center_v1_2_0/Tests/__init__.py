"""Regression fixtures and tests for the current Control Center."""
