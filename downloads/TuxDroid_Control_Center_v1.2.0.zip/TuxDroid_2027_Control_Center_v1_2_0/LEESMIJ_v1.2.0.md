# Control Center v1.2.0 — gericht herstel van geluid, TTS en draaien

Deze versie verwerkt de nieuw gevonden historische C-driver. De belangrijke
wijzigingen zitten in de aansturing: geldige tracknummers en volumebytes,
expliciete TuxDroid-audiokeuze en OEM-motorconfiguratie voor een korte draaipuls.
Alle 70 bestaande actie-ID's blijven aanwezig. De eerdere verbeteringen aan
rapporten, STOP, scènes en Attitunes-inspectie blijven behouden.

## Starten op de Mac

Stop de oude server met Ctrl+C. Pak het ZIP-bestand uit in Downloads en voer uit:

```bash
cd "$HOME/Downloads/TuxDroid_2027_Control_Center_v1_2_0"
bash Start_TuxDroid_2027.command
```

Het script bouwt de nieuwe helper en opent het dashboard. Python 3.10+ en
Apple Command Line Tools zijn nodig. Gebruik de originele dongle en vertrouwd
privé-wifi. Het starten verstuurt uitsluitend detectie en HID-open/sluit,
geen geluid, motor- of andere actieopdracht.

## Geluid en TTS

Bij **Spraak & geluid** zoekt de app naar TuxDroid-audio-uitgangen. Kies de
uitgang van je dongle. **Spreek via TuxDroid** en **Geluidsproef** kiezen deze
audio-uitgang expliciet en bereiden het bijbehorende donglekanaal voor.
De geluidsproef gebruikt een korte testzin en is onafhankelijk van de inhoud
van het oorspronkelijke flashgeheugen.

Ontbreekt een TuxDroid-uitgang, bekijk dan op de Mac **Systeeminstellingen →
Geluid → Uitvoer**. De app toont een fout als de gekozen uitgang ontbreekt of
verdwijnt; hij probeert geen andere uitgang. De afzonderlijke Mac- en
browserknoppen blijven beschikbaar. **Stop spraak** stopt het eigen
Mac-spraakproces. Alle motor-STOP-knoppen annuleren ook de lopende spraak.

De acht opgeslagen-geluidknoppen hebben nu nummers 1–8. Hun bestaande API-ID's
`sound_0` t/m `sound_7` worden vertaald naar de juiste, bij 1 beginnende
firmwaretracks. Track 0 is in de gelezen firmware geen afspeelbare track.
Voor 80% volume wordt nu parameterbyte 2 gebruikt, in plaats van de ongeldige
directe waarde 80. Er worden geen geluiden opgeslagen of geflasht.
Een lege geluidsbank blijft stil, ook bij een correct commando.

## Draaien

De draaiknoppen versturen de OEM-motorconfiguratie en daarna een tijdbegrensde
bewegingsopdracht: 240 ms volgens de referentiefirmware, gevolgd door een
onafhankelijke STOP-poging met een hostdoel van 300 ms. De twee snelheden zijn
3 en 5 uit de oorspronkelijke reeks 1–5. De labels beloven geen 90° of hele
cirkel. Werkelijke richting, beweging, hoek en stoptijd moeten op de robot
worden vastgesteld. Houd fysiek uitschakelen mogelijk bij een fysieke proef.

## Rapport en bewijs

Bij **Waarnemingen** kun je een hoorbare of mechanische reactie bij een
specifieke echte poging vastleggen. Het rapport bevat de exacte USB-pakketten,
audio-uitgang, kanaalkeuze en fouten. Ingevoerde spreektekst wordt niet in
het sessierapport opgeslagen. Onder **Diagnose** kun je het rapport downloaden;
de app bewaart het tevens lokaal in `reports/`.

De softwarecontroles slagen: 100 Python-tests en 22 browsercontroles, inclusief
het echt compileren en uitvoeren van de gedeelde C-protocolkern. Zie
[validatie](docs/VALIDATIE_v1.2.0.md) en
[de bronketen](docs/AUDIO_EN_DRAAIEN_v1.2.0.md).

De volledige Mac-helper is hier niet op macOS gecompileerd. De echte
USB-audioroute en draaipuls zijn hier niet fysiek getest. De driverbron maakt
de wijzigingen onderbouwd, maar bewijst niet welke firmware op jouw robot
draait of dat de functies nu fysiek werken. Afzonderlijke leds, IR,
ooglidherstel, sensordecodering en originele Attitunes-uitvoering zijn in deze
versie niet hersteld of als gereed verklaard.
