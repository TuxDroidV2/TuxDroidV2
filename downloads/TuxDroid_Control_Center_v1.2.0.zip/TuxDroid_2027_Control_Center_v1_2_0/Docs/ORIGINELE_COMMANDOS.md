# Originele TuxDroid-opdrachten · Command Deck v1.0

**70 toegestane USB-acties, 36 statusnamen, 58 ontdubbelde archiefgadgets.**

Bron: originele GPL-2.0 Ruby commandotabel; aanvullende vaste snelheidswaarden uit bijbehorende methoden. Alleen bekende commando-identifiers, geen willekeurige USB-invoer.

## Verbinding

| Knop | Actie-ID | Originele code | Status | Toelichting |
|---|---|---|---|---|
| Zoek USB-dongle | scan | USB | bewezen | Zoekt de originele 03EB:FF07-dongle |
| Test HID-verbinding | probe | HID | bewezen | Opent en sluit de originele interface |
| STOP ALLE MOTOREN | stop_all | 0x30/32/36/37 | proef | Stuurt alle STOP-commando’s |

## Verlichting

| Knop | Actie-ID | Originele code | Status | Toelichting |
|---|---|---|---|---|
| Beide ogen aan | led_on | 0x1A | bewezen | Blauwe verlichting aan |
| Beide ogen uit | led_off | 0x1B | bewezen | Blauwe verlichting uit |
| Blauwe ogen knipperen | led_blink | 0x1A/1B | bewezen | Korte blink via aan/uit |
| Firmware LED-knipper | led_firmware_blink | 0x9A | proef | Originele knipperopdracht · 3 cycli |
| Links aan | led_left_on | 0x1C | afwijking | Afzonderlijke LED: reageerde eerder niet |
| Links uit | led_left_off | 0x1D | afwijking | Afzonderlijke LED: reageerde eerder niet |
| Rechts aan | led_right_on | 0x1E | afwijking | Afzonderlijke LED: reageerde eerder niet |
| Rechts uit | led_right_off | 0x1F | afwijking | Afzonderlijke LED: reageerde eerder niet |
| Diagnose linkeroog | led_test_left | 0x1A/1D/1B | afwijking | Bestaande 1,5 s diagnose |
| Diagnose rechteroog | led_test_right | 0x1A/1F/1B | afwijking | Bestaande 1,5 s diagnose |

## Beweging

| Knop | Actie-ID | Originele code | Status | Toelichting |
|---|---|---|---|---|
| Vleugelslag rustig | flap | 0x80 | bewezen | 1x zwaaien · snelheid 1 |
| Vleugelslag normaal | flap_medium | 0x80 | proef | 1x zwaaien · snelheid 3 |
| Vleugelslag snel | flap_fast | 0x80 | proef | 1x zwaaien · snelheid 5 |
| Vleugels resetten | wings_reset | 0x31 | proef | Originele reset · kort begrensd |
| Vleugels STOP | wings_stop | 0x30 | bewezen | Gerichte motorstop |
| Oogleden openen | eyes_open | 0x33 | proef | Oogleden openen · nog onbewezen |
| Oogleden sluiten | eyes_close | 0x40 | bewezen | Historische toggle sluit · kwam dicht |
| Oogleden STOP | eyes_stop | 0x32 | proef | Stop ooglidmotor |
| Snavel openen | mouth_open | 0x34 | proef | Open snavel, korte puls |
| Snavel sluiten | mouth_close | 0x35 | proef | Sluit snavel, korte puls |
| Snavel bewegen 1x | mouth_toggle | 0x41 | proef | Historische snavel-toggle |
| Snavel STOP | mouth_stop | 0x36 | proef | Stop snavelmotor |
| 90° links proberen | spin_left | 0x82 | proef | Korte draai links · snelheid 1 |
| 90° rechts proberen | spin_right | 0x83 | proef | Korte draai rechts · snelheid 1 |
| Links draaien v2 | spin_left_medium | 0x82 | proef | Korte draai · snelheid 2 |
| Rechts draaien v2 | spin_right_medium | 0x83 | proef | Korte draai · snelheid 2 |
| Draaien STOP | spin_stop | 0x37 | proef | Stop draaimotor |

## Audio

| Knop | Actie-ID | Originele code | Status | Toelichting |
|---|---|---|---|---|
| Originele geluidstest | sound_test | 0x10 | proef | TEST_SOUND uit het oorspronkelijke protocol |
| Geluid #0 | sound_0 | 0x90 | proef | Speel opgeslagen soundslot 0 |
| Geluid #1 | sound_1 | 0x90 | proef | Speel opgeslagen soundslot 1 |
| Geluid #2 | sound_2 | 0x90 | proef | Speel opgeslagen soundslot 2 |
| Geluid #3 | sound_3 | 0x90 | proef | Speel opgeslagen soundslot 3 |
| Geluid #4 | sound_4 | 0x90 | proef | Speel opgeslagen soundslot 4 |
| Geluid #5 | sound_5 | 0x90 | proef | Speel opgeslagen soundslot 5 |
| Geluid #6 | sound_6 | 0x90 | proef | Speel opgeslagen soundslot 6 |
| Geluid #7 | sound_7 | 0x90 | proef | Speel opgeslagen soundslot 7 |
| Origineel mute AAN | mute_on | 0x92 | proef | Mute state 1 · werking nog verifiëren |
| Origineel mute UIT | mute_off | 0x92 | proef | Mute state 0 · werking nog verifiëren |

## Infrarood

| Knop | Actie-ID | Originele code | Status | Toelichting |
|---|---|---|---|---|
| IR korte puls | ir_on | 0x17/18 | afwijking | Liet eerder blauwe ogen reageren |
| IR-uit | ir_off | 0x18 | afwijking | Uitzetten IR-uitgang |
| RC5 Stand-by | rc5_standby | 0x91 | onderzoek | Zend RC5 command 0x0C, adres 0; geen ontvangsttest |
| RC5 Mute | rc5_mute | 0x91 | onderzoek | Zend RC5 command 0x0D, adres 0; geen ontvangsttest |
| RC5 JA | rc5_yes | 0x91 | onderzoek | Zend RC5 command 0x13, adres 0; geen ontvangsttest |
| RC5 NEE | rc5_no | 0x91 | onderzoek | Zend RC5 command 0x14, adres 0; geen ontvangsttest |
| RC5 Rood | rc5_red | 0x91 | onderzoek | Zend RC5 command 0x1B, adres 0; geen ontvangsttest |
| RC5 Groen | rc5_green | 0x91 | onderzoek | Zend RC5 command 0x1C, adres 0; geen ontvangsttest |
| RC5 Blauw | rc5_blue | 0x91 | onderzoek | Zend RC5 command 0x1D, adres 0; geen ontvangsttest |
| RC5 Geel | rc5_yellow | 0x91 | onderzoek | Zend RC5 command 0x1E, adres 0; geen ontvangsttest |
| RC5 Omhoog | rc5_up | 0x91 | onderzoek | Zend RC5 command 0x22, adres 0; geen ontvangsttest |
| RC5 Omlaag | rc5_down | 0x91 | onderzoek | Zend RC5 command 0x23, adres 0; geen ontvangsttest |
| RC5 Links | rc5_left | 0x91 | onderzoek | Zend RC5 command 0x24, adres 0; geen ontvangsttest |
| RC5 Rechts | rc5_right | 0x91 | onderzoek | Zend RC5 command 0x25, adres 0; geen ontvangsttest |
| RC5 OK | rc5_ok | 0x91 | onderzoek | Zend RC5 command 0x26, adres 0; geen ontvangsttest |
| RC5 Play/pauze | rc5_play | 0x91 | onderzoek | Zend RC5 command 0x35, adres 0; geen ontvangsttest |
| RC5 Stop | rc5_stop | 0x91 | onderzoek | Zend RC5 command 0x36, adres 0; geen ontvangsttest |
| RC5 Menu | rc5_menu | 0x91 | onderzoek | Zend RC5 command 0x3A, adres 0; geen ontvangsttest |
| RC5 0 | rc5_num0 | 0x91 | onderzoek | Zend RC5 cijfer 0, adres 0; geen ontvangsttest |
| RC5 1 | rc5_num1 | 0x91 | onderzoek | Zend RC5 cijfer 1, adres 0; geen ontvangsttest |
| RC5 2 | rc5_num2 | 0x91 | onderzoek | Zend RC5 cijfer 2, adres 0; geen ontvangsttest |
| RC5 3 | rc5_num3 | 0x91 | onderzoek | Zend RC5 cijfer 3, adres 0; geen ontvangsttest |
| RC5 4 | rc5_num4 | 0x91 | onderzoek | Zend RC5 cijfer 4, adres 0; geen ontvangsttest |
| RC5 5 | rc5_num5 | 0x91 | onderzoek | Zend RC5 cijfer 5, adres 0; geen ontvangsttest |
| RC5 6 | rc5_num6 | 0x91 | onderzoek | Zend RC5 cijfer 6, adres 0; geen ontvangsttest |
| RC5 7 | rc5_num7 | 0x91 | onderzoek | Zend RC5 cijfer 7, adres 0; geen ontvangsttest |
| RC5 8 | rc5_num8 | 0x91 | onderzoek | Zend RC5 cijfer 8, adres 0; geen ontvangsttest |
| RC5 9 | rc5_num9 | 0x91 | onderzoek | Zend RC5 cijfer 9, adres 0; geen ontvangsttest |

## Sensoren

| Knop | Actie-ID | Originele code | Status | Toelichting |
|---|---|---|---|---|
| Lees ruw USB-input | read_input | HID input | onderzoek | Alleen ruwe data, geen sensorwaarden |

## Status-ID’s uit oorspronkelijke driver

| Status | Code |
|---|---|
| Vleugelmotor achteruit | 0x01 |
| Draaimotor achteruit | 0x02 |
| Draaimotor vooruit | 0x03 |
| Snavel open positie | 0x04 |
| Snavel dicht positie | 0x05 |
| Kop ingedrukt | 0x06 |
| Laadbeveiliging | 0x07 |
| Vleugel-positie | 0x08 |
| Vleugelmotor actief | 0x09 |
| Linker LED | 0x0A |
| I²C SDA | 0x0B |
| I²C SCL | 0x0C |
| Snavelmotor | 0x0D |
| Ooglidmotor | 0x0E |
| IR-ontvanger | 0x0F |
| Draaipositie | 0x10 |
| Vleugelmotor vooruit | 0x11 |
| IR-led | 0x12 |
| Oogleden open | 0x13 |
| Oogleden dicht | 0x14 |
| Linkervleugelknop | 0x15 |
| Rechtervleugelknop | 0x16 |
| Stekkerstatus | 0x17 |
| Kopknop | 0x18 |
| Laad-led | 0x19 |
| Mute-status | 0x1A |
| Lichtsterkte | 0x1B |
| Oogpositie teller | 0x1C |
| Snavelpositie teller | 0x1D |
| Vleugelpositie teller | 0x1E |
| Draaipositie teller | 0x1F |
| Rechter LED | 0x20 |
| RF-verbinding | 0x21 |
| Ontvangen IR-code | 0x22 |
| Aantal sounds | 0x23 |
| PONG | 0x24 |

**Deze statuslabels zijn alleen een referentie:** ruwe Input/HID-data is nog niet gecodeerd naar afzonderlijke statussen.

## Historische .tgf-gadgets — na ontdubbelen

- `Alarm 0.0.5.tgf` (Alarm 0.0.5)
- `Amarok 0.0.3.tgf` (Amarok 0.0.3)
- `Attitunes_studio.tgf` (Attitunes studio)
- `Battery monitor.tgf` (Battery monitor)
- `Calculator 0.0.2.tgf` (Calculator 0.0.2)
- `Calculator.tgf` (Calculator)
- `Clipboard translator.tgf` (Clipboard translator)
- `Clock.tgf` (Clock)
- `Debug_control.tgf` (Debug control)
- `Email.tgf` (Email)
- `Light monitor.tgf` (Light monitor)
- `Manager.tgf` (Manager)
- `Micro monitor.tgf` (Micro monitor)
- `RSS reader.tgf` (RSS reader)
- `Scenes_manager.tgf` (Scenes manager)
- `Totem 0.0.2.tgf` (Totem 0.0.2)
- `Tuxcontroller.tgf` (Tuxcontroller)
- `VoiceRec_configurator.tgf` (VoiceRec configurator)
- `Weather.tgf` (Weather)
- `alarm.0.0.5.tgf` (alarm)
- `amarok_player.0.0.3.tgf` (amarok player)
- `audacious_player.0.0.3.tgf` (audacious player)
- `audio_flash.tgf` (audio flash)
- `firmware_updater.tgf` (firmware updater)
- `flash_management.tgf` (flash management)
- `gmail.tgf` (gmail)
- `pc_monitor.0.0.2.tgf` (pc monitor)
- `shortcuts_manager.tgf` (shortcuts manager)
- `totem_player.0.0.2.tgf` (totem player)
- `tuxdroid-gadget-WMP.tgf` (WMP)
- `tuxdroid-gadget-audacious.tgf` (audacious)
- `tuxdroid-gadget-facebook.tgf` (facebook)
- `tuxdroid-gadget-feed-2226.tgf` (feed-2226)
- `tuxdroid-gadget-feed.tgf` (feed)
- `tuxdroid-gadget-idleBehavior.tgf` (idleBehavior)
- `tuxdroid-gadget-java-clock-2209.tgf` (java-clock-2209)
- `tuxdroid-gadget-java-clock.tgf` (java-clock)
- `tuxdroid-gadget-mail-2225.tgf` (mail-2225)
- `tuxdroid-gadget-mail.tgf` (mail)
- `tuxdroid-gadget-maxlight.tgf` (maxlight)
- `tuxdroid-gadget-moovida.tgf` (moovida)
- `tuxdroid-gadget-mpd.tgf` (mpd)
- `tuxdroid-gadget-msn.tgf` (msn)
- `tuxdroid-gadget-programsTVBeDu.tgf` (programsTVBeDu)
- `tuxdroid-gadget-programsTVBeFr.tgf` (programsTVBeFr)
- `tuxdroid-gadget-programsTVFr.tgf` (programsTVFr)
- `tuxdroid-gadget-programsTVNl.tgf` (programsTVNl)
- `tuxdroid-gadget-programsTVSp.tgf` (programsTVSp)
- `tuxdroid-gadget-programsTVUk.tgf` (programsTVUk)
- `tuxdroid-gadget-shortcut-2237.tgf` (shortcut-2237)
- `tuxdroid-gadget-shortcut.tgf` (shortcut)
- `tuxdroid-gadget-system.tgf` (system)
- `tuxdroid-gadget-totem.tgf` (totem)
- `tuxdroid-gadget-twitter.tgf` (twitter)
- `tuxdroid-gadget-weather-2234.tgf` (weather-2234)
- `tuxdroid-gadget-xmms.tgf` (xmms)
- `tuxdroid-skype-gadget.tgf` (skype-gadget)
- `xmms_player.0.0.3.tgf` (xmms player)
