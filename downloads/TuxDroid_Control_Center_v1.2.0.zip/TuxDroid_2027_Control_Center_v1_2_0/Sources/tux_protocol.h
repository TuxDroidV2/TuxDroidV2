#ifndef TUX_PROTOCOL_H
#define TUX_PROTOCOL_H

/* New OEM protocol adaptations: based on libtuxdriver, Copyright (C) 2008
   C2ME Sa / Remi Jocaille, GPL-2.0-or-later. See THIRD_PARTY_NOTICES.md. */

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define TUX_OUTPUT_BYTES 64
#define TUX_INPUT_CAPACITY 4096

/* The proven output layout remains [0, opcode, p1, p2, 0, ...]. */
static inline void tux_output_report(uint8_t packet[TUX_OUTPUT_BYTES],
                                     uint8_t opcode, uint8_t p1, uint8_t p2) {
    memset(packet, 0, TUX_OUTPUT_BYTES);
    packet[1] = opcode;
    packet[2] = p1;
    packet[3] = p2;
}

/* OEM tux_usb.c: header 0 addresses the robot, header 1 the dongle. */
static inline void tux_addressed_report(uint8_t packet[TUX_OUTPUT_BYTES],
                                        uint8_t header, uint8_t opcode,
                                        uint8_t p1, uint8_t p2, uint8_t p3) {
    tux_output_report(packet, opcode, p1, p2);
    packet[0] = header;
    packet[4] = p3;
}

/* OEM tux_sound_flash.c: 100% -> attenuation 0, 0% -> attenuation 7. */
static inline uint8_t tux_flash_attenuation(unsigned percent) {
    if (percent > 100) percent = 100;
    return (uint8_t)(7 - percent * 7 / 100);
}

/* UI action IDs retain indexes 0..7; OEM firmware plays tracks 1..8. */
static inline void tux_sound_report(uint8_t packet[TUX_OUTPUT_BYTES], uint8_t index) {
    tux_output_report(packet, 0x90, (uint8_t)(index + 1), tux_flash_attenuation(80));
}

/* OEM tux_movements.c: configure PWM, then a firmware-timed 240 ms pulse.
   Preserve the existing 300 ms host STOP limit. No claimed angle/full circle. */
static inline void tux_spin_report(uint8_t packet[TUX_OUTPUT_BYTES],
                                   bool left, bool faster, bool movement) {
    uint8_t motor = left ? 4 : 3;
    tux_addressed_report(packet, 0, movement ? 0xD4 : 0x81, motor,
                         movement ? 60 : (faster ? 5 : 3), movement ? 1 : 0);
}

enum tux_input_state { TUX_INPUT_WAITING, TUX_INPUT_RECEIVED,
                       TUX_INPUT_FAILED, TUX_INPUT_INVALID };
struct tux_input_capture {
    enum tux_input_state state;
    int32_t result;
    uint32_t report_id;
    size_t limit;
    size_t length;
    uint8_t bytes[TUX_INPUT_CAPACITY];
};

/* Capture the first event only. No event never becomes a zero-filled reading. */
static inline void tux_capture_input(struct tux_input_capture *capture,
                                     int32_t result, uint32_t report_id,
                                     const uint8_t *bytes, ptrdiff_t length) {
    if (capture->state != TUX_INPUT_WAITING) return;
    capture->result = result;
    capture->report_id = report_id;
    if (result != 0) {
        capture->state = TUX_INPUT_FAILED;
        return;
    }
    if (!bytes || length <= 0 || (size_t)length > capture->limit ||
        (size_t)length > TUX_INPUT_CAPACITY) {
        capture->state = TUX_INPUT_INVALID;
        return;
    }
    memcpy(capture->bytes, bytes, (size_t)length);
    capture->length = (size_t)length;
    capture->state = TUX_INPUT_RECEIVED;
}

#endif
