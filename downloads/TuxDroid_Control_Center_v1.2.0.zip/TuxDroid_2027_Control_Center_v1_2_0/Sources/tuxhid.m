// TuxDroid 2027 v1.1.0 HID helper — macOS 12+, Apple Silicon and Intel.
// Existing eye LED and wing opcodes physically verified on M2/iPhone. New opcodes from original Ruby library are EXPERIMENTAL.
// NO firmware writes, NO arbitrary USB payloads, NO driver installation.
#import <Foundation/Foundation.h>
#import <IOKit/hid/IOHIDManager.h>
#import <IOKit/hid/IOHIDKeys.h>
#import <signal.h>
#import <unistd.h>
#include "tux_protocol.h"

static NSString *const HelperVersion = @"1.2.0";
static NSMutableArray<NSDictionary *> *gOutputReports;
static volatile sig_atomic_t gStopRequested = 0;
static void requestStop(int sig) { (void)sig; gStopRequested = 1; }
static NSString *hexResult(IOReturn r) { return [NSString stringWithFormat:@"0x%08X", (unsigned)r]; }
static NSString *hexBytes(const uint8_t *bytes, size_t length) {
    NSMutableArray<NSString *> *parts = [NSMutableArray arrayWithCapacity:length];
    for (size_t i = 0; i < length; ++i) [parts addObject:[NSString stringWithFormat:@"%02X", bytes[i]]];
    return [parts componentsJoinedByString:@" "];
}
static NSDictionary *fail(NSString *code, NSString *message) {
    return @{ @"ok": @NO, @"code": code, @"message": message };
}
static void emit(NSDictionary *object) {
    NSData *json = [NSJSONSerialization dataWithJSONObject:object options:0 error:nil];
    if (json) { fwrite(json.bytes, 1, json.length, stdout); fputc('\n', stdout); fflush(stdout); }
}
static BOOL selected(IOHIDDeviceRef d) {
    NSNumber *vid = (__bridge id)IOHIDDeviceGetProperty(d, CFSTR(kIOHIDVendorIDKey));
    NSNumber *pid = (__bridge id)IOHIDDeviceGetProperty(d, CFSTR(kIOHIDProductIDKey));
    NSNumber *page = (__bridge id)IOHIDDeviceGetProperty(d, CFSTR(kIOHIDPrimaryUsagePageKey));
    NSNumber *usage = (__bridge id)IOHIDDeviceGetProperty(d, CFSTR(kIOHIDPrimaryUsageKey));
    return [vid isKindOfClass:NSNumber.class] && vid.unsignedIntValue == 0x03EB &&
           [pid isKindOfClass:NSNumber.class] && pid.unsignedIntValue == 0xFF07 &&
           [page isKindOfClass:NSNumber.class] && page.unsignedIntValue == 0xFF00 &&
           [usage isKindOfClass:NSNumber.class] && usage.unsignedIntValue == 1;
}
static IOReturn sendPacket(IOHIDDeviceRef d, const uint8_t packet[TUX_OUTPUT_BYTES]) {
    IOReturn result = IOHIDDeviceSetReport(d, kIOHIDReportTypeOutput, 0, packet, TUX_OUTPUT_BYTES);
    [gOutputReports addObject:@{ @"report_id": @0, @"bytes": @64,
                                @"payload_hex": hexBytes(packet, TUX_OUTPUT_BYTES),
                                @"result": hexResult(result) }];
    return result;
}
static IOReturn sendOpcode(IOHIDDeviceRef d, uint8_t op, uint8_t p1, uint8_t p2) {
    uint8_t packet[TUX_OUTPUT_BYTES];
    tux_output_report(packet, op, p1, p2);
    return sendPacket(d, packet);
}
struct NativeInputContext {
    struct tux_input_capture capture;
    CFRunLoopRef runLoop;
};
static void receiveInput(void *context, IOReturn result, void *sender,
                         IOHIDReportType type, uint32_t reportID,
                         uint8_t *report, CFIndex reportLength) {
    (void)sender;
    if (type != kIOHIDReportTypeInput) return;
    struct NativeInputContext *state = context;
    tux_capture_input(&state->capture, (int32_t)result, reportID, report, (ptrdiff_t)reportLength);
    CFRunLoopStop(state->runLoop);
}
static NSDictionary *readInputReport(IOHIDDeviceRef device) {
    // Apple's IOHIDDevice.h directs input reports to this callback API, not GetReport.
    // No output report or guessed status request is sent by this operation.
    NSNumber *maximum = (__bridge id)IOHIDDeviceGetProperty(device, CFSTR(kIOHIDMaxInputReportSizeKey));
    if (![maximum isKindOfClass:NSNumber.class] || maximum.integerValue <= 0 ||
        maximum.unsignedLongLongValue > TUX_INPUT_CAPACITY) {
        return @{ @"ok": @NO, @"code": @"wrong_input_report_size",
                  @"message": @"Geen ondersteunde HID-inputreportgrootte gevonden; niets verstuurd" };
    }
    uint8_t buffer[TUX_INPUT_CAPACITY] = {0};
    struct NativeInputContext context = {0};
    context.capture.limit = (size_t)maximum.unsignedLongLongValue;
    context.runLoop = CFRunLoopGetCurrent();
    IOHIDDeviceRegisterInputReportCallback(device, buffer, (CFIndex)context.capture.limit,
                                           receiveInput, &context);
    IOHIDDeviceScheduleWithRunLoop(device, context.runLoop, kCFRunLoopDefaultMode);
    CFAbsoluteTime started = CFAbsoluteTimeGetCurrent();
    if (!gStopRequested) CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.75, false);
    // Keep buffer/context alive until the callback has been unregistered and unscheduled.
    IOHIDDeviceRegisterInputReportCallback(device, buffer, (CFIndex)context.capture.limit, NULL, NULL);
    IOHIDDeviceUnscheduleFromRunLoop(device, context.runLoop, kCFRunLoopDefaultMode);
    NSMutableDictionary *result = [@{ @"ok": @(context.capture.state == TUX_INPUT_RECEIVED),
        @"input_transport": @"interrupt_callback", @"wait_limit_ms": @750,
        @"waited_ms": @((long)((CFAbsoluteTimeGetCurrent() - started) * 1000.0)),
        @"input_result": [NSNull null], @"status_request_sent": @NO,
        @"decoded_sensors": @NO } mutableCopy];
    if (context.capture.state == TUX_INPUT_RECEIVED) {
        result[@"input_result"] = hexResult((IOReturn)context.capture.result);
        result[@"input_report_id"] = @(context.capture.report_id);
        result[@"actual_bytes"] = @(context.capture.length);
        result[@"raw_hex"] = hexBytes(context.capture.bytes, context.capture.length);
        result[@"message"] = @"Ruw HID-inputreport ontvangen via callback; sensorwaarden nog niet gedecodeerd";
    } else if (context.capture.state == TUX_INPUT_WAITING) {
        result[@"code"] = gStopRequested ? @"input_cancelled" : @"no_input_report";
        result[@"message"] = @"Geen inputreport binnen het luistervenster. Er is niets verstuurd; dit bewijst niet dat de sensoren defect zijn.";
    } else {
        result[@"input_result"] = hexResult((IOReturn)context.capture.result);
        result[@"code"] = context.capture.state == TUX_INPUT_FAILED ? @"input_failed" : @"invalid_input_report";
        result[@"message"] = @"HID-invoer gaf een fout of ongeldig report; geen sensorwaarde aangenomen";
    }
    return result;
}
static NSDictionary *safePulse(IOHIDDeviceRef d, NSString *action, uint8_t opcode, uint8_t p1, uint8_t p2, uint8_t stopOpcode, useconds_t microseconds) {
    // Motor action stays short and is followed by STOP regardless of start result.
    // If a USB call blocks, physical power-off is the only reliable emergency stop.
    IOReturn start = sendOpcode(d, opcode, p1, p2);
    if (start == kIOReturnSuccess) {
        for (useconds_t elapsed=0; elapsed<microseconds && !gStopRequested; elapsed+=25000) usleep(25000);
    }
    IOReturn stop = sendOpcode(d, stopOpcode, 0, 0);
    BOOL ok = start == kIOReturnSuccess && stop == kIOReturnSuccess;
    return @{ @"ok": @(ok), @"action": action,
              @"start_result": hexResult(start), @"stop_result": hexResult(stop),
              @"auto_stop_target_ms": @(microseconds/1000),
              @"stop_requested": @(gStopRequested != 0), @"firmware_changed": @NO,
              @"message": ok ? @"EXPERIMENT: motoractie en STOP door USB geaccepteerd; fysieke reactie moet worden gecontroleerd" : @"Motoractie of STOP mislukt; schakel robot fysiek uit als iets onverwachts gebeurt" };
}
static NSDictionary *perform(NSString *action) {
    NSSet *allowed = [NSSet setWithArray:@[@"scan", @"probe", @"led_on", @"led_off", @"led_blink", @"led_firmware_blink",
        @"led_left_on", @"led_left_off", @"led_right_on", @"led_right_off", @"led_test_left", @"led_test_right",
        @"flap", @"flap_medium", @"flap_fast", @"wings_reset", @"wings_stop", @"eyes_open",
        @"eyes_close", @"eyes_stop", @"mouth_open", @"mouth_close", @"mouth_toggle", @"mouth_stop",
        @"spin_left", @"spin_right", @"spin_left_medium", @"spin_right_medium", @"spin_stop", @"stop_all",
        @"audio_channel_general", @"audio_channel_tts",
        @"sound_test", @"sound_0", @"sound_1", @"sound_2", @"sound_3", @"sound_4",
        @"sound_5", @"sound_6", @"sound_7", @"mute_on", @"mute_off", @"ir_on",
        @"ir_off", @"read_input", @"rc5_standby", @"rc5_mute", @"rc5_yes", @"rc5_no",
        @"rc5_red", @"rc5_green", @"rc5_blue", @"rc5_yellow", @"rc5_up", @"rc5_down",
        @"rc5_left", @"rc5_right", @"rc5_ok", @"rc5_play", @"rc5_stop", @"rc5_menu",
        @"rc5_num0", @"rc5_num1", @"rc5_num2", @"rc5_num3", @"rc5_num4", @"rc5_num5",
        @"rc5_num6", @"rc5_num7", @"rc5_num8", @"rc5_num9", @"stop"]];
    // Reject unknown names before opening any device, including sound_* prefixes.
    if (![allowed containsObject:action]) return fail(@"invalid_action", @"Niet-toegestane USB-opdracht");
    IOHIDManagerRef manager = IOHIDManagerCreate(kCFAllocatorDefault, kIOHIDOptionsTypeNone);
    if (!manager) return fail(@"manager_error", @"IOHIDManagerCreate mislukt");
    IOHIDManagerSetDeviceMatching(manager, NULL);
    CFSetRef devices = IOHIDManagerCopyDevices(manager);
    NSMutableArray *matches = [NSMutableArray array];
    if (devices) {
        for (id candidate in (__bridge NSSet *)devices) {
            IOHIDDeviceRef d = (__bridge IOHIDDeviceRef)candidate;
            if (selected(d)) [matches addObject:candidate];
        }
    }
    NSUInteger count = matches.count;
    NSDictionary *result = nil;
    if ([action isEqualToString:@"scan"]) {
        result = @{ @"ok": @YES, @"found": @(count == 1), @"count": @(count),
                    @"device": @"03EB:FF07", @"report_bytes_expected": @64,
                    @"message": count == 1 ? @"TuxDroid USB-dongle aangetroffen" : @"Verwacht precies één TuxDroid USB-dongle" };
    } else if (count != 1) {
        result = fail(@"wrong_device_count", @"Verwacht exact één TuxDroid-dongle 03EB:FF07, HID FF00/1");
    } else {
        IOHIDDeviceRef d = (__bridge IOHIDDeviceRef)matches.firstObject;
        NSNumber *reportSize = (__bridge id)IOHIDDeviceGetProperty(d, CFSTR(kIOHIDMaxOutputReportSizeKey));
        if ([action isEqualToString:@"probe"] || [action isEqualToString:@"read_input"] ||
            ([reportSize isKindOfClass:NSNumber.class] && reportSize.integerValue == 64)) {
            IOReturn opened = IOHIDDeviceOpen(d, kIOHIDOptionsTypeNone); // Not exclusive / no seize.
            if (opened != kIOReturnSuccess) {
                result = @{ @"ok": @NO, @"code": @"open_failed", @"open_result": hexResult(opened),
                            @"message": @"Kon HID-interface niet openen" };
            } else {
                NSMutableDictionary *r = [@{ @"ok": @YES, @"device": @"03EB:FF07", @"action": action,
                                             @"open_result": hexResult(opened), @"report_bytes": reportSize ?: @0,
                                             @"firmware_changed": @NO } mutableCopy];
                if ([action isEqualToString:@"probe"]) {
                    r[@"output_ready"] = @([reportSize isKindOfClass:NSNumber.class] && reportSize.integerValue == 64);
                    NSNumber *inputSize = (__bridge id)IOHIDDeviceGetProperty(d, CFSTR(kIOHIDMaxInputReportSizeKey));
                    r[@"max_input_report_bytes"] = [inputSize isKindOfClass:NSNumber.class] ? inputSize : @0;
                    r[@"message"] = @"HID-interface succesvol geopend en gesloten; geen USB-commando verzonden";
                } else if ([action isEqualToString:@"led_on"] || [action isEqualToString:@"led_off"]) {
                    IOReturn sent = sendOpcode(d, [action isEqualToString:@"led_on"] ? 0x1A : 0x1B, 0, 0);
                    r[@"write_result"] = hexResult(sent);
                    r[@"ok"] = @(sent == kIOReturnSuccess);
                    r[@"message"] = sent == kIOReturnSuccess ? @"LED-commando door USB-stack geaccepteerd" : @"LED-commando niet geaccepteerd";
                } else if ([action isEqualToString:@"led_firmware_blink"]) {
                    IOReturn sent = sendOpcode(d, 0x9A, 3, 25);
                    r[@"write_result"] = hexResult(sent);
                    r[@"ok"] = @(sent == kIOReturnSuccess);
                    r[@"message"] = @"Origineel firmware-blink 0x9A (3x) naar USB verstuurd; fysieke reactie onbewezen";
                } else if ([action isEqualToString:@"led_blink"]) {
                    // One short on/off pair, no indefinite LED activity.
                    IOReturn on = sendOpcode(d, 0x1A, 0, 0);
                    if (on == kIOReturnSuccess) usleep(300000);
                    IOReturn off = sendOpcode(d, 0x1B, 0, 0);
                    r[@"led_on_result"] = hexResult(on);
                    r[@"led_off_result"] = hexResult(off);
                    r[@"ok"] = @(on == kIOReturnSuccess && off == kIOReturnSuccess);
                    r[@"message"] = [r[@"ok"] boolValue] ? @"Korte LED-proef verstuurd" : @"LED-proef onvolledig";
                } else if ([action isEqualToString:@"flap"] || [action isEqualToString:@"flap_medium"] || [action isEqualToString:@"flap_fast"] || [action isEqualToString:@"wings_reset"]) {
                    // Historical Ruby command: [00 80 01 01 00], one flap, low speed.
                    // Always attempt [00 30 00 00 00] after <=400 ms if HID call returns.
                    const BOOL resetting = [action isEqualToString:@"wings_reset"];
                    const uint8_t speed = [action isEqualToString:@"flap_fast"] ? 5 : ([action isEqualToString:@"flap_medium"] ? 3 : 1);
                    IOReturn start = resetting ? sendOpcode(d, 0x31, 0, 0) : sendOpcode(d, 0x80, 1, speed);
                    r[@"wing_start_result"] = hexResult(start);
                    if (start == kIOReturnSuccess) {
                        for (int i=0; i<(resetting ? 24 : 16) && !gStopRequested; ++i) usleep(25000);
                    }
                    IOReturn stop = sendOpcode(d, 0x30, 0, 0);
                    r[@"wing_stop_result"] = hexResult(stop);
                    r[@"stop_requested"] = @(gStopRequested != 0);
                    r[@"auto_stop_target_ms"] = @(resetting ? 600 : 400);
                    r[@"ok"] = @(start == kIOReturnSuccess && stop == kIOReturnSuccess);
                    r[@"message"] = [r[@"ok"] boolValue] ? @"Een vleugelactie en STOP door USB-stack geaccepteerd" : @"Vleugelactie of STOP mislukt: schakel de robot zo nodig uit";
                } else if ([action isEqualToString:@"stop"] || [action isEqualToString:@"stop_all"] ||
                           [action isEqualToString:@"wings_stop"] || [action isEqualToString:@"eyes_stop"] ||
                           [action isEqualToString:@"mouth_stop"] || [action isEqualToString:@"spin_stop"]) {
                    // Full STOP for all mechanical actuators; same HID report transport.
                    uint8_t stops[] = {0x30, 0x32, 0x36, 0x37};
                    NSUInteger countStops = [action isEqualToString:@"stop_all"] ? 4 : 1;
                    if ([action isEqualToString:@"wings_stop"]) stops[0] = 0x30;
                    else if ([action isEqualToString:@"eyes_stop"]) stops[0] = 0x32;
                    else if ([action isEqualToString:@"mouth_stop"]) stops[0] = 0x36;
                    else if ([action isEqualToString:@"spin_stop"]) stops[0] = 0x37;
                    NSMutableDictionary *sent = [NSMutableDictionary dictionary];
                    BOOL allOK = YES;
                    for (NSUInteger i=0; i<countStops; ++i) {
                        IOReturn code = sendOpcode(d, stops[i], 0, 0);
                        sent[[NSString stringWithFormat:@"0x%02X",stops[i]]] = hexResult(code);
                        if (code != kIOReturnSuccess) allOK = NO;
                    }
                    r[@"stop_results"] = sent;
                    r[@"ok"] = @(allOK);
                    r[@"message"] = allOK ? @"STOP-opdracht(en) door USB geaccepteerd" : @"STOP niet volledig geaccepteerd; schakel robot fysiek uit";
                } else if ([action isEqualToString:@"led_test_left"] || [action isEqualToString:@"led_test_right"]) {
                    // Diagnostic: both on -> just one OFF -> 1.5s visible observation -> both off.
                    // Original Ruby opcode table; no guessed opcodes, no motor/firmware writes.
                    const uint8_t target = [action isEqualToString:@"led_test_left"] ? 0x1D : 0x1F;
                    IOReturn bothOn = sendOpcode(d, 0x1A, 0, 0);
                    if (bothOn == kIOReturnSuccess) usleep(450000);
                    IOReturn oneOff = bothOn == kIOReturnSuccess ? sendOpcode(d, target, 0, 0) : (IOReturn)kIOReturnNotReady;
                    if (oneOff == kIOReturnSuccess) usleep(1500000);
                    IOReturn bothOff = sendOpcode(d, 0x1B, 0, 0);
                    const BOOL ok = bothOn == kIOReturnSuccess && oneOff == kIOReturnSuccess && bothOff == kIOReturnSuccess;
                    r[@"ok"] = @(ok);
                    r[@"both_on_result"] = hexResult(bothOn);
                    r[@"single_off_result"] = hexResult(oneOff);
                    r[@"both_off_result"] = hexResult(bothOff);
                    r[@"sequence"] = [action isEqualToString:@"led_test_left"] ? @"1A -> 1D -> 1B" : @"1A -> 1F -> 1B";
                    r[@"target_opcode"] = [NSString stringWithFormat:@"0x%02X", target];
                    r[@"visible_window_ms"] = @1500;
                    r[@"physical_result"] = @"UNKNOWN: alleen gebruiker kan dit bevestigen";
                    r[@"message"] = ok ? @"LED-diagnose-opdrachten geaccepteerd; controleer of slechts EEN oog bleef branden" : @"LED-diagnose-opdracht mislukt; oog-leds uit geprobeerd";
                } else if ([action hasPrefix:@"led_left_"] || [action hasPrefix:@"led_right_"]) {
                    NSDictionary *map = @{@"led_left_on":@0x1C, @"led_left_off":@0x1D, @"led_right_on":@0x1E, @"led_right_off":@0x1F};
                    NSNumber *opcode = map[action];
                    IOReturn sent = sendOpcode(d, opcode.unsignedCharValue, 0, 0);
                    r[@"write_result"] = hexResult(sent);
                    r[@"ok"] = @(sent == kIOReturnSuccess);
                    r[@"message"] = sent == kIOReturnSuccess ? @"Individueel LED-commando verstuurd (fysiek nog verifiëren)" : @"LED-opdracht mislukt";
                } else if ([action isEqualToString:@"read_input"]) {
                    [r addEntriesFromDictionary:readInputReport(d)];
                } else if ([action hasPrefix:@"audio_channel_"]) {
                    uint8_t packet[TUX_OUTPUT_BYTES];
                    BOOL tts = [action isEqualToString:@"audio_channel_tts"];
                    tux_addressed_report(packet, 1, 2, tts ? 1 : 0, 0, 0);
                    IOReturn channel = sendPacket(d, packet);
                    IOReturn unmute = kIOReturnNotReady;
                    if (channel == kIOReturnSuccess && !gStopRequested)
                        unmute = sendOpcode(d, 0x92, 0, 0);
                    r[@"channel_result"] = hexResult(channel);
                    r[@"unmute_result"] = hexResult(unmute);
                    r[@"audio_channel"] = tts ? @"tts" : @"general";
                    r[@"ok"] = @(channel == kIOReturnSuccess && unmute == kIOReturnSuccess);
                    r[@"message"] = @"Audio-kanaalkeuze en unmute naar USB verstuurd; nog geen geluid afgespeeld";
                } else if ([action hasPrefix:@"sound_"] && ![action isEqualToString:@"sound_test"]) {
                    // Strict fixed allowlist guarantees sound_0..sound_7 only.
                    NSInteger slot = [[action substringFromIndex:6] integerValue];
                    uint8_t packet[TUX_OUTPUT_BYTES];
                    tux_sound_report(packet, (uint8_t)slot);
                    IOReturn sent = sendPacket(d, packet);
                    r[@"write_result"] = hexResult(sent);
                    r[@"slot"] = @(slot);
                    r[@"track"] = @(slot + 1);
                    r[@"volume_percent"] = @80;
                    r[@"volume_attenuation"] = @(tux_flash_attenuation(80));
                    r[@"ok"] = @(sent == kIOReturnSuccess);
                    r[@"message"] = @"Opgeslagen-geluid commando met OEM-tracknummer en volumecodering verstuurd; inhoud en hoorbare reactie nog bevestigen";
                } else if ([action isEqualToString:@"mute_on"] || [action isEqualToString:@"mute_off"]) {
                    uint8_t state = [action isEqualToString:@"mute_on"] ? 1 : 0;
                    IOReturn sent = sendOpcode(d, 0x92, state, 0);
                    r[@"write_result"] = hexResult(sent);
                    r[@"ok"] = @(sent == kIOReturnSuccess);
                    r[@"message"] = @"Originele MUTE-opdracht verstuurd; fysieke reactie nog niet vastgesteld";
                } else if ([action hasPrefix:@"rc5_"]) {
                    // Fixed RC5 subcommands from original Ruby Remote table, address 0.
                    NSDictionary<NSString *,NSNumber *> *remote = @{@"rc5_standby":@12, @"rc5_mute":@13, @"rc5_yes":@19, @"rc5_no":@20, @"rc5_red":@27, @"rc5_green":@28, @"rc5_blue":@29, @"rc5_yellow":@30, @"rc5_up":@34, @"rc5_down":@35, @"rc5_left":@36, @"rc5_right":@37, @"rc5_ok":@38, @"rc5_play":@53, @"rc5_stop":@54, @"rc5_menu":@58, @"rc5_num0":@0, @"rc5_num1":@1, @"rc5_num2":@2, @"rc5_num3":@3, @"rc5_num4":@4, @"rc5_num5":@5, @"rc5_num6":@6, @"rc5_num7":@7, @"rc5_num8":@8, @"rc5_num9":@9};
                    NSNumber *rc = remote[action];
                    if (!rc) {
                        r[@"ok"] = @NO;
                        r[@"message"] = @"Onbekende RC5-opdracht";
                    } else {
                        IOReturn sent = sendOpcode(d, 0x91, 0, (uint8_t)[rc unsignedIntValue]);
                        r[@"write_result"] = hexResult(sent);
                        r[@"rc5_command"] = rc;
                        r[@"rc5_address"] = @0;
                        r[@"ok"] = @(sent == kIOReturnSuccess);
                        r[@"message"] = @"IR RC5 uitzendopdracht verstuurd; dit is geen infraroodontvangst of fysieke bevestiging";
                    }
                } else if ([action isEqualToString:@"sound_test"] || [action isEqualToString:@"ir_on"] || [action isEqualToString:@"ir_off"]) {
                    // Safe isolated command, but still requires human observation.
                    uint8_t opcode = [action isEqualToString:@"sound_test"] ? 0x10 : ([action isEqualToString:@"ir_on"] ? 0x17 : 0x18);
                    IOReturn sent = sendOpcode(d, opcode, 0, 0);
                    r[@"write_result"] = hexResult(sent);
                    BOOL ok = sent == kIOReturnSuccess;
                    if ([action isEqualToString:@"ir_on"]) {
                        // Never leave IR output enabled; switch it off again shortly afterwards.
                        usleep(150000);
                        IOReturn off = sendOpcode(d, 0x18, 0, 0);
                        r[@"ir_on_result"] = hexResult(sent);
                        r[@"ir_off_result"] = hexResult(off);
                        ok = ok && off == kIOReturnSuccess;
                    }
                    r[@"ok"] = @(ok);
                    r[@"message"] = ok ? @"Origineel testcommando verstuurd; fysiek gedrag nog verifiëren" : @"Testcommando of IR-uit mislukt; zie afzonderlijke USB-resultaten";
                } else if ([action hasPrefix:@"spin_"]) {
                    // OEM motor IDs: right=3, left=4. Firmware stops after 60*4 ms.
                    BOOL left = [action isEqualToString:@"spin_left"] || [action isEqualToString:@"spin_left_medium"];
                    BOOL faster = [action hasSuffix:@"_medium"];
                    uint8_t packet[TUX_OUTPUT_BYTES];
                    tux_spin_report(packet, left, faster, false);
                    IOReturn config = sendPacket(d, packet);
                    IOReturn movement = kIOReturnNotReady;
                    if (config == kIOReturnSuccess && !gStopRequested) {
                        tux_spin_report(packet, left, faster, true);
                        movement = sendPacket(d, packet);
                    }
                    if (movement == kIOReturnSuccess)
                        for (int i = 0; i < 12 && !gStopRequested; ++i) usleep(25000);
                    IOReturn stop = sendOpcode(d, 0x37, 0, 0);
                    r[@"ok"] = @(config == kIOReturnSuccess && movement == kIOReturnSuccess && stop == kIOReturnSuccess);
                    r[@"motor_config_result"] = hexResult(config);
                    r[@"movement_result"] = hexResult(movement);
                    r[@"stop_result"] = hexResult(stop);
                    r[@"motor_id"] = left ? @4 : @3;
                    r[@"speed"] = faster ? @5 : @3;
                    r[@"firmware_duration_ms"] = @240;
                    r[@"auto_stop_target_ms"] = @300;
                    r[@"stop_requested"] = @(gStopRequested != 0);
                    r[@"message"] = @"OEM-draaipuls en STOP geprobeerd; hoek en fysieke beweging nog bevestigen";
                } else {
                    NSDictionary *pulses = @{
                        // Use OPEN_EYES (0x33) as the single reversible recovery test.
                        // Physical duration is UNVERIFIED, bounded to 1200ms then STOP_EYES.
                        @"eyes_open": @[@0x33,@0,@0,@0x32,@1200],
                        @"eyes_close": @[@0x40,@1,@0,@0x32,@600],
                        @"mouth_toggle": @[@0x41,@1,@0,@0x36,@400],
                        @"mouth_open": @[@0x34,@0,@0,@0x36,@350],
                        @"mouth_close": @[@0x35,@0,@0,@0x36,@350]
                    };
                    NSArray<NSNumber *> *args = pulses[action];
                    if (args) {
                        NSDictionary *pulse = safePulse(d, action, [(NSNumber *)args[0] unsignedCharValue],
                            [(NSNumber *)args[1] unsignedCharValue],[(NSNumber *)args[2] unsignedCharValue],[(NSNumber *)args[3] unsignedCharValue],
                            (useconds_t)([(NSNumber *)args[4] unsignedIntValue]*1000));
                        [r addEntriesFromDictionary:pulse];
                    }
                }
                IOReturn closed = IOHIDDeviceClose(d, kIOHIDOptionsTypeNone);
                r[@"close_result"] = hexResult(closed);
                if (closed != kIOReturnSuccess) r[@"close_warning"] = @"HID-close mislukt";
                result = r;
            }
        } else {
            result = fail(@"wrong_report_size", @"HID-uitvoerreport is niet exact 64 bytes; geen opdracht verstuurd");
        }
    }
    if (devices) CFRelease(devices);
    CFRelease(manager);
    return result ?: fail(@"unknown_error", @"Onbekende fout");
}
int main(int argc, const char *argv[]) {
    @autoreleasepool {
        if (argc != 2) { emit(fail(@"usage", @"Gebruik: tuxhid <vaste actie uit allowlist>")); return 2; }
        signal(SIGTERM, requestStop);
        signal(SIGINT, requestStop);
        gOutputReports = [NSMutableArray array];
        NSString *action = [NSString stringWithUTF8String:argv[1]] ?: @"";
        NSMutableDictionary *r = [perform(action) mutableCopy];
        r[@"helper_version"] = HelperVersion;
        r[@"action"] = action;
        r[@"output_reports"] = [gOutputReports copy];
        r[@"usb_output_reports_attempted"] = @(gOutputReports.count > 0);
        emit(r);
        return [r[@"ok"] boolValue] ? 0 : 1;
    }
}
