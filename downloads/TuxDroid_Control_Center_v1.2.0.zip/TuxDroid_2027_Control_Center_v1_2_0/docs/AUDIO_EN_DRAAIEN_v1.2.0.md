# Herstelonderzoek geluid, TTS en draaien

Op 25 oktober 2026 gaf de gebruiker aan dat geluid, TTS en draaien niet
werkten in v1.1.0. Hiervoor is nu de volledige historische C-driver gevonden,
naast de eerder aangeleverde Ruby- en Java-bronnen. Het eerdere onderzoek
beperkte zich tot beschikbare uploads; de conclusie dat de driver daar
ontbrak betekende niet dat die nergens meer beschikbaar was.

## Controleerbare bronnen

- [libtuxdriver, vastgelegde commit](https://github.com/joelmatteotti/tuxdriver/tree/b89270c787f77d24639d898de0b155b86cc28ac5):
  oorspronkelijke C2ME-code met copyright 2008, bewaard in een communitymirror.
- [Audio: kanaalkeuze en mute](https://github.com/joelmatteotti/tuxdriver/blob/b89270c787f77d24639d898de0b155b86cc28ac5/src/tux_audio.c).
- [USB: robotheader 0 en dongleheader 1](https://github.com/joelmatteotti/tuxdriver/blob/b89270c787f77d24639d898de0b155b86cc28ac5/src/tux_usb.c).
- [Flashgeluid: volumecodering](https://github.com/joelmatteotti/tuxdriver/blob/b89270c787f77d24639d898de0b155b86cc28ac5/src/tux_sound_flash.c).
- [Motorconfiguratie, beweging en tijdcodering](https://github.com/joelmatteotti/tuxdriver/blob/b89270c787f77d24639d898de0b155b86cc28ac5/src/tux_movements.c),
  [motor-ID's](https://github.com/joelmatteotti/tuxdriver/blob/b89270c787f77d24639d898de0b155b86cc28ac5/src/tux_movements.h).
- [PortAudio-server: afzonderlijke TuxDroid-geluidskaart](https://github.com/joelmatteotti/tuxdroidserver_pa/blob/1fa665f11a6372f614f6363d925af7f235b5ef48/src/TuxAudio.c).
- [Firmwarebron: tijdvlag en motorconfiguratie](https://github.com/joelmatteotti/tuxfirmware/blob/40917ef786e620b3e761ad85c34d12f7d060834a/tuxcore/motors.c).
- [Firmwarebron: geldige tracks beginnen bij 1](https://github.com/joelmatteotti/tuxfirmware/blob/40917ef786e620b3e761ad85c34d12f7d060834a/tuxaudio/flash.c),
  functie `playInit` verwerpt nul en tracks boven het aantal opgeslagen geluiden.
- [macOS say-handleiding](https://keith.github.io/xcode-man-pages/say.1.html):
  `-a ?` voor audio-uitgangen; `-a ID` voor expliciete uitvoer; `-f -` voor tekst via stdin.

De repositories zijn uitsluitend gelezen. Geen historische executable of
driver is gestart. De firmwarebron is niet gebouwd, geflasht of meegestuurd.
De hardwareversie op de Mac is daarmee nog niet vastgesteld.

## Concrete verschillen en aanpassingen

| Onderdeel | v1.1.0 | v1.2.0 |
|---|---|---|
| Geluidsvolume | Parameterbyte 80 direct verzonden | OEM-formule `7 - floor(percent * 7 / 100)`: 80% wordt byte 2 |
| Geluidsnummer | `sound_0` verstuurde track 0, die de firmware verwerpt | Bestaande actie-ID's `sound_0` t/m `sound_7` verwijzen nu naar tracks 1 t/m 8; schermlabels volgen die nummers |
| Robot-TTS | Alleen macOS `say` op standaarduitgang | Uitgangen opnieuw opvragen, expliciet een aanwezige TuxDroid-uitgang kiezen en `say -a ID -f -` gebruiken |
| Donglekanaal | Ontbrak | TTS: `01 02 01 00 00`; gewone audio: `01 02 00 00 00`; daarna unmute `00 92 00 00 00` |
| Draaien | Ruby-opcode met snelheid 1/2, gevolgd door STOP na 300 ms; label suggereerde 90° | OEM-configuratie `00 81 motor snelheid 00`, beweging `00 D4 motor 3C 01`, STOP `00 37 00 00 00` |

Alle pakketten blijven HID-outputreports van 64 bytes, report-ID 0, met
nulvulling. Motor-ID 4 is links, 3 rechts. De snelheden zijn 3 en 5 uit de
gedocumenteerde reeks 1–5. `3C` is 60 tijdstappen van 4 ms: een doelduur van
240 ms in de referentiefirmware. De onafhankelijke host-STOP blijft uiterlijk
na een doelduur van 300 ms geprobeerd worden. Geen softwaretimer garandeert
een fysieke stoptijd als USB blokkeert of de hardware afwijkt.

De nieuwe motoropdracht heeft een betekenisvolle vijfde byte. De gezamenlijke
led- en vleugelbytes zijn ongewijzigd. Andere motoren, IR en individuele leds
zijn bij deze wijziging niet omgezet naar de nieuw gevonden driver.

## Audio en waarnemingen

De app verandert de standaard geluidsuitgang van macOS niet. Bij robotspraak
wordt alleen een tijdens de opdracht opnieuw gevonden TuxDroid-uitgang gebruikt.
Bij ontbreken of mislukken is er geen automatische Mac-fallback. Een aparte
Mac-knop behoudt hostspraak; browserstem blijft afzonderlijk beschikbaar.

De geluidsproef spreekt een vaste korte zin via dezelfde robotroute. Er zijn
geen geluiden in het flashgeheugen geschreven. Een geluidsbank kan leeg zijn;
dan levert een correcte trackopdracht nog geen hoorbaar geluid op.

Spraak-STOP en alle motor-STOP-knoppen annuleren een voorbereide of lopende
spraakopdracht. De app bewaart kanaalkeuze, USB-resultaten, apparaat-ID/naam,
doel en afspeelresultaat, maar geen ingevoerde spreektekst. Een hoorbare
waarneming kan afzonderlijk bij de robotspraak worden opgeslagen.

## Openstaande fysieke controle

De originele dongle moet op de Mac als audio-uitgang zichtbaar zijn. Deze
Linux-omgeving heeft geen CoreAudio, Apple IOKit of aangesloten robot. Er is
hier geen Mac-build of fysieke test uitgevoerd. Uit softwaretests volgt geen
bewijs dat de gebruiker nu geluid hoort, dat de robot de firmware-tijdvlag
ondersteunt of welke hoek hij draait. Een volledige cirkel is niet ingebouwd;
eerst moet een korte draaipuls met stopgedrag fysiek worden beoordeeld.
