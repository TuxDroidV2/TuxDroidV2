# Validatie v1.2.0

Uitgevoerd in Linux met Python 3.12.14, een C-compiler en Chromium:

- 100 Python-tests, geen overgeslagen tests.
- 22 browsercontroles, waaronder behoud van alle 70 actieknoppen, mobiel
  formaat, scènes/STOP, rapporten en de nieuwe expliciete audioselectie.
- De protocolkern van de echte helper wordt met
  `cc -std=c11 -Wall -Wextra -Werror` gecompileerd en uitgevoerd.
  De controles vergelijken met vanuit de OEM-bron vastgestelde bytes:
  gezamenlijke leds/vleugels ongewijzigd, dongleheader 1, 80%-volume als byte 2,
  tracks 1 en 8, links-/rechtsmotorconfiguratie en beweging inclusief tijdvlag.
- Audiocontroles bootsen de macOS-procesinterface na: device opnieuw zoeken,
  verkeerde/verdwenen uitgang afwijzen, geen standaard-Mac-fallback,
  kanaalkeuze vóór spraak, fouten doorgeven en stoppen vóór/tijdens het afspelen.
- Spreektekst gaat via stdin; tekst wordt niet als procesoptie geïnterpreteerd.
  Rapporten onderscheiden hostspraak, robotspraak en fysieke waarnemingen.
- Python-, JavaScript- en shellsyntaxcontrole.
- Het uiteindelijke pakket wordt uitgepakt, op de Python-tests gecontroleerd,
  als demo gestart en herstart. De pakketbouwer moet hetzelfde ZIP-bestand
  byte voor byte kunnen reproduceren.

```bash
python3 -m unittest discover -s Tests -v
python3 Tools/check_browser.py
```

De browsertests vereisen Playwright en Chromium; de app zelf gebruikt de
Python-standaardbibliotheek en de standaard macOS-spraakfunctie. Zonder
C-compiler wordt uitsluitend de native kerntest expliciet overgeslagen.
Dat gebeurde niet in deze validatie.

Niet uitgevoerd: de volledige Objective-C/IOKit-build op macOS, CoreAudio-
apparaatdetectie op de gebruikers-Mac, USB/radio-overdracht naar de robot,
hoorbare TTS/flashgeluiden en fysieke draaipuls of gemeten stoptijd. Er is geen
claim dat een volledige cirkel of alle oorspronkelijke functies werken.

Historische driver- en firmwarecode is alleen gelezen. Er zijn geen oude
executables gestart, geen firmwarewijzigingen uitgevoerd en geen fysieke
robotcommando's vanuit deze cloudomgeving verstuurd.
