# TuxDroid 2027 — Control Center v1.1.0

Het Command Deck met 70 vaste actieknoppen, 58 historische gadgetkaarten en
verbeterde diagnose. Dit blijft een laboratoriumprototype: veel oorspronkelijke
robotfuncties zijn nog niet fysiek bevestigd. Lees de actuele wijzigingen en
grenzen in [LEESMIJ_v1.1.0.md](LEESMIJ_v1.1.0.md).

## Start op je Mac

Stop de vorige server met Ctrl+C. Pak het nieuwe ZIP-bestand uit in Downloads.
Open Terminal:

```bash
cd "$HOME/Downloads/TuxDroid_2027_Control_Center_v1_1_0"
bash Start_TuxDroid_2027.command
```

Vereist: Python 3.10+, Apple Command Line Tools en de originele dongle.
Het script bouwt de nieuwe helper en opent het dashboard. Gebruik vertrouwd
privé-wifi en houd Terminal open. Stop met Ctrl+C. Als de bouw meldt dat de
Command Line Tools ontbreken, installeer ze via `xcode-select --install` en
start het script opnieuw.

Voor de demo zonder USB-opdrachten:

```bash
bash Start_Demo.command
```

## Wat is verbeterd

- HID-invoer via de door Apple voorgeschreven callback; geen gefingeerde nulmeting.
- Volledige USB-resultaten, exacte outputbytes en fysieke waarnemingen per opdracht.
- Automatische sessierapporten in `reports/`, met de laatste 200 opdrachten.
- STOP annuleert resterende scènestappen, ook vanuit een ander browservenster.
- Versiecontrole van de helper en duidelijke scheiding tussen demo en USB-verbinding.
- Oorspronkelijke `.att`, ZIP- en tar.gz-bestanden inspecteren als gegevens.

De bekende gezamenlijke LED- en vleugelbytes en motorlimieten zijn behouden.
Afzonderlijke leds, IR, ooglidherstel, robotspraak en sensordecodering zijn nog
niet als fysiek gerepareerd bevestigd. De nieuwe IOKit-code moet op macOS worden
gecompileerd en op het echte apparaat worden gecontroleerd. Plan elke fysieke
proef apart; een software-STOP garandeert geen fysieke noodstop.

## Ontwikkelen

```bash
python3 -m unittest discover -s Tests -v
python3 Tools/check_browser.py
```

De app gebruikt alleen de Python-standaardbibliotheek. De native kerntest
gebruikt een C-compiler. De optionele browsertests vereisen Playwright en een
lokale Chromium. De oorspronkelijke archieven en privétestrapporten worden
niet met het apppakket meegepubliceerd.
