# Control Center v1.1.0 — nieuwe herstelversie

Deze versie behoudt het bestaande Command Deck en verwerkt de aantoonbare
softwareverbeteringen uit het brononderzoek en het aangeleverde echte
testrapport. Het is geen claim dat alle 70 knoppen fysiek werken.

## Uitproberen op de Mac

1. Stop de eerdere server met Ctrl+C; de eerdere map mag je bewaren.
2. Download het nieuwe ZIP-bestand en pak het uit in Downloads. De map heet
   `TuxDroid_2027_Control_Center_v1_1_0`.
3. Open Terminal en voer uit:

   ```bash
   cd "$HOME/Downloads/TuxDroid_2027_Control_Center_v1_1_0"
   bash Start_TuxDroid_2027.command
   ```

Het script vereist macOS, Python 3.10+ en Apple Command Line Tools. Het bouwt
`Sources/tuxhid.m`, inclusief de nieuwe gedeelde header `Sources/tux_protocol.h`,
met de oorspronkelijke Foundation/IOKit/CoreFoundation-buildflags. Starten doet
alleen een scan en een HID-open/sluit-proef. Het start geen LED-, motor-,
audio-, firmware- of sensorproef.

Gebruik de originele dongle en vertrouwd privé-wifi. Deze HTTP-app heeft
geen wifi-gebruikersauthenticatie en hoort niet op een openbaar netwerk of
achter portforwarding. De robot blijft een experimenteel apparaat: spreek
elke fysieke proef apart af en houd fysiek uitschakelen mogelijk.

De app toont versie 1.1.0 en controleert of de native helper daarbij hoort.
Bij een oude helper worden nieuwe actiecommando's geblokkeerd totdat je via
het bouwscript herstart. STOP blijft als poging beschikbaar.

De demo start met `bash Start_Demo.command`. Die verstuurt geen USB-opdrachten.
Het dashboard opent automatisch; houd Terminal open.

## Wat het echte rapport aantoonde

Het rapport van v1.0.1 draaide in hardwaremodus en bevatte succesvolle
dongledetectie en HID-toegang. De 70 bewaarde gebeurtenissen bestonden uit
61 overige succesvolle native opdrachten, drie succesvolle verbindingscontroles,
drie succesvolle macOS-spraakoproepen en drie mislukte `read_input`-pogingen.
Het laatste gedetailleerde resultaat had `input_result: 0xE0005000`; openen
en sluiten hadden daarin allebei resultaat `0x00000000`.

Dit bewijst toegang tot de helper en USB-stack, niet uitvoering door de robot.
Het rapport bevatte geen bevestigde fysieke waarnemingen. Details van eerdere
opdrachten waren al vervangen door alleen hun logtekst. Het oorspronkelijke
rapport is privé bewaard en zit niet in deze distributie.

## Aangebrachte verbeteringen

### Invoer ontvangen

De oude implementatie vroeg een inputreport op met `IOHIDDeviceGetReport`.
Apple verwijst voor inputreports expliciet naar
`IOHIDDeviceRegisterInputReportCallback`. De nieuwe helper registreert die
callback, koppelt het apparaat aan de runloop, luistert maximaal 750 ms en
ruimt callback en runloopkoppeling weer op voordat de buffers verdwijnen.
Er wordt geen nieuw statuscommando of andere output verzonden.

Een ontvangen report krijgt de werkelijke report-ID, lengte en hexdata.
Als niets binnenkomt, meldt de app dat neutraal. Dat is geen nulmeting en
geen bewijs van defecte sensoren. Oude data wordt dan niet als actuele waarde
blijven getoond. Foutieve of te grote reports worden afgewezen.

De volledige sensor-/statusdecoder en het eventuele benodigde requestprotocol
ontbreken nog. De callbackwijziging garandeert dus niet dat binnen ieder kort
luistervenster gegevens binnenkomen.

Officiële bron: [Apple IOKitUser, IOHIDDevice.h](https://github.com/apple-oss-distributions/IOKitUser/blob/main/hid.subproj/IOHIDDevice.h),
documentatie van `IOHIDDeviceGetReport`, `IOHIDDeviceRegisterInputReportCallback`
en `IOHIDDeviceScheduleWithRunLoop`. Het tijdens onderzoek gelezen headerbestand
had SHA-256 `64aad6babb2e4bbbf31386f54c658fd16fbaa1aa271fb8f396126c22d6f833bd`.

### Resultaten en fysieke waarnemingen

Elke afgeronde of geblokkeerde opdracht krijgt een eigen sessie-ID/volgnummer,
tijden, duur, antwoord en foutcode. De native helper registreert elke
outputpoging met alle 64 bytes, report-ID en IOReturn. Een timeout blijft
"uitvoering onbekend"; een gestarte helper wordt niet als "niets uitgevoerd"
voorgesteld. Een eventuele herstel-STOP en diens resultaat worden bewaard.
De helperversie en hash staan eveneens in het rapport.

Onder **Wat deed de robot?** kun je bij een eerdere echte USB-poging kiezen:
verwachte reactie, geen reactie of andere reactie, plus maximaal 400 tekens
toelichting. De waarneming blijft bij die specifieke poging staan, ook na een
volgende actie of STOP. Demo-, hostspraak- en verbindingscontroles kunnen niet
als fysieke robotwerking worden bevestigd. USB-fout en fysieke waarneming
blijven onafhankelijke gegevens, ook bij een deels uitgevoerde opdracht.

De app bewaart automatisch `reports/latest.json` en een apart bestand per
appstart. Elk rapport bevat de laatste 200 volledige opdrachten; eventuele
afgekapt oudere opdrachten worden geteld. Het scherm toont de laatste twintig.
Gebruik **Diagnose → Download volledig rapport** om een kopie te delen.
De map `reports/` wordt niet in Git of in deze distributie opgenomen.

### STOP en scènes

Alle STOP-knoppen annuleren resterende lokale scènestappen. Daarnaast verhoogt
iedere STOP een serverversie voor scènes: een latere stap uit een geannuleerde
scène wordt ook vanuit een ander browservenster afgewezen. Een al aangenomen
of reeds lopende hardwareactie kan niet met software gegarandeerd worden
teruggedraaid. Bestaande motorpulslimieten en STOP-pogingen blijven van kracht.

Tijdens een scène zijn bewerken, nogmaals starten en losse actieknoppen
uitgeschakeld; STOP blijft beschikbaar. Een fout of verbroken verbinding
breekt de scène af. Een mislukte scène meldt geen succesvolle afronding.

### Oorspronkelijke Attitunes inspecteren

Bij **Oorspronkelijke Attitunes bekijken** kun je een `.att`, ZIP of tar.gz van
maximaal 2 MB kiezen. De lezer ondersteunt ook de geneste structuur van het
aangeleverde `attitunes.zip`. Hij toont namen, talen, tijdlijnen, gesproken tekst
en de namen van ingebedde WAV-bestanden. De originele 50 scènes met 306
tijdlijnblokken zijn hiermee daadwerkelijk gelezen.

De archieven worden alleen als gegevens verwerkt, niet uitgepakt naar het
bestandssysteem of uitgevoerd. De oorspronkelijke scènes worden nog niet via
de robot afgespeeld en de WAV-bestanden worden niet als een werkende audioroute
gepresenteerd. Onbekende commandonamen blijven tekst in de inspectie.

### Overige correcties

- Demo, USB/HID-toegang en fysieke robotreactie worden afzonderlijk aangegeven.
- Een verdwenen dongle of foutieve helperuitvoer maakt de verbinding niet
  kunstmatig gereed.
- macOS-spraak blijft expliciet hostaudio; het rapport noemt dit geen robotspraak.
- Versieverschillen tussen app en helper worden zichtbaar en blokkeren nieuwe acties.
- Foutieve JSON-typen, browserheaders en waarnemingen worden afgewezen.
- Teksten worden als tekst getoond; een toelichting kan geen HTML uitvoeren.
- Een waarneming die je aan het typen bent blijft staan bij een statusverversing.

## Validatie en grenzen

De uiteindelijke controles worden vastgelegd in `docs/VALIDATIE_v1.1.0.md`.
De reguliere tests draaien zonder echte USB en zonder oude software uit te
voeren. De gedeelde C-kern voor reportopbouw en inputbufferverwerking wordt
wel echt gecompileerd en uitgevoerd. De browsercontroles gebruiken Chromium
met nagebootste helperantwoorden.

Niet hier uitgevoerd: compilatie van de Objective-C/IOKit-helper op macOS,
radio-overdracht of fysieke robotproeven. Het ontbreken van de oorspronkelijke
complete driver blijft relevant voor de afzonderlijke led-, IR- en ooglidproblemen.
Robotspraak, microfoon, sensordecodering en echte oorspronkelijke Attitunes-
uitvoering zijn niet als voltooid geïmplementeerd. Er zijn geen nieuwe
onbewezen opcodes toegevoegd, geen firmwarebestanden meegeleverd en geen
firmwarewijzigingen uitgevoerd.
