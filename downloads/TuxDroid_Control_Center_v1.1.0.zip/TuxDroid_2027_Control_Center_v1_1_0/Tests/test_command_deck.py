"""Mock-only regression tests. Does not send real USB commands."""
import http.client
import json
from pathlib import Path
import re
import sys
import threading
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from catalog import CATALOG, STATUS_CODES, LEGACY_GADGETS, RC5_COMMANDS
from control_center import Bridge, ALLOWED, MOTOR_EXPERIMENTS, WING_ACTIONS, STOP_ACTIONS, create_server

class CatalogTests(unittest.TestCase):
    def test_70_physical_actions(self): self.assertEqual(len(CATALOG),70)
    def test_58_legacy_gadgets(self): self.assertEqual(len(LEGACY_GADGETS),58)
    def test_36_status_names(self): self.assertEqual(len(STATUS_CODES),36)
    def test_no_duplicate_ids(self):self.assertEqual(len({x['id'] for x in CATALOG}),len(CATALOG))
    def test_every_catalog_action_allowlisted(self):self.assertTrue({x['id'] for x in CATALOG}<=ALLOWED)
    def test_no_firmware_flashing_action(self):self.assertFalse(any('firmware_updat' in x for x in ALLOWED))
    def test_fixed_rc5_commands(self):self.assertEqual(len(RC5_COMMANDS),26)
    def test_last_led_issue(self):self.assertTrue(all(x['status']=='afwijking' for x in CATALOG if x['id'] in ('led_left_on','led_left_off','led_right_on','led_right_off','ir_on')))
    def test_eye_close_is_old_toggle(self):self.assertEqual(next(x['opcode'] for x in CATALOG if x['id']=='eyes_close'),'0x40')
    def test_native_whitelist_complete(self):
        text=(ROOT/'Sources/tuxhid.m').read_text()
        region=text.split('NSSet *allowed =')[1].split('IOHIDManagerRef manager')[0]
        missing=[x['id'] for x in CATALOG if f'@"{x["id"]}"' not in region]
        self.assertFalse(missing,missing)
    def test_native_package_no_flash(self):
        text=(ROOT/'Sources/tuxhid.m').read_text()
        self.assertNotIn('IOHIDDeviceSetFeature',text)
        self.assertIn('uint8_t packet[64] = {0}',text)
        self.assertIn('IOHIDDeviceSetReport',text)
        self.assertIn('safePulse(d, action',text)
    def test_native_max_motor_intervals(self):
        text=(ROOT/'Sources/tuxhid.m').read_text()
        times=[int(m) for m in re.findall(r'@\[(?:@0x[0-9A-Fa-f]+|@\d+),@\d+,@\d+,@0x[0-9A-Fa-f]+,@(\d+)\]',text)]
        self.assertTrue(times)
        self.assertLessEqual(max(times),1200)
    def test_native_not_arbitrary_script(self):self.assertNotIn('system(', (ROOT/'Sources/tuxhid.m').read_text())
    def test_web_has_search_studio_gadgets(self):
        text=(ROOT/'Web/index.html').read_text()
        for key in ('commandSections','gadgetGrid','sceneSteps','search','emergency','sensorGrid','__CATALOG_DATA__'):
            self.assertIn(key,text)
    def test_preview_no_fake_robot_audio(self):self.assertIn('Mac-uitvoer klinkt alleen door TuxDroid', (ROOT/'Web/index.html').read_text())

class BridgeTests(unittest.TestCase):
    def setUp(self):self.b=Bridge(mock=True)
    def test_not_ready_no_hardware_control(self):self.assertEqual(self.b.run('led_on')[0],409)
    def test_connect(self):
        self.assertEqual(self.b.run('scan')[0],200)
        self.assertEqual(self.b.run('probe')[0],200)
        self.assertTrue(self.b.hid_open)
    def connected(self):self.b.run('scan');self.b.run('probe')
    def test_every_command_executed_in_mock(self):
        self.connected()
        for a in CATALOG:
            with self.subTest(a=a['id']):self.assertEqual(self.b.run(a['id'])[0],200)
    def test_stop_works_disconnected(self):self.assertEqual(self.b.run('stop_all')[0],200)
    def test_arbitrary_opcode_fails(self):
        self.connected()
        for bad in ('opcode_13','flash_firmware','play_sound_400','rc5_foo','../../etc/passwd','eyes_blink'):
            with self.subTest(action=bad):self.assertNotEqual(self.b.run(bad)[0],200)
    def test_no_flash_in_report(self):self.assertFalse(self.b.report()['firmware_update'])
    def test_no_token_in_report(self):self.assertNotIn(self.b.token,json.dumps(self.b.report()))
    def test_host_speech_is_not_robot_audio(self):
        self.assertIn('SIMULATIE',self.b.speak('Hallo')[1]['message'])
    def test_motor_serialization(self):
        self.connected();started=threading.Event();release=threading.Event();old=self.b.raw_helper
        def delayed(action,timeout=3):
            if action=='eyes_close':started.set();release.wait(1)
            return old(action,timeout)
        self.b.raw_helper=delayed
        t=threading.Thread(target=lambda:self.b.run('eyes_close'));t.start();self.assertTrue(started.wait(1))
        self.assertEqual(self.b.run('spin_left')[0],429)
        self.assertEqual(self.b.run('flap')[0],429)
        self.assertEqual(self.b.run('stop_all')[0],200)
        release.set();t.join(2)
    def test_report_version(self):self.assertEqual(self.b.report()['version'],'1.1.0')

class WebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.b=Bridge(mock=True)
        cls.server=create_server(cls.b,port=0)
        cls.port=cls.server.server_address[1]
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(3)
    def req(self,method,path,body=None,headers=None,token=True):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5); host=f'127.0.0.1:{self.port}'
        h={'Host':host,**(headers or {})}
        if method=='POST':
            h.setdefault('Origin','http://'+host)
            if token:h['X-Tux-Token']=self.b.token
        c.request(method,path,body=json.dumps(body) if body is not None else None,headers=h)
        r=c.getresponse();data=r.read();s=r.status;c.close();return s,data
    def test_home_embeds_catalog(self):
        s,p=self.req('GET','/');self.assertEqual(s,200)
        self.assertIn(b'rc5_num9',p)
        self.assertIn(b'Verlichting',p)
        self.assertNotIn(b'__CATALOG_DATA__',p)
    def test_all_actions_catalog(self):
        s,p=self.req('GET','/api/catalog');self.assertEqual(s,200)
        data=json.loads(p)
        self.assertEqual(len(data['commands']),70)
    def test_initial_status(self):self.assertEqual(self.req('GET','/api/status')[0],200)
    def test_invalid_origin(self):
        self.assertEqual(self.req('POST','/api/action/scan',{},headers={'Origin':'http://evil.test'})[0],403)
    def test_invalid_token(self):self.assertEqual(self.req('POST','/api/action/scan',{},token=False)[0],403)
    def test_no_extra_usb_payload(self):self.assertEqual(self.req('POST','/api/action/led_on',{'opcode':90})[0],400)
    def test_legacy_pin_not_needed(self):
        self.assertEqual(self.req('POST','/api/action/scan',{})[0],200)
        self.assertEqual(self.req('POST','/api/action/probe',{})[0],200)
        self.assertEqual(self.req('POST','/api/action/rc5_num1',{})[0],200)
    def test_report(self):
        s,p=self.req('GET','/api/report');self.assertEqual(s,200)
        self.assertEqual(json.loads(p)['version'],'1.1.0')
    def test_no_shell_commands(self):self.assertEqual(self.req('POST','/api/action/../../rm',{})[0],400)

if __name__=='__main__':unittest.main(verbosity=2)
