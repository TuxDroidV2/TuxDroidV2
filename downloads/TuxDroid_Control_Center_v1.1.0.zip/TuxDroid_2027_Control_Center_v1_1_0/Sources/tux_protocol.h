#ifndef TUX_PROTOCOL_H
#define TUX_PROTOCOL_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define TUX_OUTPUT_BYTES 64
#define TUX_INPUT_CAPACITY 4096

/* The proven output layout remains [0, opcode, p1, p2, 0, ...]. */
static inline void tux_output_report(uint8_t packet[TUX_OUTPUT_BYTES],
                                     uint8_t opcode, uint8_t p1, uint8_t p2) {
    memset(packet, 0, TUX_OUTPUT_BYTES);
    packet[1] = opcode;
    packet[2] = p1;
    packet[3] = p2;
}

enum tux_input_state { TUX_INPUT_WAITING, TUX_INPUT_RECEIVED,
                       TUX_INPUT_FAILED, TUX_INPUT_INVALID };
struct tux_input_capture {
    enum tux_input_state state;
    int32_t result;
    uint32_t report_id;
    size_t limit;
    size_t length;
    uint8_t bytes[TUX_INPUT_CAPACITY];
};

/* Capture the first event only. No event never becomes a zero-filled reading. */
static inline void tux_capture_input(struct tux_input_capture *capture,
                                     int32_t result, uint32_t report_id,
                                     const uint8_t *bytes, ptrdiff_t length) {
    if (capture->state != TUX_INPUT_WAITING) return;
    capture->result = result;
    capture->report_id = report_id;
    if (result != 0) {
        capture->state = TUX_INPUT_FAILED;
        return;
    }
    if (!bytes || length <= 0 || (size_t)length > capture->limit ||
        (size_t)length > TUX_INPUT_CAPACITY) {
        capture->state = TUX_INPUT_INVALID;
        return;
    }
    memcpy(capture->bytes, bytes, (size_t)length);
    capture->length = (size_t)length;
    capture->state = TUX_INPUT_RECEIVED;
}

#endif
