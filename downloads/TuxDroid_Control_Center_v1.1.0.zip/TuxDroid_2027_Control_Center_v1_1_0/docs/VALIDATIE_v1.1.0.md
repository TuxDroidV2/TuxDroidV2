# Validatie Control Center v1.1.0

## Omgeving en uitgevoerde controles

Ontwikkeling en softwarevalidatie vinden plaats in Linux met Python 3.12.14,
de beschikbare C-compiler en Chromium. De volgende controles zijn uitgevoerd:

- 75 Python-unittests/regressietests; geen overgeslagen of verwachte fouten.
- 18 browsercontroles, inclusief desktop en mobiele afmetingen.
- De gedeelde C-kern is met `cc -std=c11 -Wall -Wextra -Werror` gecompileerd en
  echt uitgevoerd. Die controleert de bekende outputbytes en nulvulling,
  werkelijke kopie van inputdata, report-ID, foutcodes, lengtegrenzen en het
  bewaren van het eerste ontvangen report.
- Het echte aangeleverde `attitunes.zip` is als gegevens gelezen: 50 scènes,
  306 tijdlijnblokken. Er is niets uit dat archief uitgevoerd.
- De frontend-JavaScript en beide shellstartscripts worden bij de laatste
  pakketcontrole op syntax gecontroleerd.
- Het bronpakket wordt via een expliciete lijst opgebouwd en na uitpakken
  opnieuw op de Python-tests en de startbare demo gecontroleerd.

Reproduceerbare testcommando's vanuit de appmap:

```bash
python3 -m unittest discover -s Tests -v
python3 Tools/check_browser.py
```

De browsertests hebben Playwright en een lokale Chromium nodig. De gewone app
heeft geen externe Python-pakketten nodig. De native kerntest vereist `cc`;
zonder die compiler meldt alleen die test expliciet dat hij is overgeslagen.
Dat was in de gebruikte Linux-validatie niet het geval.

## Wat de controles aantonen

De tests controleren onder andere behoud van alle 70 actie-ID's, de native
allowlist, begrensde motorwaarden, juiste bekende reportbytes, STOP tijdens
een motoractie, annuleren van volgende scènestappen, STOP vanuit een tweede
browservenster, geen dubbele scènes, verlies van verbinding, herkenning van
een verkeerde helperversie, rapporthistorie, opslaan en herstellen van
waarnemingen, reportbestanden op schijf en afwijzen van ongeldige invoer.

De scène-, API- en browsertests bootsen helperantwoorden na. Zij bewijzen de
softwarelogica, niet het gedrag van een aangesloten robot. Een source-level
controle bevestigt daarnaast dat de native invoerroute callbacks gebruikt en
geen outputrapporten of `IOHIDDeviceGetReport` voor de invoer oproept.

De geschiedenis bewaart maximaal 200 volledige opdrachten en telt afgekapt
oudere opdrachten. Waarnemingen zijn aan een sessie en een specifieke poging
gekoppeld. Een USB-succes, een timeout met onbekende uitvoering en een fysieke
gebruikerswaarneming blijven afzonderlijke gegevens. Er wordt geen fysieke
waarneming automatisch als geslaagd ingevuld.

## Wat nog niet gevalideerd is

- Compilatie van de volledige Objective-C/IOKit-helper op macOS.
- Werkelijke inputcallbacks en radio-/USB-overdracht op het apparaat.
- Fysieke werking van de nieuwe versie, inclusief afzonderlijke leds, IR,
  openen van gesloten oogleden, robotspraak en sensoren.
- Een volledige interpretatie van de inputreports of een gevalideerde
  aanvullende statusrequest. Die zijn niet verzonnen om de tests te laten slagen.

De gezamenlijke led- en rustige vleugelbytes zijn behouden uit de eerder
bevestigde projectversies. Dit is geen nieuwe fysieke acceptatietest voor
v1.1.0. Het starten van de app voert alleen detectie en openen/sluiten uit;
fysieke proeven vereisen een apart afgesproken test met de gebruiker.

Deze distributie bevat broncode, tests en instructies. Het oorspronkelijke
privétestrapport, historische archieven, firmware, oude executables en
persoonlijke observatiebestanden zijn niet opgenomen.
