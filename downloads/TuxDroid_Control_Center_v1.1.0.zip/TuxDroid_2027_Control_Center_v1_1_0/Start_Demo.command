#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit('Python 3.10 of nieuwer is nodig.')
PY
echo 'TuxDroid 2027 v1.1.0 — DEMO: geen USB-opdrachten naar de robot.'
echo 'Laat dit venster open. Stop met Ctrl+C.'
exec python3 control_center.py --demo
