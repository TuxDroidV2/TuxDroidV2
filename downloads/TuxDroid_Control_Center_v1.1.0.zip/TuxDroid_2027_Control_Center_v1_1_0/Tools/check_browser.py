"""Optional browser regressions: python3 Tools/check_browser.py.

Requires Playwright and a local Chromium. All hardware replies are simulated.
The app and the standard-library test suite do not require these browser tools.
"""
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import unittest
from urllib.parse import urlsplit

ROOT = Path(os.environ.get("TUXDROID_TEST_ROOT", Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(ROOT))
from control_center import Bridge, create_server
from playwright.sync_api import sync_playwright
from Tests.test_attitunes import scene_archive
from control_center import VERSION


class BrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        cls.browser = cls.playwright.chromium.launch(
            executable_path=shutil.which("chromium"), headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def setUp(self):
        self.bridge = Bridge(mock=True)
        self.bridge.run("scan")
        self.bridge.run("probe")
        self.server = create_server(self.bridge, port=0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        self.context = self.browser.new_context(viewport={"width": 1440, "height": 1000})
        self.page = self.context.new_page()
        self.errors = []
        self.requests = []
        self.page.on("pageerror", lambda e: self.errors.append(str(e)))
        self.page.on("request", lambda r: self.requests.append(urlsplit(r.url).path))
        self.page.goto(self.base)
        self.page.wait_for_function("() => bridge.hid_open === true")

    def tearDown(self):
        self.context.close()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(3)
        self.assertEqual(self.errors, [], "Unexpected JavaScript errors")

    def test_demo_is_distinct_from_robot_connection(self):
        self.assertTrue(self.page.locator("#demoMode").is_visible())
        self.assertIn("GEEN ROBOT", self.page.locator("#liveLabel").inner_text())
        self.assertEqual(self.page.locator("#hwVersion").inner_text(), "DEMO")
        self.assertEqual(self.page.locator("#commandSections .tile").count(), 70)
        self.assertFalse(self.page.locator("#livepill").evaluate("el => el.classList.contains('ok')"))

    def start_scene(self):
        self.page.evaluate("steps=[['led_on',1200],['flap',0]];showSteps()")
        self.page.locator("#playSteps").click()
        self.page.wait_for_function("() => scenePlaying && !busy")

    def check_stop(self, selector):
        self.start_scene()
        self.page.locator(selector).click()
        self.page.wait_for_function("() => !scenePlaying", timeout=5000)
        self.assertNotIn("/api/action/flap", self.requests)
        self.assertEqual(self.bridge.flaps, 0)
        self.assertIn("afgebroken", self.page.locator("#toast").inner_text())

    def test_stop_all_tile_cancels_remaining_scene(self):
        self.check_stop(".tile[data-action=stop_all]")

    def test_targeted_motor_stop_cancels_remaining_scene(self):
        self.check_stop(".tile[data-action=wings_stop]")

    def test_emergency_button_still_cancels_scene(self):
        self.check_stop("#emergency")

    def test_failed_scene_does_not_report_completion(self):
        self.page.route("**/api/action/led_on", lambda route: route.fulfill(
            status=502, content_type="application/json",
            body=json.dumps({"ok": False, "message": "Injected USB failure"})))
        self.page.evaluate("steps=[['led_on',0],['flap',0]];showSteps()")
        self.page.locator("#playSteps").click()
        self.page.wait_for_function("() => !scenePlaying")
        self.assertIn("mislukte opdracht", self.page.locator("#toast").inner_text())
        self.assertIn("bad", self.page.locator("#toast").get_attribute("class"))
        self.assertNotIn("/api/action/flap", self.requests)

    def test_demo_led_result_cannot_be_recorded_as_physical(self):
        self.page.locator(".tile[data-action=led_test_left]").click()
        self.page.wait_for_function("() => !busy")
        self.assertTrue(self.page.locator("#section-led-observation").is_visible())
        self.assertTrue(self.page.locator("#ledWorked").is_disabled())
        self.assertTrue(self.page.locator("#ledNotWorked").is_disabled())
        self.assertIn("Simulatie", self.page.locator("#ledFeedbackStatus").inner_text())

    def test_led_observations_reach_downloadable_report(self):
        # Native replies are replaced here: no helper or physical device is used.
        self.bridge.mock = False
        self.bridge.raw_helper = lambda action, timeout=3: {
            "ok": True, "found": True, "action": action,
            "message": "Browser-test fixture, no USB"}
        self.page.evaluate("refresh()")
        for action, selector, worked, expected in (
            ("led_test_left", "#ledNotWorked", False, "linkeroog UIT"),
            ("led_test_right", "#ledWorked", True, "rechteroog UIT"),
        ):
            with self.subTest(action=action):
                self.page.locator(f".tile[data-action={action}]").click()
                self.page.wait_for_function("() => !busy")
                self.assertIn(expected, self.page.locator("#ledExpectation").inner_text())
                self.page.locator(selector).click()
                self.page.wait_for_function(
                    "action => Object.prototype.hasOwnProperty.call(bridge.led_diagnostic_feedback,action)",
                    arg=action)
                report = self.context.request.get(self.base + "/api/report").json()
                self.assertIs(report["usb"]["led_diagnostic_feedback"][action], worked)

    def test_connection_loss_disables_hardware_buttons(self):
        self.page.route("**/api/status", lambda route: route.abort())
        self.page.evaluate("refresh()")
        self.assertTrue(self.page.locator(".tile[data-action=led_on]").is_disabled())
        self.assertFalse(self.page.locator("#emergency").is_disabled())
        self.assertEqual(self.page.locator("#liveLabel").inner_text(), "SERVER OFFLINE")

    def test_mobile_layout_retains_all_commands(self):
        self.page.set_viewport_size({"width": 390, "height": 844})
        self.assertEqual(self.page.locator("#commandSections .tile").count(), 70)
        self.assertTrue(self.page.locator("#emergency").is_visible())
        self.assertTrue(self.page.evaluate(
            "document.documentElement.scrollWidth <= window.innerWidth"),
            self.page.evaluate("Array.from(document.querySelectorAll('body *')).filter(el => el.getBoundingClientRect().right > innerWidth+1).slice(0,16).map(el => [el.tagName,el.id,el.className,Math.round(el.getBoundingClientRect().width)])"))
        output = os.environ.get("TUXDROID_SCREENSHOT")
        if output:
            self.page.screenshot(path=output, full_page=True)

    def hardware_fixture(self):
        # Only fixture replies; this never invokes a native helper.
        self.bridge.mock = False
        def reply(action, timeout=3):
            passive = action in {"scan", "probe", "read_input"}
            return {"ok": True, "action": action, "found": True,
                    "helper_version": VERSION, "output_ready": True,
                    "output_reports": [] if passive else [{"fixture": "no USB"}],
                    "usb_output_reports_attempted": not passive,
                    "message": "Test fixture, no USB"}
        self.bridge.raw_helper = reply
        self.page.evaluate("refresh()")

    def test_observation_after_stop_is_saved_against_original_command(self):
        self.hardware_fixture()
        self.page.locator(".tile[data-action=led_left_on]").click()
        self.page.wait_for_function("() => !busy")
        command_id = self.bridge.last_response["id"]
        self.page.locator("#emergency").click()
        self.page.wait_for_function("() => !busy")
        self.page.locator("#observationCommand").select_option(command_id)
        self.page.locator("#observationOutcome").select_option("different")
        note = '<img src=x onerror="window.unexpectedExecution=true"> Beide ogen brandden.'
        self.page.locator("#observationNote").fill(note)
        self.page.locator("#saveObservation").click()
        self.page.wait_for_function("() => document.getElementById('observationStatus').textContent.includes('opgeslagen')")
        report = self.context.request.get(self.base + "/api/report").json()
        row = next(r for r in report["commands"] if r["id"] == command_id)
        self.assertEqual(row["observation"]["note"], note)
        self.assertEqual(row["observation"]["outcome"], "different")
        self.assertFalse(self.page.evaluate("Boolean(window.unexpectedExecution)"))
        self.assertEqual(self.page.locator("#commandHistory img").count(), 0)

    def test_stop_in_second_window_cancels_scene_in_first(self):
        second = self.context.new_page()
        try:
            second.goto(self.base)
            second.wait_for_function("() => bridge.hid_open === true")
            self.start_scene()
            second.locator("#emergency").click()
            self.page.wait_for_function("() => !scenePlaying", timeout=5000)
            self.assertNotIn("/api/action/flap", self.requests)
            self.assertEqual(self.bridge.flaps, 0)
        finally:
            second.close()

    def test_scene_disables_editing_and_manual_actions(self):
        self.start_scene()
        self.assertTrue(self.page.locator("#addStep").is_disabled())
        self.assertTrue(self.page.locator("#presets button").first.is_disabled())
        self.assertTrue(self.page.locator(".tile[data-action=mouth_open]").is_disabled())
        self.assertFalse(self.page.locator("#emergency").is_disabled())
        self.page.locator("#emergency").click()
        self.page.wait_for_function("() => !scenePlaying")
        self.assertFalse(self.page.locator("#addStep").is_disabled())

    def test_double_play_does_not_start_two_scenes(self):
        self.page.evaluate("steps=[['led_on',150]];playScene();playScene()")
        self.page.wait_for_function("() => !scenePlaying")
        self.assertEqual(self.requests.count("/api/action/led_on"), 1)

    def test_helper_mismatch_is_visible_and_blocks_actions(self):
        self.hardware_fixture()
        self.bridge.helper_version = "1.0.1"
        self.page.evaluate("refresh()")
        self.assertTrue(self.page.locator("#helperWarning").is_visible())
        self.assertTrue(self.page.locator(".tile[data-action=led_on]").is_disabled())
        self.assertFalse(self.page.locator("#emergency").is_disabled())

    def test_missing_input_is_neutral_and_never_shows_stale_values(self):
        self.hardware_fixture()
        self.bridge.last_input = "OLD DATA"
        self.bridge.raw_helper = lambda action, timeout=3: {
            "ok": False, "code": "no_input_report", "input_result": None,
            "input_transport": "interrupt_callback", "status_request_sent": False,
            "message": "Geen inputreport binnen het luistervenster"}
        self.page.evaluate("refresh()")
        self.page.locator(".tile[data-action=read_input]").click()
        self.page.wait_for_function("() => !busy")
        self.assertIn("Geen inputreport", self.page.locator("#inputStatus").inner_text())
        self.assertNotIn("OLD DATA", self.page.locator("#rawData").inner_text())
        self.assertNotIn("bad", self.page.locator("#toast").get_attribute("class"))
        self.assertTrue(self.bridge.hid_open)

    def test_original_attitune_can_be_inspected_without_any_robot_action(self):
        self.page.locator("#attituneFile").set_input_files({
            "name": "demo.att", "mimeType": "application/octet-stream", "buffer": scene_archive()})
        self.page.locator("#inspectAttitunes").click()
        self.page.wait_for_function("() => document.getElementById('attituneStatus').textContent.includes('1 oorspronkelijke')")
        self.assertEqual(self.page.locator("#originalSceneSelect option").count(), 1)
        self.assertIn("Testscène", self.page.locator("#originalTimeline").inner_text())
        self.assertIn("leds_on", self.page.locator("#originalTimeline").inner_text())
        self.assertFalse(any(path.startswith("/api/action/") for path in self.requests))

    def test_note_is_not_lost_when_another_command_arrives(self):
        self.hardware_fixture()
        self.page.locator(".tile[data-action=led_on]").click()
        self.page.wait_for_function("() => !busy")
        command_id = self.bridge.last_response["id"]
        self.page.locator("#observationOutcome").select_option("different")
        self.page.locator("#observationNote").fill("Mijn nog niet opgeslagen waarneming")
        self.bridge.run("led_off")
        self.page.evaluate("refresh()")
        self.assertEqual(self.page.locator("#observationCommand").input_value(), command_id)
        self.assertEqual(self.page.locator("#observationNote").input_value(), "Mijn nog niet opgeslagen waarneming")

    def test_timeout_is_shown_as_unknown_execution(self):
        self.hardware_fixture()
        self.bridge.raw_helper = lambda action, timeout=3: {
            "ok": False, "code": "timeout", "helper_process_started": True,
            "usb_output_reports_attempted": None, "message": "Uitvoering onbekend"}
        self.page.locator(".tile[data-action=flap]").click()
        self.page.wait_for_function("() => !busy")
        self.assertIn("Uitvoering onbekend", self.page.locator("#commandHistory").inner_text())
        self.assertEqual(self.page.locator("#observationCommand option").count(), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
